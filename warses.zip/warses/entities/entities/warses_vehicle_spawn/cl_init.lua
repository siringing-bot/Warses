include("shared.lua")

function ENT:Draw()
    if not LocalPlayer():IsSuperAdmin() then return end
    local cv = GetConVar("warses_show_spawn")
    if not cv or not cv:GetBool() then return end

    self:DrawModel()

    local c = self:GetVehicleSpawnColor()
    if c and c ~= vector_origin then
        local col = Color(
            math.Clamp(c.x * 255, 0, 255),
            math.Clamp(c.y * 255, 0, 255),
            math.Clamp(c.z * 255, 0, 255),
            180)
        render.SetColorMaterial()
        render.DrawSphere(self:GetPos() + Vector(0, 0, 30), 8, 12, 12, col)
    end

    local pos = self:GetPos() + Vector(0, 0, 50)
    local ang = Angle(0, LocalPlayer():EyeAngles().y - 90, 90)
    cam.Start3D2D(pos, ang, 0.08)
        draw.SimpleText("VEH · " .. self:GetVehicleClass(),
            "DermaDefaultBold", 0, -10, Color(255, 220, 120),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("respawn " .. math.Round(self:GetRespawnTime()) .. "s",
            "DermaDefault", 0, 10, Color(200, 210, 230),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    cam.End3D2D()
end
