ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Vehicle Spawn"
ENT.Author = "Warses Team"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.Category = "Warses"

function ENT:SetupDataTables()
    self:NetworkVar("String", 0, "VehicleClass")
    self:NetworkVar("Float", 0, "RespawnTime")
    self:NetworkVar("Float", 1, "NextRespawn")
    self:NetworkVar("Vector", 0, "VehicleSpawnColor")
end
