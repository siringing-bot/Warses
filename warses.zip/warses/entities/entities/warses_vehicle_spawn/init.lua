AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
    self:SetModel("models/props_c17/consolebox01a.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetCollisionGroup(COLLISION_GROUP_WORLD)
    self:DrawShadow(false)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:EnableMotion(false)
    end

    if self:GetVehicleClass() == "" then self:SetVehicleClass("jeep") end
    if self:GetRespawnTime() == 0 then self:SetRespawnTime(30) end
    if self:GetVehicleSpawnColor() == vector_origin then
        self:SetVehicleSpawnColor(Vector(1, 1, 1))
    end

    self.CurrentVehicle = nil
    self:SpawnVehicle()
end

function ENT:RespawnNow()
    if IsValid(self.CurrentVehicle) then
        self.CurrentVehicle:Remove()
        self.CurrentVehicle = nil
    end
    self:SetNextRespawn(0)
    self:SpawnVehicle()
end

function ENT:SpawnVehicle()
    if IsValid(self.CurrentVehicle) then return end

    local class = self:GetVehicleClass()
    if not class or class == "" then return end

    local vehicleList = list.Get("Vehicles")
    local vehData = vehicleList[class]
    local veh = nil

    if vehData then
        veh = ents.Create(vehData.Class or "prop_vehicle_jeep")
        if IsValid(veh) then
            veh:SetModel(vehData.Model)
            if vehData.KeyValues then
                for k, v in pairs(vehData.KeyValues) do
                    veh:SetKeyValue(k, v)
                end
            end
        end
    else
        veh = ents.Create(class)
    end

    if not IsValid(veh) then
        print("[Warses] Error: Invalid vehicle class: " .. tostring(class))
        self:SetNextRespawn(CurTime() + 10)
        return
    end

    veh:SetPos(self:GetPos() + Vector(0,0,10))
    veh:SetAngles(self:GetAngles())

    local success, err = pcall(function()
        veh:Spawn()
        veh:Activate()
    end)

    if not success or not IsValid(veh) then
        print("[Warses] Vehicle spawn error (Missing model?): " .. tostring(err or "Unknown ERROR"))
        self:SetNextRespawn(CurTime() + 10)
        return
    end

    local cv = self:GetVehicleSpawnColor()
    if cv and cv ~= vector_origin then
        local col = Color(
            math.Clamp(cv.x * 255, 0, 255),
            math.Clamp(cv.y * 255, 0, 255),
            math.Clamp(cv.z * 255, 0, 255))
        if not (col.r == 255 and col.g == 255 and col.b == 255) then
            veh:SetColor(col)
            veh:SetRenderMode(RENDERMODE_TRANSCOLOR)
            for _, c in ipairs(veh:GetChildren()) do
                if IsValid(c) then c:SetColor(col) end
            end
            if veh.SetBodyColor then pcall(veh.SetBodyColor, veh, Vector(cv.x, cv.y, cv.z)) end
        end
    end

    self.CurrentVehicle = veh
    self:SetNextRespawn(0)

end

function ENT:Think()
    if not IsValid(self.CurrentVehicle) then
        if self:GetNextRespawn() == 0 then
            self:SetNextRespawn(CurTime() + self:GetRespawnTime())
        elseif CurTime() >= self:GetNextRespawn() then
            self:SpawnVehicle()
        end
    else
        if self:GetNextRespawn() ~= 0 then
            self:SetNextRespawn(0)
        end
    end

    self:NextThink(CurTime() + 1)
    return true
end

function ENT:OnRemove()
end
