AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

function ENT:Initialize()
    self:SetModel("models/props_c17/gravestone003a.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_VPHYSICS)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:EnableMotion(false)
    end

    self:SetTrigger(true)

    self:SetCaptureProgress(0)
    self:SetOwningTeam(0)
    self:SetCapturingTeam(0)
    self:SetPointName("Capture Point")
    self:SetProgressTeam(0)

    self.PlayersInZone = {}

    self:SetZoneType(1)
    self:SetZoneLength(400)
    self:SetZoneWidth(400)
    self:SetZoneHeight(300)

    self._zoneCacheTick = -1
end

function ENT:Think()
    self:UpdateCapture()
    self:NextThink(CurTime() + 0.1)
    return true
end

function ENT:UpdateCapture()
    if GAMEMODE and GAMEMODE.CurrentGameMode == "operation" then
        local activeSector = GetGlobalInt("ActiveSector", 1)
        if self:GetSector() ~= activeSector then
            self:SetCapturingTeam(0)
            return
        end

        local attackTeam = GAMEMODE.MapConfig.operation_attack_team or TEAM_ALPHA
        if self:GetOwningTeam() == attackTeam then
            if #player.GetAll() <= 6 then
                self:SetCapturingTeam(0)
                return
            end
        end
    end

    local zoneType = self:GetZoneType()
    local dX, dY, height, radius, posZ
    local pos = self:GetPos()
    if zoneType == 1 then
        dX = self:GetZoneLength() * 0.5
        dY = self:GetZoneWidth()  * 0.5
        height = self:GetZoneHeight()
    elseif zoneType == 2 then
        height = self:GetZoneHeight()
        radius = self:GetZoneWidth()
        posZ   = pos.z
    else
        radius = self:GetZoneWidth()
    end

    local alphaCounts = 0
    local bravoCounts = 0

    local allPlayers = player.GetAll()
    local activePlayersCount = #allPlayers

    for i = 1, activePlayersCount do
        local ply = allPlayers[i]
        if IsValid(ply) and ply:Alive() then
            local t = ply:Team()
            if t == TEAM_ALPHA or t == TEAM_BRAVO then
                local inZone
                local plyPos = ply:GetPos()
                if zoneType == 1 then
                    local lp = self:WorldToLocal(plyPos)
                    inZone = lp.x >= -dX and lp.x <= dX
                        and lp.y >= -dY and lp.y <= dY
                        and lp.z >= 0   and lp.z <= height
                elseif zoneType == 2 then
                    local dz = plyPos.z - posZ
                    if dz >= 0 and dz <= height then
                        inZone = pos:Distance2D(plyPos) <= radius
                    else
                        inZone = false
                    end
                else
                    inZone = pos:Distance(plyPos) <= radius
                end

                if inZone then
                    if t == TEAM_ALPHA then
                        alphaCounts = alphaCounts + 1
                    else
                        bravoCounts = bravoCounts + 1
                    end
                end
            end
        end
    end

    local currentOwner = self:GetOwningTeam()
    local progress = self:GetCaptureProgress()

    if currentOwner == TEAM_ALPHA and bravoCounts > 0 then
        self:SetAttackUntil(CurTime() + (WARSES_CP_SPAWN_LOCK or 10))
    elseif currentOwner == TEAM_BRAVO and alphaCounts > 0 then
        self:SetAttackUntil(CurTime() + (WARSES_CP_SPAWN_LOCK or 10))
    end

    local captureTime = 40
    if activePlayersCount > 4 then
        captureTime = captureTime + math.floor((activePlayersCount - 4) / 2) * 5
    end

    local captureSpeed = 10 / captureTime

    if alphaCounts > 0 and bravoCounts == 0 then
        self:SetCapturingTeam(TEAM_ALPHA)

        if currentOwner == TEAM_ALPHA then
            if progress < 100 then
                progress = progress + (captureSpeed * alphaCounts)
                if progress > 100 then progress = 100 end
                self:SetCaptureProgress(progress)
                self:SetProgressTeam(TEAM_ALPHA)
            else
                self:SetCaptureProgress(100)
                self:SetProgressTeam(0)
            end
        elseif currentOwner == TEAM_BRAVO then
            progress = progress - (captureSpeed * alphaCounts)
            if progress <= 0 then
                progress = 0
                self:SetOwningTeam(0)
                self:SetProgressTeam(TEAM_ALPHA)
            end
            self:SetCaptureProgress(progress)
        else
            if self:GetProgressTeam() == TEAM_BRAVO and progress > 0 then
                progress = progress - (captureSpeed * alphaCounts)
                if progress <= 0 then
                    progress = 0
                    self:SetProgressTeam(TEAM_ALPHA)
                end
                self:SetCaptureProgress(progress)
            else
                self:SetProgressTeam(TEAM_ALPHA)
                progress = progress + (captureSpeed * alphaCounts)
                if progress >= 100 then
                    progress = 100
                    self:SetOwningTeam(TEAM_ALPHA)
                    self:SetProgressTeam(0)
                    self:OnCaptured(TEAM_ALPHA)
                end
                self:SetCaptureProgress(progress)
            end
        end

    elseif bravoCounts > 0 and alphaCounts == 0 then
        self:SetCapturingTeam(TEAM_BRAVO)

        if currentOwner == TEAM_BRAVO then
            if progress < 100 then
                progress = progress + (captureSpeed * bravoCounts)
                if progress > 100 then progress = 100 end
                self:SetCaptureProgress(progress)
                self:SetProgressTeam(TEAM_BRAVO)
            else
                self:SetCaptureProgress(100)
                self:SetProgressTeam(0)
            end
        elseif currentOwner == TEAM_ALPHA then
            progress = progress - (captureSpeed * bravoCounts)
            if progress <= 0 then
                progress = 0
                self:SetOwningTeam(0)
                self:SetProgressTeam(TEAM_BRAVO)
            end
            self:SetCaptureProgress(progress)
        else
            if self:GetProgressTeam() == TEAM_ALPHA and progress > 0 then
                progress = progress - (captureSpeed * bravoCounts)
                if progress <= 0 then
                    progress = 0
                    self:SetProgressTeam(TEAM_BRAVO)
                end
                self:SetCaptureProgress(progress)
            else
                self:SetProgressTeam(TEAM_BRAVO)
                progress = progress + (captureSpeed * bravoCounts)
                if progress >= 100 then
                    progress = 100
                    self:SetOwningTeam(TEAM_BRAVO)
                    self:SetProgressTeam(0)
                    self:OnCaptured(TEAM_BRAVO)
                end
                self:SetCaptureProgress(progress)
            end
        end

    elseif alphaCounts > 0 and bravoCounts > 0 then
        self:SetCapturingTeam(0)
    else
        self:SetCapturingTeam(0)
    end
end

function ENT:OnCaptured(teamID)
    local teamName = team.GetName(teamID)
    for _, ply in ipairs(player.GetAll()) do
        ply:ChatPrint("[WARSES] " .. teamName .. " captured " .. self:GetPointName() .. "!")
    end
end

function ENT:IsPlayerInZone(ply)
    local zoneType = self:GetZoneType()
    local pos = self:GetPos()
    local plyPos = ply:GetPos()

    if zoneType == 1 then
        local localPos = self:WorldToLocal(plyPos)
        local dX = self:GetZoneLength() / 2
        local dY = self:GetZoneWidth() / 2
        local height = self:GetZoneHeight()

        local xValid = localPos.x >= -dX and localPos.x <= dX
        local yValid = localPos.y >= -dY and localPos.y <= dY
        local zValid = localPos.z >= 0 and localPos.z <= height

        return xValid and yValid and zValid

    elseif zoneType == 2 then
        local height = self:GetZoneHeight()
        local radius = self:GetZoneWidth()

        local zDiff = plyPos.z - pos.z
        if zDiff < 0 or zDiff > height then return false end

        local dist2D = pos:Distance2D(plyPos)
        return dist2D <= radius

    else
        local radius = self:GetZoneWidth()
        return pos:Distance(plyPos) <= radius
    end
end
