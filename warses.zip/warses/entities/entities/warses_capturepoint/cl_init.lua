include("shared.lua")

surface.CreateFont("Warses_CP_Name",   {font = "Roboto", size = 64, weight = 900, antialias = true})
surface.CreateFont("Warses_CP_Status", {font = "Roboto", size = 28, weight = 600, antialias = true})
surface.CreateFont("Warses_CP_Ring",   {font = "Roboto", size = 44, weight = 900, antialias = true})
surface.CreateFont("Warses_CP_Pct",    {font = "Roboto", size = 18, weight = 700, antialias = true})
surface.CreateFont("Warses_CP_Hint",   {font = "Roboto", size = 14, weight = 600, antialias = true})
surface.CreateFont("Warses_CP_Dist",   {font = "Roboto", size = 26, weight = 700, antialias = true})

surface.CreateFont("Warses_CP_RoundName", {font = "Roboto", size = 56, weight = 900, antialias = true})
surface.CreateFont("Warses_CP_RoundDist", {font = "Roboto", size = 42, weight = 800, antialias = true})
surface.CreateFont("Warses_CP_RoundPct",  {font = "Roboto", size = 22, weight = 700, antialias = true})

local CP_UNITS_PER_METER = 39.37
local CP_MAX_DIST_METERS = 200
local CP_MAX_DIST_UNITS  = CP_MAX_DIST_METERS * CP_UNITS_PER_METER
local CP_MAX_DIST_UNITS2 = CP_MAX_DIST_UNITS * CP_MAX_DIST_UNITS

local surface          = surface
local draw             = draw
local math_cos         = math.cos
local math_sin         = math.sin
local math_pi          = math.pi
local math_pi2         = math.pi * 2
local math_pihalf      = math.pi / 2
local math_clamp       = math.Clamp
local math_round       = math.Round
local team_GetColor    = team.GetColor
local team_GetName     = team.GetName
local IsValid          = IsValid
local Lerp             = Lerp
local FrameTime        = FrameTime
local CurTime          = CurTime

local _ringPoly = {{x=0,y=0},{x=0,y=0},{x=0,y=0},{x=0,y=0}}
local _ringCS = {}
local function _getRingCS(segments)
    local e = _ringCS[segments]
    if e then return e end
    e = {}
    local startAng = -math_pihalf
    local step = math_pi2 / segments
    for i = 0, segments do
        local a = startAng + i * step
        e[i * 2 + 1] = math_cos(a)
        e[i * 2 + 2] = math_sin(a)
    end
    _ringCS[segments] = e
    return e
end

local function DrawRadialRing(cx, cy, outerR, innerR, progress, color, segments)
    segments = segments or 80
    progress = math_clamp(progress, 0, 1)
    if progress <= 0 then return end

    surface.SetDrawColor(color.r, color.g, color.b, color.a or 255)
    draw.NoTexture()

    local fullAngle = progress * math_pi2
    local startAng  = -math_pihalf
    local cs = _getRingCS(segments)
    local poly = _ringPoly
    local step = math_pi2 / segments

    for i = 0, segments - 1 do
        local a1 = i * step
        local a2 = (i + 1) * step
        if a1 > fullAngle then break end

        local c1 = cs[i * 2 + 1]
        local s1 = cs[i * 2 + 2]
        local c2, s2
        if a2 > fullAngle then
            local cap = startAng + fullAngle
            c2 = math_cos(cap)
            s2 = math_sin(cap)
        else
            c2 = cs[(i + 1) * 2 + 1]
            s2 = cs[(i + 1) * 2 + 2]
        end

        poly[1].x = cx + c1 * outerR; poly[1].y = cy + s1 * outerR
        poly[2].x = cx + c2 * outerR; poly[2].y = cy + s2 * outerR
        poly[3].x = cx + c2 * innerR; poly[3].y = cy + s2 * innerR
        poly[4].x = cx + c1 * innerR; poly[4].y = cy + s1 * innerR
        surface.DrawPoly(poly)
    end
end

local _circleTpl = {}
local _circleScratch = {}
local function _getCircleTpl(segments)
    local t = _circleTpl[segments]
    if t then return t end
    t = {}
    for i = 0, segments - 1 do
        local ang = (i / segments) * math_pi2
        t[i + 1] = { x = math_cos(ang), y = math_sin(ang) }
    end
    _circleTpl[segments] = t
    return t
end
local function _getCircleScratch(segments)
    local s = _circleScratch[segments]
    if s then return s end
    s = {}
    for i = 1, segments do s[i] = { x = 0, y = 0 } end
    _circleScratch[segments] = s
    return s
end

local function DrawFilledCircle(cx, cy, r, color, segments)
    segments = segments or 64
    surface.SetDrawColor(color.r, color.g, color.b, color.a or 255)
    draw.NoTexture()
    local tpl = _getCircleTpl(segments)
    local sc = _getCircleScratch(segments)
    for i = 1, segments do
        local t = tpl[i]; local s = sc[i]
        s.x = cx + t.x * r
        s.y = cy + t.y * r
    end
    surface.DrawPoly(sc)
end

local _CV_ShowSpawn
local function _getShowSpawnCV()
    if not _CV_ShowSpawn then _CV_ShowSpawn = GetConVar("warses_show_spawn") end
    return _CV_ShowSpawn
end

local _C_WIRE   = Color(0, 255, 0, 255)
local _C_BASE_OUT = Color(0, 0, 0, 200)
local _C_BASE_IN  = Color(30, 32, 40, 230)
local _C_BAR      = Color(160, 160, 160, 255)
local _C_PULSE    = Color(0, 0, 0, 0)
local _C_INNER    = Color(12, 14, 20, 235)
local _C_NAME     = Color(255, 255, 255, 255)
local _C_DIST     = Color(220, 230, 245, 255)
local _C_PCT      = Color(0, 0, 0, 0)
local _C_STATUS   = Color(0, 0, 0, 0)
local _ANG_TMP    = Angle(0, 0, 90)

function ENT:IsPlayerInZone(ply)
    if GAMEMODE and GAMEMODE.CurrentGameMode == "operation" then
        if self.GetSector and self:GetSector() ~= GetGlobalInt("ActiveSector", 1) then
            return false
        end
    end

    local zoneType = self:GetZoneType()
    local pos      = self:GetPos()
    local plyPos   = ply:GetPos()

    local widthVal = self:GetZoneWidth()
    local lenVal   = (zoneType == 1) and self:GetZoneLength() or widthVal
    local hVal     = (zoneType ~= 0) and self:GetZoneHeight() or 0
    local maxExt2  = widthVal * widthVal + lenVal * lenVal + hVal * hVal
    if pos:DistToSqr(plyPos) > maxExt2 then return false end

    if zoneType == 1 then
        local localPos = self:WorldToLocal(plyPos)
        local dX = lenVal * 0.5
        local dY = widthVal * 0.5
        return localPos.x >= -dX and localPos.x <= dX
            and localPos.y >= -dY and localPos.y <= dY
            and localPos.z >= 0   and localPos.z <= hVal
    elseif zoneType == 2 then
        local zDiff = plyPos.z - pos.z
        if zDiff < 0 or zDiff > hVal then return false end
        return pos:Distance2D(plyPos) <= widthVal
    else
        return pos:Distance(plyPos) <= widthVal
    end
end

function ENT:GetTopZonePos()
    local zoneType = self:GetZoneType()
    if zoneType == 0 then
        return self:GetPos() + Vector(0, 0, self:GetZoneWidth())
    end
    return self:LocalToWorld(Vector(0, 0, self:GetZoneHeight()))
end

function ENT:Draw()
    if GAMEMODE and GAMEMODE.CurrentGameMode == "operation" then
        if self.GetSector and self:GetSector() ~= GetGlobalInt("ActiveSector", 1) then
            return
        end
    end

    self:DrawModel()

    local zoneType  = self:GetZoneType()
    local capturing = self:GetCapturingTeam()
    local owner     = self:GetOwningTeam()

    local showZonesCV = _getShowSpawnCV()
    local showZones   = showZonesCV and showZonesCV:GetBool() or false

    if showZones then
        local cr, cg, cb = 0, 255, 0
        if capturing > 0 then
            local c = team_GetColor(capturing); cr, cg, cb = c.r, c.g, c.b
        elseif owner > 0 then
            local c = team_GetColor(owner); cr, cg, cb = c.r, c.g, c.b
        end
        local pulse = 180 + 75 * math_sin(CurTime() * 2)
        _C_WIRE.r, _C_WIRE.g, _C_WIRE.b, _C_WIRE.a = cr, cg, cb, pulse

        if zoneType == 1 then
            local len    = self:GetZoneLength() * 0.5
            local wid    = self:GetZoneWidth()  * 0.5
            local height = self:GetZoneHeight()
            render.DrawWireframeBox(self:GetPos(), self:GetAngles(),
                Vector(-len, -wid, 0), Vector(len, wid, height), _C_WIRE, true)
        elseif zoneType == 0 then
            render.DrawWireframeSphere(self:GetPos(), self:GetZoneWidth(), 10, 10, _C_WIRE, true)
        elseif zoneType == 2 then
            local height = self:GetZoneHeight()
            local radius = self:GetZoneWidth()
            local pos    = self:GetPos()
            local up     = self:GetUp()
            local right  = self:GetRight()
            local fwd    = self:GetForward()
            local segments = 16
            for i = 1, segments do
                local ang  = (i     / segments) * math_pi2
                local angN = ((i+1) / segments) * math_pi2
                local b1 = pos + (right * math_cos(ang)  * radius) + (fwd * math_sin(ang)  * radius)
                local b2 = pos + (right * math_cos(angN) * radius) + (fwd * math_sin(angN) * radius)
                render.DrawLine(b1, b2, _C_WIRE, true)
                local t1, t2 = b1 + up * height, b2 + up * height
                render.DrawLine(t1, t2, _C_WIRE, true)
                if i % 4 == 0 then render.DrawLine(b1, t1, _C_WIRE, true) end
            end
        end
    end

    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local markerPos = self:GetTopZonePos()
    markerPos = Vector(markerPos.x, markerPos.y, markerPos.z + 20)

    local d2 = ply:EyePos():DistToSqr(markerPos)
    if d2 > CP_MAX_DIST_UNITS2 then return end

    local distUnits  = math.sqrt(d2)
    local t          = math_clamp(distUnits / CP_MAX_DIST_UNITS, 0, 1)
    local scale      = Lerp(t, 0.15, 1.5)
    local alphaMul   = Lerp(t, 1.0, 0.28)
    local distMeters = math_round(distUnits / CP_UNITS_PER_METER)

    _ANG_TMP.p = 0
    _ANG_TMP.y = ply:EyeAngles().y - 90
    _ANG_TMP.r = 90

    local progress      = self:GetCaptureProgress()
    local progressTeam  = self:GetProgressTeam()
    local progressOwner = owner > 0 and owner or progressTeam

    self.cpSmooth = Lerp(FrameTime() * 4, self.cpSmooth or 0, progress / 100)

    local br, bg, bb = 160, 160, 160
    if progressOwner == TEAM_ALPHA then
        local c = team_GetColor(TEAM_ALPHA); br, bg, bb = c.r, c.g, c.b
    elseif progressOwner == TEAM_BRAVO then
        local c = team_GetColor(TEAM_BRAVO); br, bg, bb = c.r, c.g, c.b
    end

    local statusText = "Нейтрально"
    local sr, sg, sb = 180, 180, 180
    if owner == TEAM_ALPHA and capturing == 0 then
        statusText = team_GetName(TEAM_ALPHA)
        local c = team_GetColor(TEAM_ALPHA); sr, sg, sb = c.r, c.g, c.b
    elseif owner == TEAM_BRAVO and capturing == 0 then
        statusText = team_GetName(TEAM_BRAVO)
        local c = team_GetColor(TEAM_BRAVO); sr, sg, sb = c.r, c.g, c.b
    elseif capturing > 0 then
        statusText = (progressOwner > 0 and progressOwner ~= capturing)
            and "НЕЙТРАЛИЗАЦИЯ" or "ЗАХВАТ"
        local c = team_GetColor(capturing); sr, sg, sb = c.r, c.g, c.b
    end

    local a = alphaMul
    local outerR = 150
    local innerR = 118

    _C_BASE_OUT.a = 200 * a
    _C_BASE_IN.a  = 230 * a
    _C_BAR.r, _C_BAR.g, _C_BAR.b = br, bg, bb
    _C_BAR.a = 245 * a
    _C_INNER.a = 235 * a
    _C_NAME.a  = 255 * a
    _C_DIST.a  = 255 * a
    _C_PCT.r, _C_PCT.g, _C_PCT.b = br, bg, bb
    _C_PCT.a = 240 * a
    _C_STATUS.r, _C_STATUS.g, _C_STATUS.b = sr, sg, sb
    _C_STATUS.a = 255 * a

    cam.IgnoreZ(true)
    cam.Start3D2D(markerPos, _ANG_TMP, scale)
        DrawRadialRing(0, 0, outerR, innerR, 1, _C_BASE_OUT, 72)
        DrawRadialRing(0, 0, outerR - 2, innerR + 2, 1, _C_BASE_IN, 72)
        DrawRadialRing(0, 0, outerR - 2, innerR + 2, self.cpSmooth, _C_BAR, 80)

        if capturing > 0 then
            local pulse = 0.5 + 0.5 * math_sin(CurTime() * 6)
            local c = team_GetColor(capturing)
            _C_PULSE.r, _C_PULSE.g, _C_PULSE.b = c.r, c.g, c.b
            _C_PULSE.a = 200 * pulse * a
            DrawRadialRing(0, 0, outerR + 10, outerR, 1, _C_PULSE, 72)
        end

        DrawFilledCircle(0, 0, innerR + 2, _C_INNER, 64)

        draw.SimpleText(self:GetPointName(), "Warses_CP_RoundName", 0, -54,
            _C_NAME, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText(distMeters .. " м", "Warses_CP_RoundDist", 0, 0,
            _C_DIST, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        local pct = math_round(progress) .. "%"
        draw.SimpleText(pct, "Warses_CP_RoundPct", 0, 50,
            _C_PCT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        draw.SimpleText(statusText, "Warses_CP_Status", 0, outerR + 30,
            _C_STATUS, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    cam.End3D2D()
    cam.IgnoreZ(false)
end

hook.Remove("HUDPaint", "Warses_CapturePointHUD")
