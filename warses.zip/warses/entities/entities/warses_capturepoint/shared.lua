ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Capture Point"
ENT.Author = "Warses Team"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.Category = "Warses"

function ENT:SetupDataTables()
    self:NetworkVar("Float", 0, "CaptureProgress")
    self:NetworkVar("Int", 0, "OwningTeam")
    self:NetworkVar("Int", 1, "CapturingTeam")
    self:NetworkVar("String", 0, "PointName")

    self:NetworkVar("Int", 2, "ZoneType")
    self:NetworkVar("Float", 1, "ZoneHeight")
    self:NetworkVar("Float", 2, "ZoneLength")
    self:NetworkVar("Float", 3, "ZoneWidth")

    self:NetworkVar("Int", 3, "ProgressTeam")

    self:NetworkVar("Int", 4, "Sector")

    self:NetworkVar("Float", 4, "AttackUntil")
end

WARSES_CP_SPAWN_LOCK = 10
