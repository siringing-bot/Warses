ENT.Type      = "anim"
ENT.Base      = "base_gmodentity"
ENT.PrintName = "Gravity Zone"
ENT.Author    = "Warses Team"
ENT.Spawnable = false
ENT.AdminOnly = true
ENT.Category  = "Warses"

function ENT:SetupDataTables()
    self:NetworkVar("Int",   0, "ZoneType")
    self:NetworkVar("Float", 0, "ZoneHeight")
    self:NetworkVar("Float", 1, "ZoneLength")
    self:NetworkVar("Float", 2, "ZoneWidth")
end

function ENT:IsPlayerInZone(ply)
    if not IsValid(ply) then return false end
    local zoneType = self:GetZoneType()
    local pos      = self:GetPos()
    local plyPos   = ply:GetPos()

    if zoneType == 1 then
        local localPos = self:WorldToLocal(plyPos)
        local dX     = self:GetZoneLength() / 2
        local dY     = self:GetZoneWidth()  / 2
        local height = self:GetZoneHeight()

        local xValid = localPos.x >= -dX and localPos.x <= dX
        local yValid = localPos.y >= -dY and localPos.y <= dY
        local zValid = localPos.z >= 0   and localPos.z <= height
        return xValid and yValid and zValid

    elseif zoneType == 2 then
        local height = self:GetZoneHeight()
        local radius = self:GetZoneWidth()

        local zDiff = plyPos.z - pos.z
        if zDiff < 0 or zDiff > height then return false end

        return pos:Distance2D(plyPos) <= radius

    else
        local radius = self:GetZoneWidth()
        return pos:Distance(plyPos) <= radius
    end
end
