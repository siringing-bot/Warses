AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
    self:SetModel("models/props_c17/gravestone003a.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_VPHYSICS)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:EnableMotion(false)
    end

    self:SetTrigger(true)

    self:SetZoneType(1)
    self:SetZoneLength(800)
    self:SetZoneWidth(800)
    self:SetZoneHeight(500)

    self:SetNoDraw(true)

    self.InZoneTimers = {}
end

function ENT:Think()
    self:CheckPlayersInZone()
    self:NextThink(CurTime() + 0.5)
    return true
end

function ENT:CheckPlayersInZone()
    local ownerTeam = self:GetOwningTeam()

    local zoneType = self:GetZoneType()
    local pos      = self:GetPos()
    local zLen, zWid, zHeight
    if zoneType == 1 then
        zLen    = self:GetZoneLength() * 0.5
        zWid    = self:GetZoneWidth()  * 0.5
        zHeight = self:GetZoneHeight()
    elseif zoneType == 2 then
        zWid    = self:GetZoneWidth()
        zHeight = self:GetZoneHeight()
    else
        zWid    = self:GetZoneWidth()
    end

    local currentPlayers = {}
    self._lastSent = self._lastSent or {}
    local lastSent = self._lastSent

    local plys = player.GetAll()
    for i = 1, #plys do
        local ply = plys[i]
        if IsValid(ply) and ply:Alive() and ply:Team() ~= TEAM_SPECTATOR then
            local sid = ply:SteamID()
            local inZone = false
            if ply:Team() ~= ownerTeam then
                local plyPos = ply:GetPos()
                if zoneType == 1 then
                    local lp = self:WorldToLocal(plyPos)
                    inZone = lp.x >= -zLen and lp.x <= zLen
                        and lp.y >= -zWid and lp.y <= zWid
                        and lp.z >= 0    and lp.z <= zHeight
                elseif zoneType == 2 then
                    local dz = plyPos.z - pos.z
                    if dz >= 0 and dz <= zHeight then
                        inZone = pos:Distance2D(plyPos) <= zWid
                    end
                else
                    inZone = pos:Distance(plyPos) <= zWid
                end
            end

            if inZone then
                currentPlayers[sid] = true
                local left
                if not self.InZoneTimers[sid] then
                    left = 10
                else
                    left = math.max(0, self.InZoneTimers[sid] - 0.5)
                end
                self.InZoneTimers[sid] = left

                local timeLeft = math.ceil(left)
                if lastSent[sid] ~= timeLeft then
                    lastSent[sid] = timeLeft
                    net.Start("Warses_BaseAlert")
                    net.WriteInt(timeLeft, 8)
                    net.Send(ply)
                end

                if left <= 0 then
                    ply:Kill()
                    self.InZoneTimers[sid] = nil
                    lastSent[sid] = nil
                end
            else
                if self.InZoneTimers[sid] then
                    self.InZoneTimers[sid] = nil
                    lastSent[sid] = nil
                    net.Start("Warses_BaseAlert")
                    net.WriteInt(-1, 8)
                    net.Send(ply)
                end
            end
        end
    end

    for sid in pairs(self.InZoneTimers) do
        if not currentPlayers[sid] then
            self.InZoneTimers[sid] = nil
            lastSent[sid] = nil
        end
    end
end

function ENT:IsPlayerInZone(ply)
    local zoneType = self:GetZoneType()
    local pos = self:GetPos()
    local plyPos = ply:GetPos()

    if zoneType == 1 then
        local localPos = self:WorldToLocal(plyPos)
        local dX = self:GetZoneLength() / 2
        local dY = self:GetZoneWidth() / 2
        local height = self:GetZoneHeight()

        local xValid = localPos.x >= -dX and localPos.x <= dX
        local yValid = localPos.y >= -dY and localPos.y <= dY
        local zValid = localPos.z >= 0 and localPos.z <= height

        return xValid and yValid and zValid

    elseif zoneType == 2 then
        local height = self:GetZoneHeight()
        local radius = self:GetZoneWidth()

        local zDiff = plyPos.z - pos.z
        if zDiff < 0 or zDiff > height then return false end

        local dist2D = pos:Distance2D(plyPos)
        return dist2D <= radius

    else
        local radius = self:GetZoneWidth()
        return pos:Distance(plyPos) <= radius
    end
end
