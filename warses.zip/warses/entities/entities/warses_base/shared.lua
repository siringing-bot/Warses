ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Base Protection"
ENT.Author = "Warses Team"
ENT.Spawnable = false
ENT.AdminOnly = true
ENT.Category = "Warses"

function ENT:SetupDataTables()
    self:NetworkVar("Int", 0, "OwningTeam")

    self:NetworkVar("Int", 1, "ZoneType")
    self:NetworkVar("Float", 0, "ZoneHeight")
    self:NetworkVar("Float", 1, "ZoneLength")
    self:NetworkVar("Float", 2, "ZoneWidth")
end
