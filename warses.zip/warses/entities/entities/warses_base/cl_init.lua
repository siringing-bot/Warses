include("shared.lua")

function ENT:Draw()
    if not LocalPlayer():IsSuperAdmin() then return end
    local cv = GetConVar("warses_show_spawn")
    if not cv or not cv:GetBool() then return end

    local zoneType = self:GetZoneType()
    local pos = self:GetPos()
    local length = self:GetZoneLength()
    local width = self:GetZoneWidth()
    local height = self:GetZoneHeight()

    local color = self:GetOwningTeam() == TEAM_ALPHA
        and Color(0, 0, 255, 100)
        or Color(255, 0, 0, 100)

    render.SetColorMaterial()

    if zoneType == 1 then
        render.DrawBox(pos, self:GetAngles(),
            Vector(-length/2, -width/2, 0), Vector(length/2, width/2, height), color)
    elseif zoneType == 2 then
        render.DrawWireframeBox(pos, Angle(0, 0, 0),
            Vector(-width, -width, 0), Vector(width, width, height), color, true)
    else
        render.DrawSphere(pos, width, 20, 20, color)
    end

    local ang = Angle(0, LocalPlayer():EyeAngles().y - 90, 90)
    cam.Start3D2D(pos + Vector(0, 0, height + 20), ang, 0.1)
        draw.SimpleText("BASE · " .. team.GetName(self:GetOwningTeam()),
            "DermaDefaultBold", 0, 0,
            Color(color.r, color.g, color.b, 255),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    cam.End3D2D()
end

net.Receive("Warses_BaseAlert", function()
    local timeLeft = net.ReadInt(8)

    if timeLeft == -1 then
        hook.Remove("HUDPaint", "Warses_BaseAlertDisplay")
    else
        hook.Add("HUDPaint", "Warses_BaseAlertDisplay", function()
            local screenW = ScrW()
            local screenH = ScrH()

            draw.SimpleText("Вы покидаете зону боя", "DermaLarge",
                screenW / 2, screenH / 3, Color(255, 0, 0, 255),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText(tostring(timeLeft), "DermaLarge",
                screenW / 2, screenH / 3 + 40,
                Color(255, 0, 0, 255 * (math.sin(CurTime() * 10) * 0.5 + 0.5)),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end)
    end
end)
