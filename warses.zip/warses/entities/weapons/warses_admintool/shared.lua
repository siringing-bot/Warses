AddCSLuaFile()

if SERVER then
    util.AddNetworkString("WarsesAdmin_Place")
    util.AddNetworkString("WarsesAdmin_Remove")
    util.AddNetworkString("WarsesAdmin_ConfigZone")
    util.AddNetworkString("WarsesAdmin_SetAttackTeam")
    util.AddNetworkString("WarsesAdmin_Save")
    util.AddNetworkString("WarsesAdmin_Load")
    util.AddNetworkString("WarsesAdmin_Clear")
    util.AddNetworkString("WarsesAdmin_RemoveSpawnAt")
    util.AddNetworkString("WarsesAdmin_GetSpawns")
    util.AddNetworkString("WarsesAdmin_SpawnsList")
    util.AddNetworkString("WarsesAdmin_OpenMenu")
    util.AddNetworkString("WarsesAdmin_PlaceGravityZone")
end

SWEP.PrintName        = "Warses Admin Tool"
SWEP.Author           = "Warses"
SWEP.Purpose          = "Размещение точек, баз, спаунов и транспорта"
SWEP.Instructions     = "ЛКМ — поставить · ПКМ — меню · R — удалить"
SWEP.Category         = "Warses"

SWEP.Spawnable        = true
SWEP.AdminOnly        = true
SWEP.Slot             = 5
SWEP.SlotPos          = 0

SWEP.UseHands         = false
SWEP.HoldType         = "pistol"
SWEP.ViewModel        = "models/weapons/c_toolgun.mdl"
SWEP.WorldModel       = "models/weapons/w_toolgun.mdl"
SWEP.ViewModelFlip    = false
SWEP.DrawCrosshair    = true
SWEP.DrawAmmo         = false

SWEP.Primary.ClipSize     = -1
SWEP.Primary.DefaultClip  = -1
SWEP.Primary.Automatic    = false
SWEP.Primary.Ammo         = "none"

SWEP.Secondary.ClipSize     = -1
SWEP.Secondary.DefaultClip  = -1
SWEP.Secondary.Automatic    = false
SWEP.Secondary.Ammo         = "none"

function SWEP:Initialize()
    self:SetHoldType(self.HoldType)
end

function SWEP:Deploy()
    if CLIENT then
        chat.AddText(Color(255, 200, 60), "[Warses] ",
            color_white, "ЛКМ — поставить · ПКМ — меню · R — удалить")
    end
    return true
end

function SWEP:Holster() return true end

function SWEP:Think() end

function SWEP:PrimaryAttack()
    if (self.nextPrimary or 0) > CurTime() then return end
    self.nextPrimary = CurTime() + 0.25

    self:SendWeaponAnim(ACT_VM_PRIMARYATTACK)

    if SERVER then return end
    local ply = LocalPlayer()
    if not ply:IsSuperAdmin() then return end

    WarsesAdminTool = WarsesAdminTool or {}
    if not WarsesAdminTool.mode then
        chat.AddText(Color(255, 100, 100),
            "[Warses] Откройте меню (ПКМ) и выберите инструмент.")
        return
    end

    local tr = ply:GetEyeTrace()

    if WarsesAdminTool.mode == "gravity_zone" then
        if not WarsesAdminTool.gravityFirstPoint then
            WarsesAdminTool.gravityFirstPoint = tr.HitPos
            chat.AddText(Color(120, 220, 120), "[Warses] ",
                color_white,
                "Первая точка отмечена. ЛКМ — отметить вторую (R — сбросить).")
            surface.PlaySound("buttons/button14.wav")
            return
        end

        local p1 = WarsesAdminTool.gravityFirstPoint
        local p2 = tr.HitPos
        WarsesAdminTool.gravityFirstPoint = nil

        net.Start("WarsesAdmin_PlaceGravityZone")
        net.WriteVector(p1)
        net.WriteVector(p2)
        net.SendToServer()

        chat.AddText(Color(120, 220, 120), "[Warses] ",
            color_white, "Зона гравитации создана.")
        surface.PlaySound("buttons/button14.wav")
        return
    end

    local ang = ply:EyeAngles()
    ang.p = 0
    ang.r = 0

    net.Start("WarsesAdmin_Place")
    net.WriteString(WarsesAdminTool.mode)
    net.WriteVector(tr.HitPos)
    net.WriteAngle(ang)
    net.WriteTable(WarsesAdminTool.params or {})
    net.WriteEntity(tr.Entity or NULL)
    net.SendToServer()

    surface.PlaySound("buttons/button14.wav")
end

function SWEP:SecondaryAttack()
    if (self.nextSecondary or 0) > CurTime() then return end
    self.nextSecondary = CurTime() + 0.4

    if SERVER then return end
    if not LocalPlayer():IsSuperAdmin() then return end

    if OpenWarsesAdminMenu then OpenWarsesAdminMenu() end
end

function SWEP:Reload()
    if (self.nextReload or 0) > CurTime() then return end
    self.nextReload = CurTime() + 0.3

    if SERVER then return end
    if not LocalPlayer():IsSuperAdmin() then return end

    WarsesAdminTool = WarsesAdminTool or {}
    if WarsesAdminTool.mode == "gravity_zone" and WarsesAdminTool.gravityFirstPoint then
        WarsesAdminTool.gravityFirstPoint = nil
        chat.AddText(Color(255, 200, 60), "[Warses] ",
            color_white, "Первая точка зоны гравитации сброшена.")
        surface.PlaySound("buttons/button15.wav")
        return
    end

    local tr = LocalPlayer():GetEyeTrace()

    if IsValid(tr.Entity) then
        local cls = tr.Entity:GetClass()
        if cls == "warses_capturepoint"
            or cls == "warses_base"
            or cls == "warses_vehicle_spawn" then

            net.Start("WarsesAdmin_Remove")
            net.WriteEntity(tr.Entity)
            net.SendToServer()
            surface.PlaySound("buttons/button15.wav")
            return
        end
    end

    net.Start("WarsesAdmin_RemoveSpawnAt")
    net.WriteVector(tr.HitPos)
    net.SendToServer()
    surface.PlaySound("buttons/button15.wav")
end
