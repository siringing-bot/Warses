local MapVoteFrame = nil
local VoteEndTime  = 0

function Warses_CloseMapVoteUI()
    if IsValid(MapVoteFrame) then
        MapVoteFrame:Remove()
        MapVoteFrame = nil
    end
end

local EraVotes     = {}
local CurrentVotes = {}
local Phase2Votes  = {}
local Phase3Votes  = {}

local EraList      = {}
local ConflictList = {}
local Phase2Maps   = {}
local Phase3Modes  = {}
local SelectedConflictName = ""
local SelectedMapForPhase3 = ""

surface.CreateFont("VoteTitle", {
    font = "Roboto", size = 84, weight = 900, antialias = true, shadow = true
})
surface.CreateFont("VoteSubtitle", {
    font = "Roboto", size = 30, weight = 600, antialias = true
})
surface.CreateFont("VoteMapName", {
    font = "Roboto", size = 24, weight = 600, antialias = true
})
surface.CreateFont("VoteTimer", {
    font = "Roboto", size = 70, weight = 900, antialias = true
})
surface.CreateFont("VoteDesc", {
    font = "Roboto", size = 16, weight = 400, antialias = true
})
surface.CreateFont("VoteBig", {
    font = "Roboto", size = 36, weight = 800, antialias = true
})
surface.CreateFont("VoteSmall", {
    font = "Roboto", size = 13, weight = 500, antialias = true
})
surface.CreateFont("VoteEraName", {
    font = "Roboto", size = 40, weight = 900, antialias = true, shadow = true
})
surface.CreateFont("VoteEraPeriod", {
    font = "Roboto", size = 17, weight = 600, antialias = true
})
surface.CreateFont("VoteEraMeta", {
    font = "Roboto", size = 14, weight = 500, antialias = true
})

local function CountVotes(tbl, key)
    local n = 0
    for _, v in pairs(tbl) do if v == key then n = n + 1 end end
    return n
end

local function TotalVotes(tbl)
    local n = 0
    for _ in pairs(tbl) do n = n + 1 end
    return n
end

local eraPalette = {
    civilwar = {bg = Color(60, 40, 30),  accent = Color(220, 150, 80),  title = Color(255, 200, 140)},
    ww2      = {bg = Color(50, 50, 35),  accent = Color(200, 180, 80),  title = Color(255, 230, 130)},
    coldwar  = {bg = Color(60, 35, 35),  accent = Color(220, 90, 90),   title = Color(255, 130, 130)},
    modern   = {bg = Color(35, 45, 70),  accent = Color(90, 140, 230),  title = Color(140, 180, 255)},
    halflife = {bg = Color(45, 60, 30),  accent = Color(170, 220, 70),  title = Color(200, 255, 120)},
    spacewar = {bg = Color(35, 30, 65),  accent = Color(160, 110, 230), title = Color(200, 160, 255)},
}
local conflictColors = {
    coldwar  = {bg = Color(70, 35, 35), accent = Color(220, 90, 90),  title = Color(255, 130, 130)},
    ww2      = {bg = Color(55, 55, 35), accent = Color(200, 180, 80), title = Color(255, 230, 130)},
    modern   = {bg = Color(35, 40, 70), accent = Color(90, 130, 220), title = Color(130, 160, 255)},
    civilwar = {bg = Color(55, 35, 30), accent = Color(210, 130, 70), title = Color(255, 190, 150)},
    halflife = {bg = Color(45, 60, 30), accent = Color(170, 220, 70), title = Color(200, 255, 120)},
    spacewar = {bg = Color(35, 30, 65), accent = Color(160, 110, 230),title = Color(200, 160, 255)},
}
local defaultColors = {bg = Color(40, 42, 50), accent = Color(160, 160, 160), title = Color(220, 220, 220)}

local function MakeBaseFrame()
    if IsValid(MapVoteFrame) then MapVoteFrame:Remove() end

    local f = vgui.Create("DFrame")
    MapVoteFrame = f
    f:SetSize(ScrW(), ScrH())
    f:SetPos(0, 0)
    f:SetTitle("")
    f:ShowCloseButton(false)
    f:SetDraggable(false)
    f:MakePopup()
    f:SetKeyboardInputEnabled(false)

    f.start  = SysTime()
    f.appear = 0
    f.Think = function(self)
        self.appear = math.Clamp((SysTime() - self.start) * 1.6, 0, 1)
        self.appear = 1 - math.pow(1 - self.appear, 3)
    end

    return f
end

local function DrawBackdrop(w, h, a, accent)
    accent = accent or Color(190, 35, 40)

    surface.SetDrawColor(8, 9, 14, 240 * a)
    surface.DrawRect(0, 0, w, h)

    surface.SetDrawColor(accent.r, accent.g, accent.b, 12 * a)
    local off = (CurTime() * 18) % 40
    for x = -40, w, 40 do
        surface.DrawRect(x + off, 0, 1, h)
    end

    local barH = 6 * a
    surface.SetDrawColor(accent.r, accent.g, accent.b, 235 * a)
    surface.DrawRect(0, 0, w, barH)

    surface.SetDrawColor(accent.r, accent.g, accent.b, 235 * a)
    surface.DrawRect(0, h - barH, w, barH)
end

local function DrawTimer(w, h, a)
    local timeLeft = math.max(0, math.ceil(VoteEndTime - CurTime()))
    local col = timeLeft <= 5 and Color(255, 70, 70) or Color(255, 255, 255)

    local cx, cy = w / 2, h - 80
    draw.SimpleText(tostring(timeLeft), "VoteTimer",
        cx, cy,
        Color(col.r, col.g, col.b, 255 * a),
        TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

local function HoverAnimate(btn)
    btn.hover  = 0
    btn.appear = 0
    btn.start  = SysTime() + (btn.indexDelay or 0)
    btn.Think = function(self)
        local t = math.Clamp((SysTime() - self.start) * 2.0, 0, 1)
        self.appear = 1 - math.pow(1 - t, 3)
        self.hover  = Lerp(FrameTime() * 8, self.hover, self:IsHovered() and 1 or 0)
    end
end

net.Receive("MapVote_Era", function()
    local duration = net.ReadUInt(8)
    VoteEndTime = CurTime() + duration
    EraList = net.ReadTable()
    EraVotes = {}
    OpenEraVoteMenu()
end)

net.Receive("MapVote_EraUpdate", function()
    EraVotes = net.ReadTable()
end)

function OpenEraVoteMenu()
    local f = MakeBaseFrame()
    f.titleAccent = Color(220, 55, 55)

    f.Paint = function(self, w, h)
        local a = self.appear
        DrawBackdrop(w, h, a, self.titleAccent)

        draw.SimpleText("ВЫБЕРИ ЭПОХУ", "VoteTitle",
            w / 2, h * 0.07,
            Color(self.titleAccent.r, self.titleAccent.g, self.titleAccent.b, 255 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        draw.SimpleText("Временной промежуток определяет конфликты", "VoteSubtitle",
            w / 2, h * 0.07 + 88,
            Color(220, 220, 220, 200 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

        DrawTimer(w, h, a)
    end

    local container = vgui.Create("DPanel", f)
    local n = #EraList
    local cols = math.min(n, 3)
    local gap = 18
    local panelW = math.min(ScrW() * 0.86, 1240)
    local cardW = (panelW - (cols + 1) * gap) / cols
    local cardH = 220
    local rows = math.ceil(n / cols)
    local panelH = rows * (cardH + gap) + gap

    container:SetSize(panelW, panelH)
    container:SetPos((ScrW() - panelW) / 2, ScrH() * 0.22)
    container.Paint = function() end

    for i, entry in ipairs(EraList) do
        local row = math.floor((i - 1) / cols)
        local col = (i - 1) % cols
        local x = gap + col * (cardW + gap)
        local y = gap + row * (cardH + gap)

        local pal = eraPalette[entry.eraID] or defaultColors

        local card = vgui.Create("DButton", container)
        card:SetPos(x, y)
        card:SetSize(cardW, cardH)
        card:SetText("")
        card.indexDelay = i * 0.05
        HoverAnimate(card)

        card.Paint = function(self, pw, ph)
            local a = self.appear * f.appear
            if a <= 0 then return end
            local hov = self.hover

            local votes = CountVotes(EraVotes, entry.eraID)
            local total = TotalVotes(EraVotes)
            local frac  = total > 0 and votes / total or 0

            local myID = LocalPlayer():SteamID()
            local mine = (EraVotes[myID] == entry.eraID)

            local yOff = (1 - a) * 50
            local ox, oy = 0, yOff

            surface.SetDrawColor(0, 0, 0, 100 * a)
            surface.DrawRect(ox + 5, oy + 7, pw, ph)

            local r = math.floor(Lerp(hov, pal.bg.r, pal.bg.r + 30))
            local g = math.floor(Lerp(hov, pal.bg.g, pal.bg.g + 30))
            local b = math.floor(Lerp(hov, pal.bg.b, pal.bg.b + 30))
            surface.SetDrawColor(r, g, b, 240 * a)
            surface.DrawRect(ox, oy, pw, ph)

            surface.SetDrawColor(pal.accent.r, pal.accent.g, pal.accent.b, 30 * a)
            local stripeW = pw * 0.35
            for sx = 0, pw, 1 do
                local alpha = (1 - (sx / pw)) * 12 * a
                if alpha > 0 then
                    surface.SetDrawColor(pal.accent.r, pal.accent.g, pal.accent.b, alpha)
                    surface.DrawRect(ox + sx, oy, 1, ph)
                end
            end

            surface.SetDrawColor(pal.accent.r, pal.accent.g, pal.accent.b, 255 * a)
            surface.DrawRect(ox, oy, pw, 4)

            local lbarW = Lerp(hov, 4, 10)
            surface.SetDrawColor(pal.accent.r, pal.accent.g, pal.accent.b, 255 * a)
            surface.DrawRect(ox, oy + 4, lbarW, ph - 4)

            if mine then
                local pulse = 0.6 + 0.4 * math.sin(CurTime() * 5)
                surface.SetDrawColor(120, 255, 140, 220 * pulse * a)
                surface.DrawOutlinedRect(ox, oy, pw, ph, 3)
            elseif hov > 0.05 then
                surface.SetDrawColor(255, 255, 255, 110 * hov * a)
                surface.DrawOutlinedRect(ox, oy, pw, ph, 1)
            end

            draw.SimpleText(string.upper(entry.name), "VoteEraName",
                ox + pw / 2, oy + 30,
                Color(pal.title.r, pal.title.g, pal.title.b, 255 * a),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

            draw.SimpleText(entry.period or "", "VoteEraPeriod",
                ox + pw / 2, oy + 80,
                Color(pal.accent.r, pal.accent.g, pal.accent.b, 230 * a),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

            draw.SimpleText(entry.description or "", "VoteDesc",
                ox + pw / 2, oy + 110,
                Color(210, 210, 210, 230 * a),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

            surface.SetDrawColor(pal.accent.r, pal.accent.g, pal.accent.b, 70 * a)
            surface.DrawRect(ox + 30, oy + ph - 78, pw - 60, 1)

            local meta = (entry.subCount or 0) .. " конфликт(ов) · "
                      .. (entry.mapCount or 0) .. " карт(ы)"
            draw.SimpleText(meta, "VoteEraMeta",
                ox + pw / 2, oy + ph - 70,
                Color(160, 160, 170, 220 * a),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

            local barX, barY = ox + 24, oy + ph - 40
            local barW, barH = pw - 48, 10
            surface.SetDrawColor(20, 20, 25, 220 * a)
            surface.DrawRect(barX, barY, barW, barH)

            self.dispFrac = self.dispFrac or 0
            self.dispFrac = Lerp(FrameTime() * 6, self.dispFrac, frac)
            surface.SetDrawColor(pal.accent.r, pal.accent.g, pal.accent.b, 240 * a)
            surface.DrawRect(barX, barY, barW * self.dispFrac, barH)

            local voteText = votes == 0 and "Нет голосов" or (votes .. " голос(ов)")
            draw.SimpleText(voteText, "VoteSmall",
                ox + pw / 2, oy + ph - 22,
                Color(120, 255, 140, 230 * a),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

            if mine then
                draw.SimpleText("✔ ВАШ ВЫБОР", "VoteSmall",
                    ox + pw / 2, oy + ph - 8,
                    Color(120, 255, 140, 240 * a),
                    TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
            end
        end

        card.DoClick = function()
            net.Start("MapVote_EraVote")
            net.WriteString(entry.eraID)
            net.SendToServer()
            surface.PlaySound("buttons/lightswitch2.wav")
        end
    end
end

net.Receive("MapVote_Start", function()
    local duration = net.ReadUInt(8)
    VoteEndTime = CurTime() + duration
    ConflictList = net.ReadTable()
    CurrentVotes = {}
    OpenConflictVoteMenu()
end)

net.Receive("MapVote_Update", function()
    CurrentVotes = net.ReadTable()
end)

function OpenConflictVoteMenu()
    local f = MakeBaseFrame()
    f.titleAccent = Color(220, 55, 55)

    local eraID = ConflictList[1] and ConflictList[1].conflictID
    local pal = eraPalette[eraID] or defaultColors
    f.titleAccent = pal.accent

    local eraName = (GAMEMODE.Conflicts[eraID] and GAMEMODE.Conflicts[eraID].name) or ""

    f.Paint = function(self, w, h)
        local a = self.appear
        DrawBackdrop(w, h, a, self.titleAccent)

        draw.SimpleText(string.upper(eraName), "VoteSubtitle",
            w / 2, h * 0.05,
            Color(pal.title.r, pal.title.g, pal.title.b, 220 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

        draw.SimpleText("ВЫБЕРИ КОНФЛИКТ", "VoteTitle",
            w / 2, h * 0.10,
            Color(self.titleAccent.r, self.titleAccent.g, self.titleAccent.b, 255 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

        DrawTimer(w, h, a)
    end

    local scroll = vgui.Create("DScrollPanel", f)
    scroll:SetSize(ScrW() * 0.92, ScrH() * 0.62)
    scroll:SetPos(ScrW() * 0.04, ScrH() * 0.24)

    local sbar = scroll:GetVBar()
    sbar:SetWide(4)
    sbar.Paint = function() end
    sbar.btnUp.Paint   = function() end
    sbar.btnDown.Paint = function() end
    sbar.btnGrip.Paint = function(_, sw, sh)
        surface.SetDrawColor(120, 120, 120, 180)
        surface.DrawRect(0, 0, sw, sh)
    end

    local n = #ConflictList
    local cols = math.min(n, 4)
    local gap = 16
    local cardW = (scroll:GetWide() - (cols + 1) * gap) / cols
    local cardH = 230

    local rows = math.ceil(n / cols)
    local grid = vgui.Create("DPanel", scroll)
    grid:SetSize(scroll:GetWide(), rows * (cardH + gap) + gap)
    grid.Paint = function() end

    for i, entry in ipairs(ConflictList) do
        local row = math.floor((i - 1) / cols)
        local col = (i - 1) % cols
        local x = gap + col * (cardW + gap)
        local y = gap + row * (cardH + gap)

        local colors = conflictColors[entry.conflictID] or defaultColors

        local card = vgui.Create("DButton", grid)
        card:SetPos(x, y)
        card:SetSize(cardW, cardH)
        card:SetText("")
        card.indexDelay = i * 0.04
        HoverAnimate(card)

        card.Paint = function(self, pw, ph)
            local a = self.appear * f.appear
            if a <= 0 then return end
            local hov = self.hover

            local votes = CountVotes(CurrentVotes, entry.voteID)
            local total = TotalVotes(CurrentVotes)
            local frac  = total > 0 and votes / total or 0

            local myID = LocalPlayer():SteamID()
            local mine = (CurrentVotes[myID] == entry.voteID)

            local yOff = (1 - a) * 40
            local ox, oy = 0, yOff

            surface.SetDrawColor(0, 0, 0, 100 * a)
            surface.DrawRect(ox + 4, oy + 6, pw, ph)

            local r = math.floor(Lerp(hov, colors.bg.r, colors.bg.r + 30))
            local g = math.floor(Lerp(hov, colors.bg.g, colors.bg.g + 30))
            local b = math.floor(Lerp(hov, colors.bg.b, colors.bg.b + 30))
            surface.SetDrawColor(r, g, b, 240 * a)
            surface.DrawRect(ox, oy, pw, ph)

            surface.SetDrawColor(colors.accent.r, colors.accent.g, colors.accent.b, 255 * a)
            surface.DrawRect(ox, oy, pw, 4)

            if mine then
                local pulse = 0.6 + 0.4 * math.sin(CurTime() * 5)
                surface.SetDrawColor(120, 255, 140, 220 * pulse * a)
                surface.DrawOutlinedRect(ox, oy, pw, ph, 3)
            elseif hov > 0.05 then
                surface.SetDrawColor(255, 255, 255, 100 * hov * a)
                surface.DrawOutlinedRect(ox, oy, pw, ph, 1)
            end

            draw.SimpleText(entry.subconflictName, "VoteSubtitle",
                ox + pw / 2, oy + 26,
                Color(colors.title.r, colors.title.g, colors.title.b, 255 * a),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

            draw.SimpleText(entry.description, "VoteDesc",
                ox + pw / 2, oy + 64,
                Color(190, 190, 190, 230 * a),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

            local mapStr = table.concat(entry.maps, ", ")
            draw.SimpleText(mapStr, "VoteSmall",
                ox + pw / 2, oy + 92,
                Color(140, 140, 140, 220 * a),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

            surface.SetDrawColor(colors.accent.r, colors.accent.g, colors.accent.b, 60 * a)
            surface.DrawRect(ox + 20, oy + 120, pw - 40, 1)

            local barX, barY = ox + 20, oy + ph - 60
            local barW, barH = pw - 40, 10
            surface.SetDrawColor(20, 20, 25, 220 * a)
            surface.DrawRect(barX, barY, barW, barH)

            self.dispFrac = self.dispFrac or 0
            self.dispFrac = Lerp(FrameTime() * 6, self.dispFrac, frac)

            surface.SetDrawColor(colors.accent.r, colors.accent.g, colors.accent.b, 240 * a)
            surface.DrawRect(barX, barY, barW * self.dispFrac, barH)

            local voteText = votes == 0 and "Нет голосов" or (votes .. " голос(ов)")
            draw.SimpleText(voteText, "VoteDesc",
                ox + pw / 2, oy + ph - 38,
                Color(120, 255, 140, 230 * a),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

            if mine then
                draw.SimpleText("✔ ВАШ ВЫБОР", "VoteDesc",
                    ox + pw / 2, oy + ph - 18,
                    Color(120, 255, 140, 240 * a),
                    TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
            end
        end

        card.DoClick = function()
            net.Start("MapVote_CastVote")
            net.WriteString(entry.voteID)
            net.SendToServer()
            surface.PlaySound("buttons/lightswitch2.wav")
        end
    end
end

net.Receive("MapVote_Phase2", function()
    local duration = net.ReadUInt(8)
    VoteEndTime = CurTime() + duration
    SelectedConflictName = net.ReadString()
    Phase2Maps = net.ReadTable()
    Phase2Votes = {}
    OpenMapVoteMenu(SelectedConflictName)
end)

net.Receive("MapVote_Phase2Update", function()
    Phase2Votes = net.ReadTable()
end)

function OpenMapVoteMenu(conflictName)
    local f = MakeBaseFrame()

    f.Paint = function(self, w, h)
        local a = self.appear
        DrawBackdrop(w, h, a, Color(190, 35, 40))

        draw.SimpleText(conflictName, "VoteTitle",
            w / 2, h * 0.05,
            Color(220, 55, 55, 255 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        draw.SimpleText("ВЫБЕРИ КАРТУ", "VoteSubtitle",
            w / 2, h * 0.16,
            Color(220, 220, 220, 230 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        DrawTimer(w, h, a)
    end

    local container = vgui.Create("DPanel", f)
    local panelW = math.min(ScrW() * 0.55, 720)
    local rowH = 64
    local totalH = #Phase2Maps * (rowH + 10) + 20
    container:SetSize(panelW, totalH)
    container:SetPos((ScrW() - panelW) / 2, ScrH() * 0.24)
    container.Paint = function() end

    for i, mapName in ipairs(Phase2Maps) do
        local btn = vgui.Create("DButton", container)
        btn:SetSize(panelW, rowH)
        btn:SetPos(0, (i - 1) * (rowH + 10))
        btn:SetText("")
        btn.indexDelay = i * 0.04
        HoverAnimate(btn)

        local isRandom = (mapName == "__random__")
        local display = isRandom and "Случайная карта" or mapName

        btn.Paint = function(self, pw, ph)
            local a = self.appear * f.appear
            if a <= 0 then return end
            local hov = self.hover

            local mine = (Phase2Votes[LocalPlayer():SteamID()] == mapName)
            local votes = CountVotes(Phase2Votes, mapName)
            local total = TotalVotes(Phase2Votes)
            local frac  = total > 0 and votes / total or 0

            local xOff = (1 - a) * -30
            local ox = xOff

            local baseR, baseG, baseB = 22, 24, 32
            if isRandom then baseR, baseG, baseB = 50, 30, 65 end

            local r = math.floor(Lerp(hov, baseR, baseR + 22))
            local g = math.floor(Lerp(hov, baseG, baseG + 22))
            local b = math.floor(Lerp(hov, baseB, baseB + 26))

            surface.SetDrawColor(r, g, b, 240 * a)
            surface.DrawRect(ox, 0, pw, ph)

            local accent = isRandom and Color(200, 130, 255) or Color(120, 170, 255)
            surface.SetDrawColor(accent.r, accent.g, accent.b, 230 * a)
            surface.DrawRect(ox, 0, 4, ph)

            self.dispFrac = self.dispFrac or 0
            self.dispFrac = Lerp(FrameTime() * 6, self.dispFrac, frac)
            surface.SetDrawColor(accent.r, accent.g, accent.b, 35 * a)
            surface.DrawRect(ox + 4, 0, (pw - 4) * self.dispFrac, ph)

            if mine then
                local pulse = 0.6 + 0.4 * math.sin(CurTime() * 5)
                surface.SetDrawColor(120, 255, 140, 220 * pulse * a)
                surface.DrawOutlinedRect(ox, 0, pw, ph, 3)
            elseif hov > 0.05 then
                surface.SetDrawColor(255, 255, 255, 100 * hov * a)
                surface.DrawOutlinedRect(ox, 0, pw, ph, 1)
            end

            draw.SimpleText(display, "VoteMapName",
                ox + 24, ph / 2,
                Color(255, 255, 255, 255 * a),
                TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            if votes > 0 then
                draw.SimpleText(votes .. " голос(ов)", "VoteMapName",
                    ox + pw - 24, ph / 2,
                    Color(120, 255, 140, 240 * a),
                    TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
            end

            if mine then
                draw.SimpleText("✔", "VoteMapName",
                    ox + pw - 160, ph / 2,
                    Color(120, 255, 140, 250 * a),
                    TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
            end
        end

        btn.DoClick = function()
            net.Start("MapVote_Phase2Vote")
            net.WriteString(mapName)
            net.SendToServer()
            surface.PlaySound("buttons/lightswitch2.wav")
        end
    end
end

net.Receive("MapVote_Phase3", function()
    local duration = net.ReadUInt(8)
    VoteEndTime = CurTime() + duration
    SelectedMapForPhase3 = net.ReadString()
    Phase3Modes = net.ReadTable()
    Phase3Votes = {}
    OpenModeVoteMenu()
end)

net.Receive("MapVote_Phase3Update", function()
    Phase3Votes = net.ReadTable()
end)

function OpenModeVoteMenu()
    local f = MakeBaseFrame()

    f.Paint = function(self, w, h)
        local a = self.appear
        DrawBackdrop(w, h, a, Color(120, 170, 255))

        draw.SimpleText(SelectedMapForPhase3, "VoteTitle",
            w / 2, h * 0.05,
            Color(220, 55, 55, 255 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        draw.SimpleText("ВЫБЕРИ РЕЖИМ", "VoteSubtitle",
            w / 2, h * 0.16,
            Color(220, 220, 220, 230 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        DrawTimer(w, h, a)
    end

    local container = vgui.Create("DPanel", f)
    local panelW = math.min(ScrW() * 0.45, 600)
    local rowH = 76
    local totalH = #Phase3Modes * (rowH + 12) + 20
    container:SetSize(panelW, totalH)
    container:SetPos((ScrW() - panelW) / 2, ScrH() * 0.26)
    container.Paint = function() end

    for i, modeName in ipairs(Phase3Modes) do
        local btn = vgui.Create("DButton", container)
        btn:SetSize(panelW, rowH)
        btn:SetPos(0, (i - 1) * (rowH + 12))
        btn:SetText("")
        btn.indexDelay = i * 0.05
        HoverAnimate(btn)

        local display = GAMEMODE.GameModesList and GAMEMODE.GameModesList[modeName] or modeName

        btn.Paint = function(self, pw, ph)
            local a = self.appear * f.appear
            if a <= 0 then return end
            local hov = self.hover

            local mine = (Phase3Votes[LocalPlayer():SteamID()] == modeName)
            local votes = CountVotes(Phase3Votes, modeName)
            local total = TotalVotes(Phase3Votes)
            local frac  = total > 0 and votes / total or 0

            local yOff = (1 - a) * 30

            local r = math.floor(Lerp(hov, 22, 50))
            local g = math.floor(Lerp(hov, 24, 60))
            local b = math.floor(Lerp(hov, 32, 80))
            surface.SetDrawColor(r, g, b, 240 * a)
            surface.DrawRect(0, yOff, pw, ph)

            surface.SetDrawColor(120, 170, 255, 230 * a)
            surface.DrawRect(0, yOff, 4, ph)

            self.dispFrac = self.dispFrac or 0
            self.dispFrac = Lerp(FrameTime() * 6, self.dispFrac, frac)
            surface.SetDrawColor(120, 170, 255, 40 * a)
            surface.DrawRect(4, yOff, (pw - 4) * self.dispFrac, ph)

            if mine then
                local pulse = 0.6 + 0.4 * math.sin(CurTime() * 5)
                surface.SetDrawColor(120, 255, 140, 220 * pulse * a)
                surface.DrawOutlinedRect(0, yOff, pw, ph, 3)
            elseif hov > 0.05 then
                surface.SetDrawColor(255, 255, 255, 100 * hov * a)
                surface.DrawOutlinedRect(0, yOff, pw, ph, 1)
            end

            draw.SimpleText(display, "VoteBig",
                24, yOff + ph / 2,
                Color(255, 255, 255, 255 * a),
                TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            if votes > 0 then
                draw.SimpleText(votes .. " голос(ов)", "VoteMapName",
                    pw - 24, yOff + ph / 2,
                    Color(120, 255, 140, 240 * a),
                    TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
            end

            if mine then
                draw.SimpleText("✔", "VoteBig",
                    pw - 160, yOff + ph / 2,
                    Color(120, 255, 140, 250 * a),
                    TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
            end
        end

        btn.DoClick = function()
            net.Start("MapVote_Phase3Vote")
            net.WriteString(modeName)
            net.SendToServer()
            surface.PlaySound("buttons/lightswitch2.wav")
        end
    end
end
