util.AddNetworkString("Warses_SpecCmd")
util.AddNetworkString("Warses_SpecState")
util.AddNetworkString("Warses_SpecMsg")

WARSES_SPEC_FREE  = 0
WARSES_SPEC_FIRST = 1
WARSES_SPEC_CHASE = 2

local SPEC_CMD_CYCLE  = 1
local SPEC_CMD_MODE   = 2
local SPEC_CMD_DETACH = 3

local function IsZombieGhostActive()
    return GAMEMODE and GAMEMODE.ZombieActive == true
end

local function GetSpectatableTargets(self)
    local out = {}
    for _, p in ipairs(player.GetAll()) do
        if not IsValid(p) then continue end
        if p == self then continue end
        if not p:Alive() then continue end
        if p:Team() ~= TEAM_ALPHA and p:Team() ~= TEAM_BRAVO then continue end
        out[#out + 1] = p
    end
    table.sort(out, function(a, b) return a:UserID() < b:UserID() end)
    return out
end

local function PickNextTarget(self, current, dir)
    local list = GetSpectatableTargets(self)
    if #list == 0 then return nil end

    local idx = 1
    for i, p in ipairs(list) do
        if p == current then idx = i break end
    end

    if current and table.HasValue(list, current) then
        idx = idx + (dir or 1)
        if idx > #list then idx = 1 end
        if idx < 1 then idx = #list end
    end

    return list[idx]
end

local function SendState(ply)
    if not IsValid(ply) then return end
    local target = ply:GetNWEntity("spect", NULL)
    net.Start("Warses_SpecState")
        net.WriteInt(ply:GetNWInt("viewmode", WARSES_SPEC_FREE), 8)
        net.WriteEntity(IsValid(target) and target or NULL)
    net.Send(ply)
end

local function ApplyMode(ply, mode, target)
    if not IsValid(ply) then return end

    if mode == WARSES_SPEC_FREE or not (IsValid(target) and target:IsPlayer() and target:Alive()) then
        ply:SetNWInt("viewmode", WARSES_SPEC_FREE)
        ply:SetNWEntity("spect", NULL)
        ply:Spectate(OBS_MODE_ROAMING)
        ply:SpectateEntity(NULL)
        SendState(ply)
        return
    end

    if mode == WARSES_SPEC_FIRST then
        ply:Spectate(OBS_MODE_IN_EYE)
        ply:SpectateEntity(target)
        ply:SetNWInt("viewmode", WARSES_SPEC_FIRST)
        ply:SetNWEntity("spect", target)
    else
        ply:Spectate(OBS_MODE_CHASE)
        ply:SpectateEntity(target)
        ply:SetNWInt("viewmode", WARSES_SPEC_CHASE)
        ply:SetNWEntity("spect", target)
    end

    SendState(ply)
end

local function HideSpectatorBody(ply)
    if not IsValid(ply) then return end
    ply:SetNoDraw(true)
    ply:DrawShadow(false)
    ply:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)
end

local function ShowSpectatorBody(ply)
    if not IsValid(ply) then return end
    ply:SetNoDraw(false)
    ply:DrawShadow(true)
    ply:SetCollisionGroup(COLLISION_GROUP_PLAYER)
end

function Warses_EnterSpectator(ply)
    if not IsValid(ply) then return end
    if IsZombieGhostActive() then return end

    ply:UnSpectate()
    ply:Freeze(false)
    ply:StripWeapons()
    ply:RemoveAllAmmo()
    ply:GodEnable()

    if IsValid(ply.FakeRagdoll) and hg and isfunction(hg.FakeUp) then
        hg.FakeUp(ply, true, true)
    end

    ApplyMode(ply, WARSES_SPEC_FREE, NULL)

    HideSpectatorBody(ply)
    timer.Simple(0, function() HideSpectatorBody(ply) end)

    net.Start("Warses_SpecMsg")
        net.WriteString("Наблюдатель: ЛКМ/ПКМ — следующий/предыдущий, R — режим, ПРОБЕЛ — отстёгнуться")
    net.Send(ply)
end

function Warses_ExitSpectator(ply)
    if not IsValid(ply) then return end
    ply:UnSpectate()
    ply:GodDisable()
    ShowSpectatorBody(ply)
    ply:SetNWInt("viewmode", WARSES_SPEC_FREE)
    ply:SetNWEntity("spect", NULL)
    SendState(ply)
end

local function ValidateTarget(ply)
    if not IsValid(ply) then return end
    if ply:Team() ~= TEAM_SPECTATOR then return end
    if IsZombieGhostActive() then return end

    local mode   = ply:GetNWInt("viewmode", WARSES_SPEC_FREE)
    local target = ply:GetNWEntity("spect", NULL)

    if mode == WARSES_SPEC_FREE then return end
    if IsValid(target) and target:IsPlayer() and target:Alive() then return end

    local next = PickNextTarget(ply, nil, 1)
    if IsValid(next) then
        ApplyMode(ply, mode, next)
    else
        ApplyMode(ply, WARSES_SPEC_FREE, NULL)
    end
end

timer.Create("Warses_SpecValidate", 0.5, 0, function()
    local plys = player.GetAll()
    for i = 1, #plys do
        local ply = plys[i]
        if ply:Team() == TEAM_SPECTATOR then
            if not IsZombieGhostActive() and not ply:GetNoDraw() then
                HideSpectatorBody(ply)
            end
            ValidateTarget(ply)
        end
    end
end)

hook.Add("PostPlayerDeath", "Warses_SpecRotateOnDeath", function(victim)
    if not IsValid(victim) then return end
    timer.Simple(0.05, function()
        if not IsValid(victim) then return end
        local plys = player.GetAll()
        for i = 1, #plys do
            local p = plys[i]
            if p:Team() == TEAM_SPECTATOR and p:GetNWEntity("spect", NULL) == victim then
                ValidateTarget(p)
            end
        end
    end)
end)

net.Receive("Warses_SpecCmd", function(_, ply)
    if not IsValid(ply) then return end
    if ply:Team() ~= TEAM_SPECTATOR then return end
    if IsZombieGhostActive() then return end

    local cmd = net.ReadInt(8)
    local dir = net.ReadInt(8)

    local mode   = ply:GetNWInt("viewmode", WARSES_SPEC_FREE)
    local target = ply:GetNWEntity("spect", NULL)

    if cmd == SPEC_CMD_CYCLE then
        local next = PickNextTarget(ply, IsValid(target) and target or nil, dir or 1)
        if IsValid(next) then
            local applyMode = (mode == WARSES_SPEC_FREE) and WARSES_SPEC_CHASE or mode
            ApplyMode(ply, applyMode, next)
        else
            net.Start("Warses_SpecMsg")
                net.WriteString("Нет доступных целей для наблюдения.")
            net.Send(ply)
        end

    elseif cmd == SPEC_CMD_MODE then
        if not (IsValid(target) and target:IsPlayer() and target:Alive()) then
            return
        end
        local nextMode
        if mode == WARSES_SPEC_CHASE then
            nextMode = WARSES_SPEC_FIRST
        elseif mode == WARSES_SPEC_FIRST then
            nextMode = WARSES_SPEC_CHASE
        else
            nextMode = WARSES_SPEC_CHASE
        end
        ApplyMode(ply, nextMode, target)

    elseif cmd == SPEC_CMD_DETACH then
        ApplyMode(ply, WARSES_SPEC_FREE, NULL)
    end
end)

hook.Add("PlayerInitialSpawn", "Warses_SpecPushStateInit", function(ply)
    timer.Simple(2, function()
        if IsValid(ply) and ply:Team() == TEAM_SPECTATOR then SendState(ply) end
    end)
end)

hook.Add("InitPostEntity", "Warses_SpecBlockFake", function()
    timer.Simple(1, function()
        if not hg or not isfunction(hg.Fake) then return end
        if hg.Warses_FakeWrapped then return end
        hg.Warses_FakeWrapped = true

        local baseFake = hg.Fake
        function hg.Fake(ply, ...)
            if IsValid(ply) and ply:Team() == TEAM_SPECTATOR then return end
            return baseFake(ply, ...)
        end
    end)
end)

hook.Add("CanPlayerEnterVehicle", "Warses_SpecNoVehicle", function(ply, veh, role)
    if IsValid(ply) and ply:Team() == TEAM_SPECTATOR then return false end
end)

hook.Add("PlayerEnteredVehicle", "Warses_SpecEjectVehicle", function(ply, veh)
    if not (IsValid(ply) and ply:Team() == TEAM_SPECTATOR) then return end
    timer.Simple(0, function()
        if IsValid(ply) and ply:InVehicle() then ply:ExitVehicle() end
    end)
end)
