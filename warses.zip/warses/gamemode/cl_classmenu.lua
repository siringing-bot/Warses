local classMenuOpen = false
local ClassMenuFrame = nil

local selectedClass = nil
local selectedSpawnTarget = nil
local respawnTimer = 0
local isRespawning = false

LocalPlayerState = LocalPlayerState or {}
LocalPlayerState.weaponChoice = LocalPlayerState.weaponChoice or {}

surface.CreateFont("Warses_CM_Title", {font = "Roboto", size = 52, weight = 900, antialias = true})
surface.CreateFont("Warses_CM_Sub",   {font = "Roboto", size = 22, weight = 500, antialias = true})
surface.CreateFont("Warses_CM_Card",  {font = "Roboto", size = 24, weight = 800, antialias = true})
surface.CreateFont("Warses_CM_Desc",  {font = "Roboto", size = 15, weight = 500, antialias = true})
surface.CreateFont("Warses_CM_Btn",   {font = "Roboto", size = 24, weight = 700, antialias = true})
surface.CreateFont("Warses_CM_Timer", {font = "Roboto", size = 44, weight = 900, antialias = true})
surface.CreateFont("Warses_CM_Small", {font = "Roboto", size = 14, weight = 500, antialias = true})
surface.CreateFont("Warses_CM_Big",   {font = "Roboto", size = 38, weight = 900, antialias = true})
surface.CreateFont("Warses_CM_Stat",  {font = "Roboto", size = 18, weight = 600, antialias = true})

local function ResolveTeamID()
    local t = LocalPlayerState and LocalPlayerState.team
    if t == TEAM_ALPHA or t == TEAM_BRAVO then return t end
    t = LocalPlayer():Team()
    if t == TEAM_ALPHA or t == TEAM_BRAVO then return t end
    return TEAM_ALPHA
end

local function GetModelForClass(teamID, classID)
    local teamInfo = GAMEMODE:GetTeamInfo(teamID)
    if teamInfo and teamInfo.models and teamInfo.models[classID] then
        local models = teamInfo.models[classID]
        if type(models) == "table" and models[1] then
            return models[1]
        end
    end
    for _, conf in pairs(GAMEMODE.Conflicts) do
        for _, sub in pairs(conf.subconflicts) do
            local t = sub.teams and sub.teams[teamID]
            if t and t.models and t.models[classID] then
                local m = t.models[classID]
                if type(m) == "table" and m[1] then return m[1] end
            end
        end
    end
    local cls = GAMEMODE.Classes[classID]
    return (cls and cls.model) or "models/player/combine_soldier.mdl"
end

local function GetPrimaryWeaponForClass(teamID, classID)
    local conflict = GAMEMODE.Conflicts[GAMEMODE.CurrentConflict]
    if conflict then
        local sub = conflict.subconflicts[GAMEMODE.CurrentSubconflict]
        if sub and sub.weaponLoadouts and sub.weaponLoadouts[teamID] then
            local loadout = sub.weaponLoadouts[teamID][classID]
            if loadout and loadout[1] then
                return loadout[1]
            end
        end
    end
    for _, conf in pairs(GAMEMODE.Conflicts) do
        for _, sub in pairs(conf.subconflicts) do
            local l = sub.weaponLoadouts and sub.weaponLoadouts[teamID] and sub.weaponLoadouts[teamID][classID]
            if l and l[1] then return l[1] end
        end
    end
    local cls = GAMEMODE.Classes[classID]
    return cls and cls.weapons and cls.weapons[1] or nil
end

local function GetLoadoutForClass(teamID, classID)
    local conflict = GAMEMODE.Conflicts[GAMEMODE.CurrentConflict]
    if conflict then
        local sub = conflict.subconflicts[GAMEMODE.CurrentSubconflict]
        if sub and sub.weaponLoadouts and sub.weaponLoadouts[teamID] then
            local loadout = sub.weaponLoadouts[teamID][classID]
            if loadout then return loadout end
        end
    end
    for _, conf in pairs(GAMEMODE.Conflicts) do
        for _, sub in pairs(conf.subconflicts) do
            local l = sub.weaponLoadouts and sub.weaponLoadouts[teamID] and sub.weaponLoadouts[teamID][classID]
            if l then return l end
        end
    end
    local cls = GAMEMODE.Classes[classID]
    return cls and cls.weapons or nil
end

local function GetWeaponWorldModel(weaponClass)
    if not weaponClass then return nil end
    local wep = weapons.GetStored(weaponClass)
    if wep and wep.WorldModel and wep.WorldModel ~= "" then
        return wep.WorldModel
    end
    return nil
end

local function CountClassPlayers(myTeam, classID)
    local n = 0
    for _, p in ipairs(player.GetAll()) do
        if p:Team() == myTeam and p:GetNWString("Class") == classID then
            n = n + 1
        end
    end
    return n
end

local function MakeClassCard(parent, classID, classInfo, w, h, index, onClick, onHover)
    local btn = vgui.Create("DButton", parent)
    btn:SetTall(h)
    btn:Dock(TOP)
    btn:DockMargin(0, 0, 0, 8)
    btn:SetText("")

    btn.hover  = 0
    btn.appear = 0
    btn.start  = SysTime() + 0.04 * index

    btn.Think = function(self)
        local t = math.Clamp((SysTime() - self.start) * 2.0, 0, 1)
        self.appear = 1 - math.pow(1 - t, 3)
        local target = self:IsHovered() and 1 or 0
        self.hover = Lerp(FrameTime() * 9, self.hover, target)
        if self:IsHovered() and onHover then onHover(classID) end
    end

    btn.Paint = function(self, pw, ph)
        if self.appear <= 0 then return end
        local a = self.appear
        local hov = self.hover

        local playersText, isFull = "∞", false
        if classInfo.max_players then
            local curN = CountClassPlayers(ResolveTeamID(), classID)
            playersText = curN .. " / " .. classInfo.max_players
            isFull = (curN >= classInfo.max_players) and (LocalPlayerState.class ~= classID)
                and not Warses_IsVIP(LocalPlayer())
        end

        local selected = (selectedClass == classID)
        local xOff = (1 - a) * -30

        surface.SetDrawColor(0, 0, 0, 80 * a)
        surface.DrawRect(xOff + 3, 4, pw, ph)

        local baseR, baseG, baseB = 22, 24, 32
        if selected then
            baseR, baseG, baseB = 26, 55, 30
        elseif isFull then
            baseR, baseG, baseB = 40, 22, 22
        end
        local r = math.floor(Lerp(hov, baseR, baseR + 22))
        local g = math.floor(Lerp(hov, baseG, baseG + 22))
        local b = math.floor(Lerp(hov, baseB, baseB + 26))
        surface.SetDrawColor(r, g, b, 245 * a)
        surface.DrawRect(xOff, 0, pw, ph)

        local accent = Color(120, 170, 255)
        if selected then accent = Color(100, 255, 130)
        elseif isFull then accent = Color(255, 90, 90) end
        surface.SetDrawColor(accent.r, accent.g, accent.b, 255 * a)
        surface.DrawRect(xOff, 0, 4, ph)

        if selected then
            local pulse = 0.6 + 0.4 * math.sin(CurTime() * 5)
            surface.SetDrawColor(100, 255, 130, 220 * pulse * a)
            surface.DrawOutlinedRect(xOff, 0, pw, ph, 2)
        elseif hov > 0.05 then
            surface.SetDrawColor(255, 255, 255, 140 * hov * a)
            surface.DrawOutlinedRect(xOff, 0, pw, ph, 1)
        end

        draw.SimpleText(classInfo.name, "Warses_CM_Card",
            xOff + 18, 10,
            Color(255, 255, 255, 255 * a),
            TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

        draw.SimpleText(classInfo.description or "", "Warses_CM_Desc",
            xOff + 18, 42,
            Color(190, 190, 200, 230 * a),
            TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

        if classInfo.att_slots then
            draw.SimpleText("Слотов аттачей: " .. classInfo.att_slots, "Warses_CM_Small",
                xOff + 18, ph - 22,
                Color(150, 180, 220, 220 * a),
                TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        end

        local pcCol = isFull and Color(255, 90, 90) or Color(220, 70, 65)
        if selected then pcCol = Color(120, 255, 140) end
        draw.SimpleText(playersText, "Warses_CM_Btn",
            xOff + pw - 18, ph - 28,
            Color(pcCol.r, pcCol.g, pcCol.b, 240 * a),
            TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
    end

    btn.DoClick = function() onClick(classID, classInfo) end
    return btn
end

local IDLE_PRIORITY = {
    "idle_all_01", "cidle_all_01", "idle_subtle",
    "menu_combine_idle", "menu_combine", "menu_citizen",
    "idle_smg1", "idle_smg", "idle_ar2", "idle_pistol",
    "idle_shotgun", "idle_rpg", "idle_crossbow"
}

local function PickIdleSequence(ent)
    local count = ent:GetSequenceCount() or 0
    for _, want in ipairs(IDLE_PRIORITY) do
        for i = 0, count - 1 do
            local name = string.lower(ent:GetSequenceName(i) or "")
            if name == want then return i end
        end
    end
    for i = 0, count - 1 do
        local name = string.lower(ent:GetSequenceName(i) or "")
        if string.sub(name, 1, 4) == "idle" then return i end
    end
    for i = 0, count - 1 do
        local name = string.lower(ent:GetSequenceName(i) or "")
        if string.find(name, "idle") or string.find(name, "stand") or string.find(name, "menu") then
            return i
        end
    end
    return 0
end

local function CreateClassPreview(parent)
    local mp = vgui.Create("DModelPanel", parent)
    mp:SetFOV(45)
    mp:SetAmbientLight(Color(160, 160, 170))
    mp:SetDirectionalLight(BOX_TOP,    Color(255, 245, 220))
    mp:SetDirectionalLight(BOX_FRONT,  Color(220, 230, 255))
    mp:SetDirectionalLight(BOX_RIGHT,  Color(255, 200, 160))
    mp:SetDirectionalLight(BOX_LEFT,   Color(120, 140, 200))
    mp:SetAnimated(true)

    mp.currentClassID = nil
    mp.currentModel   = nil
    mp.weaponEnt      = nil
    mp.idleSequence   = 0
    mp.sequenceSet    = false

    function mp:SetClass(classID, teamID)
        if self.currentClassID == classID then return end
        self.currentClassID = classID

        local modelPath = GetModelForClass(teamID, classID)
        if modelPath ~= self.currentModel then
            self.currentModel = modelPath
            self:SetModel(modelPath)
            self.sequenceSet = false
        end

        local ent = self.Entity
        if IsValid(ent) then
            ent:SetIK(false)
            local mins, maxs = ent:GetRenderBounds()
            local headZ = math.min(maxs.z - 6, 66)
            local d = 24
            self:SetCamPos(Vector(d, 0, headZ + 2))
            self:SetLookAt(Vector(0, 0, headZ - 1))
        end

        if IsValid(self.weaponEnt) then
            self.weaponEnt:Remove()
            self.weaponEnt = nil
        end
        local weaponClass = GetPrimaryWeaponForClass(teamID, classID)
        local worldModel = GetWeaponWorldModel(weaponClass)
        if worldModel and IsValid(ent) then
            local wep = ClientsideModel(worldModel, RENDERGROUP_OPAQUE)
            if IsValid(wep) then
                wep:SetNoDraw(true)
                wep:SetParent(ent)
                wep:AddEffects(EF_BONEMERGE)
                self.weaponEnt = wep
            end
        end
    end

    function mp:LayoutEntity(ent)
        if not self.sequenceSet then
            self.idleSequence = PickIdleSequence(ent)
            ent:SetSequence(self.idleSequence)
            self.sequenceSet = true
        end
        ent:SetAngles(Angle(0, 0, 0))
        ent:FrameAdvance(FrameTime())
    end

    function mp:DrawModel()
        local ent = self.Entity
        if not IsValid(ent) then return end
        ent:DrawModel()
        if IsValid(self.weaponEnt) then
            self.weaponEnt:DrawModel()
        end
    end

    function mp:OnRemove()
        if IsValid(self.weaponEnt) then
            self.weaponEnt:Remove()
            self.weaponEnt = nil
        end
    end

    return mp
end

function OpenClassMenu(respawn, respawnTime)
    local zombieMode = GAMEMODE and GAMEMODE.CurrentGameMode == "zombie"
    local cutscene = Warses_IsZombieCutsceneFullscreen and Warses_IsZombieCutsceneFullscreen()
    if zombieMode or cutscene then
        return
    end
    if classMenuOpen and IsValid(ClassMenuFrame) then return end
    classMenuOpen = true

    isRespawning = respawn or false
    if isRespawning then
        respawnTimer = CurTime() + (respawnTime or GAMEMODE.RespawnTime or 8)
    end

    if not selectedClass and LocalPlayerState.class then
        selectedClass = LocalPlayerState.class
    end

    local myTeam = ResolveTeamID()
    local classes = GAMEMODE:GetAvailableClasses(myTeam)

    if LocalPlayerState.lastSeenTeam and LocalPlayerState.lastSeenTeam ~= myTeam then
        LocalPlayerState.weaponChoice = {}
        selectedClass = nil
    end
    LocalPlayerState.lastSeenTeam = myTeam
    if selectedClass and not classes[selectedClass] then
        selectedClass = nil
        LocalPlayerState.weaponChoice = {}
    end

    local scrW, scrH = ScrW(), ScrH()

    local frame = vgui.Create("DFrame")
    ClassMenuFrame = frame
    frame:SetSize(scrW, scrH)
    frame:SetPos(0, 0)
    frame:SetTitle("")
    frame:ShowCloseButton(false)
    frame:SetDraggable(false)
    frame:MakePopup()
    frame:SetKeyboardInputEnabled(false)

    frame.start  = SysTime()
    frame.appear = 0
    frame.OnClose = function() classMenuOpen = false end

    local firstClassID
    for k in pairs(classes) do firstClassID = k; break end
    local previewClass = selectedClass or firstClassID

    frame.Paint = function(self, w, h)
        local a = self.appear

        surface.SetDrawColor(8, 9, 14, 235 * a)
        surface.DrawRect(0, 0, w, h)

        local barH = 80
        surface.SetDrawColor(20, 22, 30, 240 * a)
        surface.DrawRect(0, 0, w, barH)

        local teamCol = (myTeam == TEAM_ALPHA) and Color(80, 140, 240) or Color(240, 80, 80)
        surface.SetDrawColor(teamCol.r, teamCol.g, teamCol.b, 220 * a)
        surface.DrawRect(0, barH - 3, w, 3)

        draw.SimpleText("ВЫБОР КЛАССА", "Warses_CM_Title",
            w / 2, barH / 2,
            Color(255, 255, 255, 255 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        if isRespawning then
            local timeLeft = math.max(0, respawnTimer - CurTime())
            local secs = math.ceil(timeLeft)
            local col = secs > 0 and Color(220, 60, 60) or Color(120, 255, 140)
            local label = secs > 0 and ("Возрождение через " .. secs .. " сек") or "ГОТОВ К ВОЗРОЖДЕНИЮ"
            draw.SimpleText(label, "Warses_CM_Sub",
                w / 2, barH + 18,
                Color(col.r, col.g, col.b, 240 * a),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

            local respawnDuration = GAMEMODE.RespawnTime or 8
            local frac = 1 - math.Clamp(timeLeft / respawnDuration, 0, 1)
            local bw = w * 0.35
            local bx = (w - bw) / 2
            local by = barH + 48
            surface.SetDrawColor(40, 42, 48, 220 * a)
            surface.DrawRect(bx, by, bw, 4)
            surface.SetDrawColor(col.r, col.g, col.b, 240 * a)
            surface.DrawRect(bx, by, bw * frac, 4)
        end
    end

    frame.Think = function(self)
        self.appear = math.Clamp((SysTime() - self.start) * 1.8, 0, 1)
        self.appear = 1 - math.pow(1 - self.appear, 3)
    end

    local contentTop    = isRespawning and 150 or 100
    local contentBottom = scrH - 200
    local contentH      = contentBottom - contentTop

    local leftW = math.min(420, math.floor(scrW * 0.30))
    local leftX = 40
    local leftPanel = vgui.Create("DScrollPanel", frame)
    leftPanel:SetPos(leftX, contentTop)
    leftPanel:SetSize(leftW, contentH)

    local sbar = leftPanel:GetVBar()
    sbar:SetWide(6)
    function sbar:Paint(w, h)
        surface.SetDrawColor(20, 22, 28, 200)
        surface.DrawRect(0, 0, w, h)
    end
    function sbar.btnUp:Paint() end
    function sbar.btnDown:Paint() end
    function sbar.btnGrip:Paint(w, h)
        surface.SetDrawColor(140, 150, 170, 220)
        surface.DrawRect(0, 0, w, h)
    end

    local rightX = leftX + leftW + 30
    local rightW = scrW - rightX - 40
    local rightPanel = vgui.Create("DPanel", frame)
    rightPanel:SetPos(rightX, contentTop)
    rightPanel:SetSize(rightW, contentH)
    rightPanel.Paint = function(self, w, h)
        local a = frame.appear
        surface.SetDrawColor(14, 16, 22, 230 * a)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(255, 255, 255, 18 * a)
        surface.DrawOutlinedRect(0, 0, w, h, 1)

        local g1 = Color(0, 0, 0, 80 * a)
        surface.SetDrawColor(g1.r, g1.g, g1.b, g1.a)
        surface.DrawRect(0, 0, w, 30)
        surface.DrawRect(0, h - 30, w, 30)
    end

    local infoStripH = 120
    local previewH = contentH - infoStripH - 10

    local previewMP = CreateClassPreview(rightPanel)
    previewMP:SetPos(0, 0)
    previewMP:SetSize(rightW, previewH)
    if previewClass then
        previewMP:SetClass(previewClass, myTeam)
    end

    local infoStrip = vgui.Create("DPanel", rightPanel)
    infoStrip:SetPos(0, previewH + 10)
    infoStrip:SetSize(rightW, infoStripH)
    infoStrip.Paint = function(self, w, h)
        local a = frame.appear
        local classID = previewMP.currentClassID
        local cls = classID and classes[classID]
        if not cls then return end

        surface.SetDrawColor(18, 20, 28, 240 * a)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(255, 255, 255, 20 * a)
        surface.DrawOutlinedRect(0, 0, w, h, 1)

        local teamCol = (myTeam == TEAM_ALPHA) and Color(80, 140, 240) or Color(240, 80, 80)
        surface.SetDrawColor(teamCol.r, teamCol.g, teamCol.b, 220 * a)
        surface.DrawRect(0, 0, 4, h)

        draw.SimpleText(cls.name or classID, "Warses_CM_Big",
            22, 14,
            Color(255, 255, 255, 255 * a),
            TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

        draw.SimpleText(cls.description or "", "Warses_CM_Desc",
            22, 62,
            Color(200, 200, 210, 240 * a),
            TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

        if cls.att_slots then
            local sx, sy = 22, h - 34
            draw.SimpleText("СЛОТЫ", "Warses_CM_Small", sx, sy,
                Color(140, 160, 200, 220 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            draw.SimpleText(tostring(cls.att_slots), "Warses_CM_Stat", sx + 60, sy - 3,
                Color(255, 165, 150, 240 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        end

        local hasVariantsForSelected = selectedClass
            and (GAMEMODE:GetWeaponVariants(myTeam, selectedClass) ~= nil)

        local loadout = GetLoadoutForClass(myTeam, classID)
        if loadout and not hasVariantsForSelected then
            local x = w - 22
            local y = 14
            draw.SimpleText("ОРУЖИЕ", "Warses_CM_Small",
                x, y, Color(140, 160, 200, 220 * a), TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
            y = y + 20

            local shown = 0
            for _, wepClass in ipairs(loadout) do
                if shown >= 4 then break end
                local wep = weapons.GetStored(wepClass)
                local name = wep and wep.PrintName or wepClass
                local skip = (name == "Hands" or name == "" or string.find(wepClass, "walkie") or string.find(wepClass, "hands"))
                if name and not skip then
                    draw.SimpleText(name, "Warses_CM_Stat",
                        x, y,
                        Color(230, 230, 240, 240 * a),
                        TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
                    y = y + 20
                    shown = shown + 1
                end
            end
        end
    end

    local variantPanel = vgui.Create("DPanel", infoStrip)
    variantPanel.Paint = function() end

    local function RebuildVariantPanel()
        variantPanel:Clear()
        variantPanel:SetVisible(false)

        if not selectedClass then return end
        local variants = GAMEMODE:GetWeaponVariants(myTeam, selectedClass)
        if not variants then return end

        local panelW = math.floor(rightW * 0.55)
        local panelH = 96
        local px = rightW - panelW - 14
        local py = 12
        variantPanel:SetPos(px, py)
        variantPanel:SetSize(panelW, panelH)
        variantPanel:SetVisible(true)

        local loadout = GetLoadoutForClass(myTeam, selectedClass)
        local defaults = {
            primary   = loadout and loadout[1] or nil,
            secondary = loadout and loadout[2] or nil,
        }

        local function MakeRow(yOff, slotID, slotName, slotVariants)
            if not slotVariants or #slotVariants < 2 then return end

            local lblW = 60
            local lbl = vgui.Create("DLabel", variantPanel)
            lbl:SetPos(0, yOff + 6)
            lbl:SetSize(lblW, 24)
            lbl:SetText(slotName)
            lbl:SetFont("Warses_CM_Small")
            lbl:SetTextColor(Color(150, 170, 200))

            local bx = lblW
            local bw = math.floor((panelW - lblW - 6 * (#slotVariants - 1)) / #slotVariants)
            local bh = 30

            for _, v in ipairs(slotVariants) do
                local wepClass = v.wep
                local wep = weapons.GetStored(wepClass)
                local name = (wep and wep.PrintName and wep.PrintName ~= "") and wep.PrintName or wepClass

                local btn = vgui.Create("DButton", variantPanel)
                btn:SetPos(bx, yOff + 2)
                btn:SetSize(bw, bh)
                btn:SetText("")
                btn.hover = 0

                btn.IsSelected = function()
                    local cur = LocalPlayerState.weaponChoice and LocalPlayerState.weaponChoice[slotID]
                    if cur and cur ~= "" then return cur == wepClass end
                    return wepClass == defaults[slotID]
                end

                btn.Think = function(self)
                    self.hover = Lerp(FrameTime() * 9, self.hover, self:IsHovered() and 1 or 0)
                end

                btn.Paint = function(self, w, h)
                    local sel = self:IsSelected()
                    local r, g, b = 22, 24, 32
                    if sel then r, g, b = 26, 55, 30 end
                    local hov = self.hover
                    surface.SetDrawColor(r + hov * 18, g + hov * 18, b + hov * 22, 240)
                    surface.DrawRect(0, 0, w, h)

                    local accent = sel and Color(120, 255, 140) or Color(120, 160, 200)
                    surface.SetDrawColor(accent.r, accent.g, accent.b, sel and 230 or 80)
                    surface.DrawOutlinedRect(0, 0, w, h, sel and 2 or 1)

                    draw.SimpleText(name, "Warses_CM_Small",
                        w / 2, h / 2,
                        Color(230, 230, 240),
                        TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end

                btn.DoClick = function()
                    LocalPlayerState.weaponChoice = LocalPlayerState.weaponChoice or {}
                    LocalPlayerState.weaponChoice[slotID] = wepClass
                    net.Start("Warses_WeaponChoice")
                    net.WriteString(slotID)
                    net.WriteString(wepClass)
                    net.SendToServer()
                    surface.PlaySound("buttons/button17.wav")
                end

                bx = bx + bw + 6
            end
        end

        local rowY = 4
        if variants.primary and #variants.primary > 1 then
            MakeRow(rowY, "primary", "ОСН.", variants.primary)
            rowY = rowY + 38
        end
        if variants.secondary and #variants.secondary > 1 then
            MakeRow(rowY, "secondary", "ВТОР.", variants.secondary)
        end
    end

    local cards = {}
    local cardH = 92
    local lastPreviewedID = previewClass

    local function onClick(classID, classInfo)
        if classInfo.max_players and not Warses_IsVIP(LocalPlayer()) then
            local curN = CountClassPlayers(myTeam, classID)
            if curN >= classInfo.max_players and LocalPlayerState.class ~= classID then
                surface.PlaySound("buttons/button10.wav")
                return
            end
        end
        if selectedClass ~= classID then
            LocalPlayerState.weaponChoice = {}
        end
        selectedClass = classID
        LocalPlayerState.class = classID
        previewMP:SetClass(classID, myTeam)
        lastPreviewedID = classID
        net.Start("Warses_SelectClass")
        net.WriteString(classID)
        net.SendToServer()
        RebuildVariantPanel()
        surface.PlaySound("buttons/button17.wav")
    end

    local function onHover(classID)
        if classID ~= lastPreviewedID then
            lastPreviewedID = classID
            previewMP:SetClass(classID, myTeam)
        end
    end

    local idx = 0
    for classID, classInfo in pairs(classes) do
        local card = MakeClassCard(leftPanel, classID, classInfo, leftW - 14, cardH, idx, onClick, onHover)
        cards[classID] = card
        idx = idx + 1
    end

    RebuildVariantPanel()

    leftPanel.Think = function(self)
        local anyHovered = false
        for _, c in pairs(cards) do
            if IsValid(c) and c:IsHovered() then anyHovered = true; break end
        end
        if not anyHovered and selectedClass and lastPreviewedID ~= selectedClass then
            lastPreviewedID = selectedClass
            previewMP:SetClass(selectedClass, myTeam)
        end
    end

    local spawnStrip = vgui.Create("DPanel", frame)
    local stripH = 80
    spawnStrip:SetPos(0, scrH - 190)
    spawnStrip:SetSize(scrW, stripH)
    spawnStrip.Paint = function() end

    selectedSpawnTarget = nil

    local function MakeSpawnCard(parent, idx, isBase, sid, ply, x, y, cw, ch, cp)
        local card = vgui.Create("DButton", parent)
        card:SetPos(x, y)
        card:SetSize(cw, ch)
        card:SetText("")
        card.hover = 0

        local isCP = IsValid(cp)
        local cpTargetStr = isCP and ("cp:" .. cp:EntIndex()) or nil

        card.Think = function(self)
            self.hover = Lerp(FrameTime() * 8, self.hover, self:IsHovered() and 1 or 0)
        end

        card.Paint = function(self, pw, ph)
            local a = frame.appear
            local selected =
                (isBase and selectedSpawnTarget == nil) or
                (isCP and selectedSpawnTarget == cpTargetStr) or
                (not isBase and not isCP and selectedSpawnTarget == sid)

            local alive, locked, lockLeft = true, false, 0
            if isCP then
                if not IsValid(cp) then alive = false
                else
                    local until_ = (cp.GetAttackUntil and cp:GetAttackUntil() or 0)
                    lockLeft = until_ - CurTime()
                    if lockLeft > 0 then locked = true end
                end
            elseif not isBase then
                alive = IsValid(ply) and ply:Alive()
                if alive then
                    lockLeft = (ply:GetNWFloat("WarsesSpawnLockUntil", 0) or 0) - CurTime()
                    if lockLeft > 0 then locked = true end
                end
            end
            local disabled = (not isBase) and (not alive or locked)

            local r, g, b = 22, 24, 32
            if disabled then r, g, b = 40, 22, 22
            elseif selected then r, g, b = 26, 55, 30 end
            local hov = self.hover
            surface.SetDrawColor(r + hov * 18, g + hov * 18, b + hov * 22, 240 * a)
            surface.DrawRect(0, 0, pw, ph)

            local accent = Color(120, 170, 255)
            if isBase then accent = Color(255, 200, 80)
            elseif disabled then accent = Color(255, 100, 100)
            elseif selected then accent = Color(120, 255, 140) end
            surface.SetDrawColor(accent.r, accent.g, accent.b, 230 * a)
            surface.DrawRect(0, 0, 3, ph)

            if selected then
                local pulse = 0.6 + 0.4 * math.sin(CurTime() * 5)
                surface.SetDrawColor(120, 255, 140, 220 * pulse * a)
                surface.DrawOutlinedRect(0, 0, pw, ph, 2)
            end

            if isBase then
                draw.SimpleText("БАЗА", "Warses_CM_Btn",
                    pw / 2, 16, Color(255, 255, 255, 255 * a),
                    TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                draw.SimpleText("Стандартный спавн", "Warses_CM_Small",
                    pw / 2, ph - 16, Color(190, 195, 210, 240 * a),
                    TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            elseif isCP then
                local cpName = IsValid(cp) and cp:GetPointName() or "Точка"
                draw.SimpleText(cpName, "Warses_CM_Btn",
                    10, 12, Color(255, 255, 255, 255 * a),
                    TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                if locked then
                    draw.SimpleText("ПОД АТАКОЙ " .. math.ceil(lockLeft) .. "с",
                        "Warses_CM_Small",
                        10, ph - 18, Color(255, 130, 100, 240 * a),
                        TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                else
                    draw.SimpleText("Захвачено",
                        "Warses_CM_Small",
                        10, ph - 18, Color(150, 220, 255, 240 * a),
                        TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                end
            else
                local nick = IsValid(ply) and ply:Nick() or "—"
                local cls = ""
                if IsValid(ply) then
                    local c = ply:GetNWString("Class", "")
                    if c ~= "" and GAMEMODE.Classes[c] then cls = GAMEMODE.Classes[c].name end
                end
                local isLeader = false
                local mySquad = WarsesGetMySquad and WarsesGetMySquad() or nil
                if mySquad and mySquad.leader == sid then isLeader = true end

                local nameCol = Color(235, 235, 240)
                if disabled then nameCol = Color(180, 180, 180) end

                local prefix = isLeader and "★ " or ""
                draw.SimpleText(prefix .. nick, "Warses_CM_Btn",
                    10, 12,
                    Color(nameCol.r, nameCol.g, nameCol.b, 255 * a),
                    TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

                if not alive then
                    draw.SimpleText("МЁРТВ", "Warses_CM_Small",
                        10, ph - 18, Color(255, 110, 110, 240 * a),
                        TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                elseif locked then
                    draw.SimpleText("ПОД ОГНЁМ " .. math.ceil(lockLeft) .. "с",
                        "Warses_CM_Small",
                        10, ph - 18, Color(255, 130, 100, 240 * a),
                        TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                else
                    draw.SimpleText(cls ~= "" and cls or "Готов",
                        "Warses_CM_Small",
                        10, ph - 18, Color(190, 200, 220, 240 * a),
                        TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                end
            end
        end

        card.DoClick = function(self)
            if isBase then
                selectedSpawnTarget = nil
                surface.PlaySound("buttons/button17.wav")
                return
            end
            if isCP then
                if not IsValid(cp) then
                    surface.PlaySound("buttons/button10.wav"); return
                end
                local until_ = (cp.GetAttackUntil and cp:GetAttackUntil() or 0)
                if until_ - CurTime() > 0 then
                    surface.PlaySound("buttons/button10.wav"); return
                end
                selectedSpawnTarget = cpTargetStr
                surface.PlaySound("buttons/button17.wav")
                return
            end
            if not IsValid(ply) or not ply:Alive() then
                surface.PlaySound("buttons/button10.wav"); return
            end
            local lockLeft = (ply:GetNWFloat("WarsesSpawnLockUntil", 0) or 0) - CurTime()
            if lockLeft > 0 then
                surface.PlaySound("buttons/button10.wav"); return
            end
            selectedSpawnTarget = sid
            surface.PlaySound("buttons/button17.wav")
        end

        return card
    end

    local function RebuildSpawnStrip()
        spawnStrip:Clear()

        local cards = { { isBase = true } }
        if WarsesGetMySquad then
            local squad = WarsesGetMySquad()
            if squad then
                local mySID = LocalPlayer():SteamID()
                for _, sid in ipairs(squad.members) do
                    if sid ~= mySID then
                        local ply
                        for _, p in ipairs(player.GetAll()) do
                            if p:SteamID() == sid then ply = p; break end
                        end
                        cards[#cards + 1] = { isBase = false, sid = sid, ply = ply }
                    end
                end
            end
        end

        local myTeam = LocalPlayer():Team()
        if GAMEMODE.CurrentGameMode ~= "operation"
            and (myTeam == TEAM_ALPHA or myTeam == TEAM_BRAVO) then
            for _, cp in ipairs(ents.FindByClass("warses_capturepoint")) do
                if IsValid(cp) and cp:GetOwningTeam() == myTeam then
                    cards[#cards + 1] = { isCP = true, cp = cp }
                end
            end
        end

        local cw, ch = 170, stripH - 8
        local gap = 8
        local totalW = #cards * cw + (#cards - 1) * gap
        local x = (scrW - totalW) / 2

        for i, c in ipairs(cards) do
            MakeSpawnCard(spawnStrip, i, c.isBase, c.sid, c.ply, x + (i - 1) * (cw + gap), 4, cw, ch, c.cp)
        end
    end

    RebuildSpawnStrip()

    local lastStripRebuild = SysTime()
    spawnStrip.Think = function()
        if SysTime() - lastStripRebuild > 1 then
            lastStripRebuild = SysTime()
            if selectedSpawnTarget then
                if string.sub(selectedSpawnTarget, 1, 3) == "cp:" then
                    local idx = tonumber(string.sub(selectedSpawnTarget, 4)) or 0
                    local cp = Entity(idx)
                    local valid = IsValid(cp) and cp:GetClass() == "warses_capturepoint"
                        and cp:GetOwningTeam() == LocalPlayer():Team()
                    local until_ = (valid and cp.GetAttackUntil) and cp:GetAttackUntil() or 0
                    if not valid or until_ - CurTime() > 0 then
                        selectedSpawnTarget = nil
                    end
                else
                    local p
                    for _, pp in ipairs(player.GetAll()) do
                        if pp:SteamID() == selectedSpawnTarget then p = pp; break end
                    end
                    if not IsValid(p) or not p:Alive()
                        or (p:GetNWFloat("WarsesSpawnLockUntil", 0) - CurTime() > 0) then
                        selectedSpawnTarget = nil
                    end
                end
            end
            RebuildSpawnStrip()
        end
    end

    local spawnBtn = vgui.Create("DButton", frame)
    local btnW, btnH = 280, 60
    spawnBtn:SetSize(btnW, btnH)
    spawnBtn:SetPos(scrW / 2 - btnW / 2, scrH - 90)
    spawnBtn:SetText("")

    spawnBtn.hover = 0
    spawnBtn.Think = function(self)
        self.hover = Lerp(FrameTime() * 8, self.hover, self:IsHovered() and 1 or 0)
    end

    spawnBtn.Paint = function(self, w, h)
        local a = frame.appear
        local canSpawn = selectedClass ~= nil
        if isRespawning then canSpawn = canSpawn and (CurTime() >= respawnTimer) end

        local baseR, baseG, baseB = 50, 60, 50
        local hoverR, hoverG, hoverB = 70, 140, 70
        if not canSpawn then
            baseR, baseG, baseB = 40, 40, 40
            hoverR, hoverG, hoverB = 60, 60, 60
        end

        local hov = self.hover
        local r = math.floor(Lerp(hov, baseR, hoverR))
        local g = math.floor(Lerp(hov, baseG, hoverG))
        local b = math.floor(Lerp(hov, baseB, hoverB))

        surface.SetDrawColor(r, g, b, 245 * a)
        surface.DrawRect(0, 0, w, h)

        if canSpawn then
            local pulse = 0.6 + 0.4 * math.sin(CurTime() * 4)
            surface.SetDrawColor(120, 255, 140, 200 * pulse * a)
            surface.DrawOutlinedRect(0, 0, w, h, 2)
        else
            surface.SetDrawColor(120, 120, 120, 100 * a)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end

        local label = isRespawning and "ВОЗРОДИТЬСЯ" or "В БОЙ"
        local txtCol = canSpawn and Color(255, 255, 255) or Color(150, 150, 150)
        draw.SimpleText(label, "Warses_CM_Btn",
            w / 2, h / 2,
            Color(txtCol.r, txtCol.g, txtCol.b, 255 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    spawnBtn.DoClick = function()
        if not selectedClass then
            surface.PlaySound("buttons/button10.wav")
            return
        end
        if isRespawning and CurTime() < respawnTimer then
            surface.PlaySound("buttons/button10.wav")
            return
        end
        net.Start("Warses_RequestSpawn")
        net.WriteBool(selectedSpawnTarget ~= nil)
        if selectedSpawnTarget then net.WriteString(selectedSpawnTarget) end
        net.SendToServer()
        frame:Close()
        surface.PlaySound("buttons/button14.wav")
    end

    local changeBtn = vgui.Create("DButton", frame)
    changeBtn:SetSize(200, 38)
    changeBtn:SetPos(scrW - 220, scrH - 56)
    changeBtn:SetText("")
    changeBtn.hover = 0
    changeBtn.Think = function(self)
        self.hover = Lerp(FrameTime() * 8, self.hover, self:IsHovered() and 1 or 0)
    end
    changeBtn.Paint = function(self, w, h)
        local a = frame.appear
        local hov = self.hover
        surface.SetDrawColor(30 + 25 * hov, 30 + 25 * hov, 35 + 25 * hov, 230 * a)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(170, 170, 170, (120 + 80 * hov) * a)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        draw.SimpleText("Сменить команду", "Warses_CM_Small",
            w / 2, h / 2,
            Color(220, 220, 220, 240 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    changeBtn.DoClick = function()
        frame:Close()
        OpenTeamMenu()
    end
end

net.Receive("Warses_OpenClassMenu", function()
    local isRespawn = net.ReadBool()
    local respawnTime = net.ReadFloat()
    OpenClassMenu(isRespawn, respawnTime)
end)

concommand.Add("warses_classmenu", function() OpenClassMenu(false, 0) end)
