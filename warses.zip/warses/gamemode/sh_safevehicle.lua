WARSES_SafeVeh = WARSES_SafeVeh or {}
WARSES_SafeVeh.Classes = WARSES_SafeVeh.Classes or {}
WARSES_SafeVeh.Models  = WARSES_SafeVeh.Models  or {}

function WARSES_SafeVeh.AddClass(class)
    if not isstring(class) or class == "" then return end
    WARSES_SafeVeh.Classes[string.lower(class)] = true
end

function WARSES_SafeVeh.AddModel(model)
    if not isstring(model) or model == "" then return end
    WARSES_SafeVeh.Models[string.lower(model)] = true
end

local function RegisterDefaults()

    WARSES_SafeVeh.AddClass("lvs_wheeldrive_pz3f")
    WARSES_SafeVeh.AddClass("lvs_wheeldrive_t34")
    WARSES_SafeVeh.AddClass("lvs_wheeldrive_merkava_mk3")
    WARSES_SafeVeh.AddClass("lvs_wheeldrive_merkava_mk4")
end
RegisterDefaults()

local function MatchEntity(e)
    if not IsValid(e) then return false end
    local cls = e.GetClass and e:GetClass() or ""
    if cls ~= "" and WARSES_SafeVeh.Classes[string.lower(cls)] then return true end
    local mdl = e.GetModel and e:GetModel() or ""
    if mdl ~= "" and WARSES_SafeVeh.Models[string.lower(mdl)] then return true end
    return false
end

function WARSES_SafeVeh.IsSafeVehicle(veh)
    if not IsValid(veh) then return false end

    if MatchEntity(veh) then return true, veh end

    local cur = veh
    for _ = 1, 4 do
        cur = IsValid(cur) and cur:GetParent() or nil
        if not IsValid(cur) then break end
        if MatchEntity(cur) then return true, cur end
    end

    for _, key in ipairs({ "LVSBaseEnt", "lvsBaseEnt", "BaseEnt", "Base", "ParentVehicle", "Vehicle" }) do
        local v = veh[key] or (veh.GetNWEntity and veh:GetNWEntity(key))
        if IsValid(v) and MatchEntity(v) then return true, v end
    end

    if veh.lvsGetVehicle then
        local lvsBase = veh:lvsGetVehicle()
        if IsValid(lvsBase) then return true, lvsBase end
    end
    local par = IsValid(veh) and veh:GetParent() or nil
    if IsValid(par) and par.LVS then return true, par end

    local ext = hook.Run("Warses_IsSafeVehicle", veh)
    if ext == true then return true, veh end

    return false
end

function WARSES_SafeVeh.IsPlayerSafe(ply)
    return IsValid(ply) and ply:IsPlayer() and ply:GetNW2Bool("WARSES_SafeVeh", false)
end

if SERVER then
    util.AddNetworkString("WARSES_SafeVeh_Fade")

    local DEBUG = true

    local function dprint(...)
        if not DEBUG then return end
        MsgC(Color(80,200,255), "[Warses/SafeVeh] ", ...)
        Msg("\n")
    end

    dprint("loaded, registered classes: "
        .. table.concat(table.GetKeys(WARSES_SafeVeh.Classes), ", "))

    local function SendFade(ply)
        if not IsValid(ply) then return end
        net.Start("WARSES_SafeVeh_Fade")
        net.Send(ply)
    end

    local function HidePlayerForSafeVehicle(ply)
        if not IsValid(ply) then return end
        if ply.WARSES_SafeVeh_HiddenOld then return end
        ply.WARSES_SafeVeh_HiddenOld = {
            renderMode  = ply:GetRenderMode(),
            drawShadow  = true,
            drawWorldMd = true,
        }
        ply:DrawWorldModel(false)
        ply:DrawShadow(false)
        ply:SetRenderMode(RENDERMODE_NONE)
        ply:SetColor(Color(255, 255, 255, 0))
    end

    local function ShowPlayerAfterSafeVehicle(ply)
        if not IsValid(ply) then return end
        local old = ply.WARSES_SafeVeh_HiddenOld
        ply.WARSES_SafeVeh_HiddenOld = nil
        ply:DrawWorldModel(true)
        ply:DrawShadow(true)
        ply:SetRenderMode(old and old.renderMode or RENDERMODE_NORMAL)
        ply:SetColor(Color(255, 255, 255, 255))
    end

    local function CleanupZcityState(ply)
        if not IsValid(ply) then return end

        timer.Remove("EnterVehicleRag" .. ply:EntIndex())
        timer.Remove("faking_up" .. ply:EntIndex())

        local rag = ply.FakeRagdoll
        if IsValid(rag) then
            rag.override = nil
            rag:Remove()
        end
        ply.FakeRagdoll = nil
        ply:SetNWEntity("FakeRagdoll", NULL)

        local oldRag = ply.FakeRagdollOld
        if IsValid(oldRag) then oldRag:Remove() end
        ply.FakeRagdollOld = nil

        if hg and istable(hg.ragdollFake) then
            hg.ragdollFake[ply] = nil
        end

        ply.zmanipstart = nil
        ply.flinching   = nil
        ply.Flinch      = nil
        ply.fakecd      = 0
        ply.Removed     = nil

        ply:DrawWorldModel(true)
        ply:DrawShadow(true)
        ply:SetRenderMode(RENDERMODE_NORMAL)
        local oldFlashAllowed = ply.oldCanUseFlashlight
        if oldFlashAllowed ~= nil then
            ply:AllowFlashlight(oldFlashAllowed)
            ply.oldCanUseFlashlight = nil
        else
            ply:AllowFlashlight(true)
        end

    end

    hook.Add("PlayerEnteredVehicle", "!warses_safeveh_enter", function(ply, veh, role)
        local ok, matched = WARSES_SafeVeh.IsSafeVehicle(veh)

        local seatCls = IsValid(veh) and veh:GetClass() or "?"
        local par     = IsValid(veh) and veh:GetParent() or NULL
        local parCls  = IsValid(par) and par:GetClass() or "(no parent)"
        dprint("enter " .. tostring(ply)
            .. " seat=" .. seatCls
            .. " parent=" .. parCls
            .. " matched=" .. tostring(ok)
            .. (IsValid(matched) and (" -> " .. matched:GetClass()) or ""))

        if not ok then return end

        ply:SetNW2Bool("WARSES_SafeVeh", true)
        ply.WARSES_SafeVeh = true

        CleanupZcityState(ply)
        HidePlayerForSafeVehicle(ply)
        SendFade(ply)

        timer.Simple(0, function()
            if IsValid(ply) and ply.WARSES_SafeVeh then
                timer.Remove("EnterVehicleRag" .. ply:EntIndex())
            end
        end)

        hook.Run("Warses_SafeVehicleEntered", ply, veh, matched)
    end)

    hook.Add("PlayerLeaveVehicle", "!warses_safeveh_leave", function(ply, veh)
        if not ply.WARSES_SafeVeh then return end

        ply:SetNW2Bool("WARSES_SafeVeh", false)
        ply.WARSES_SafeVeh = nil
        ShowPlayerAfterSafeVehicle(ply)

        hook.Run("Warses_SafeVehicleLeft", ply, veh)
    end)

    hook.Add("PlayerDisconnected", "!warses_safeveh_disc", function(ply)
        ply.WARSES_SafeVeh = nil
    end)

    hook.Add("PlayerDeath", "!warses_safeveh_death", function(ply)
        if ply.WARSES_SafeVeh then
            ply:SetNW2Bool("WARSES_SafeVeh", false)
            ply.WARSES_SafeVeh = nil
            ShowPlayerAfterSafeVehicle(ply)
        end
    end)

    hook.Add("PlayerSpawn", "!warses_safeveh_spawn", function(ply)
        ShowPlayerAfterSafeVehicle(ply)
    end)

    local ZCITY_HOOKS = {
        EntityTakeDamage = {
            "homigrad-damage", "Abnormalties_Weapon", "ExplosiveDamage",
            "HL2Shit", "ZombieInfect",
        },
        ScalePlayerDamage = { "FlinchPlayersOnHit", "remove-effects" },
        StartCommand      = { "hg_lol", "HG_AntiGmodPVP", "ShadowControlAdmin", "kolesiko", "Swarm" },
        SetupMove         = {
            "hg-speed", "HG(StartCommand)", "hg_FallSound", "SV_SYNC",
            "bm_force_foosteps", "AntiCrouchSpam",
        },
        FinishMove        = { "!homigrad-organism" },
        Move              = { "CP_detectland", "PushAwayRagdolls", "hg_RagdollIntoWalls", "fakestatus" },
        CalcMainActivity  = { "RunningAnim", "CustomAnim_Activity", "SLCAnim_Activity", "Swarm" },
        UpdateAnimation   = { "NormAnimki" },
        PlayerTick        = { "ilovefurries" },
    }

    local wrappedFuncs = setmetatable({}, { __mode = "k" })

    local function WrapOne(event, name)
        local bucket = hook.GetTable()[event]
        if not bucket then return false end
        local fn = bucket[name]
        if not fn then return false end
        if wrappedFuncs[fn] then return false end

        local original = fn
        local wrapper = function(a, ...)
            if WARSES_SafeVeh.IsPlayerSafe(a) then return end
            return original(a, ...)
        end
        wrappedFuncs[wrapper] = true

        hook.Add(event, name, wrapper)
        return true
    end

    local function SuppressHooks()
        local total = 0
        for event, names in pairs(ZCITY_HOOKS) do
            for _, name in ipairs(names) do
                if WrapOne(event, name) then total = total + 1 end
            end
        end
        if total > 0 then dprint("wrapped " .. total .. " zcity hook(s)") end
    end

    local function PatchHgFake()
        if not (hg and isfunction(hg.Fake)) then return false end
        if hg._warses_originalFake then return false end
        hg._warses_originalFake = hg.Fake
        hg.Fake = function(ply, ...)
            if WARSES_SafeVeh.IsPlayerSafe(ply) then return end
            return hg._warses_originalFake(ply, ...)
        end
        dprint("hg.Fake monkey-patched")
        return true
    end

    hook.Add("InitPostEntity", "!warses_safeveh_suppress_init", function()
        timer.Simple(1, function()
            SuppressHooks()
            PatchHgFake()
        end)
    end)

    timer.Simple(0, function()
        SuppressHooks()
        PatchHgFake()
    end)

    concommand.Add("warses_safeveh_rewrap", function(ply)
        if IsValid(ply) and not ply:IsSuperAdmin() then return end
        SuppressHooks()
        PatchHgFake()
        dprint("manual rewrap done")
    end)

    local nextTick = 0
    hook.Add("Think", "!warses_safeveh_think", function()
        local now = CurTime()
        if now < nextTick then return end
        nextTick = now + 0.5

        local rewrapNeeded = false

        for _, ply in player.Iterator() do
            if not ply.WARSES_SafeVeh then continue end

            if not ply:InVehicle() then
                ply:SetNW2Bool("WARSES_SafeVeh", false)
                ply.WARSES_SafeVeh = nil
                ShowPlayerAfterSafeVehicle(ply)
                hook.Run("Warses_SafeVehicleLeft", ply, nil)
                continue
            end

            timer.Remove("EnterVehicleRag" .. ply:EntIndex())

            if IsValid(ply.FakeRagdoll) then
                local r = ply.FakeRagdoll
                r.override = nil
                r:Remove()
                ply.FakeRagdoll = nil
                ply:SetNWEntity("FakeRagdoll", NULL)
                if hg and istable(hg.ragdollFake) then hg.ragdollFake[ply] = nil end
                rewrapNeeded = true
            end

            ply.flinching = nil
            ply.Flinch    = nil
        end

        if rewrapNeeded then SuppressHooks() end
    end)
end

if CLIENT then
    local function cdprint(...)
        MsgC(Color(80,200,255), "[Warses/SafeVeh:cl] ", ...)
        Msg("\n")
    end

    local ZCITY_HOOKS_CL = {
        CalcView              = { ["homigrad-view"]         = "arg1" },
        ShouldDrawLocalPlayer = { ["drawlocalplayeralways"] = "arg1" },
        InputMouseApply       = { ["fakeCameraAngles"]      = "local" },
        AdjustMouseSensitivity= { ["AdjustRunSensivityHUY"] = "local" },
        CreateMove            = {
            ["flipmove"]          = "local",
            ["delta-counting-hg"] = "local",
            ["Swarm"]             = "local",
        },

        StartCommand          = { ["WeaponSelector_StartCommand"] = "local" },
        CalcMainActivity      = { ["RunningAnim"] = "arg1", ["SLCAnim_Activity"] = "arg1", ["Swarm"] = "arg1" },
        UpdateAnimation       = { ["NormAnimki"]  = "arg1" },

        RenderScene           = { ["jopa"] = "local" },
    }

    local function IsLocalSafe()
        local lp = LocalPlayer()
        return IsValid(lp) and WARSES_SafeVeh.IsPlayerSafe(lp)
    end

    local wrappedCl = setmetatable({}, { __mode = "k" })

    local function WrapOneCl(event, name, mode)
        local bucket = hook.GetTable()[event]
        if not bucket then return false end
        local fn = bucket[name]
        if not fn then return false end
        if wrappedCl[fn] then return false end

        local original = fn
        local wrapper
        if mode == "arg1" then
            wrapper = function(a, ...)
                if WARSES_SafeVeh.IsPlayerSafe(a) then return end
                return original(a, ...)
            end
        else
            wrapper = function(...)
                if IsLocalSafe() then return end
                return original(...)
            end
        end
        wrappedCl[wrapper] = true

        hook.Add(event, name, wrapper)
        return true
    end

    local function SuppressHooksCl()
        local total = 0
        for event, names in pairs(ZCITY_HOOKS_CL) do
            for name, mode in pairs(names) do
                if WrapOneCl(event, name, mode) then total = total + 1 end
            end
        end
        if total > 0 then cdprint("wrapped " .. total .. " zcity hook(s)") end
    end

    hook.Add("InitPostEntity", "!warses_safeveh_suppress_cl", function()
        timer.Simple(1, SuppressHooksCl)
    end)
    timer.Simple(0, SuppressHooksCl)

    local nextRewrapCl = 0
    hook.Add("Think", "!warses_safeveh_rewrap_cl", function()
        local now = RealTime()
        if now < nextRewrapCl then return end
        nextRewrapCl = now + 1
        SuppressHooksCl()
    end)

    concommand.Add("warses_safeveh_rewrap_cl", function()
        SuppressHooksCl()
        cdprint("manual rewrap done")
    end)

    local FADE_IN  = 0.5
    local HOLD     = 0.1
    local FADE_OUT = 0.5

    local fadeStart = 0

    net.Receive("WARSES_SafeVeh_Fade", function()
        fadeStart = RealTime()
    end)

    hook.Add("HUDPaint", "warses_safeveh_fade", function()
        if fadeStart <= 0 then return end

        local t = RealTime() - fadeStart
        local total = FADE_IN + HOLD + FADE_OUT
        if t >= total then
            fadeStart = 0
            return
        end

        local a
        if t < FADE_IN then
            a = (t / FADE_IN) * 255
        elseif t < FADE_IN + HOLD then
            a = 255
        else
            a = (1 - (t - FADE_IN - HOLD) / FADE_OUT) * 255
        end

        a = math.Clamp(a, 0, 255)

        surface.SetDrawColor(0, 0, 0, a)
        surface.DrawRect(0, 0, ScrW(), ScrH())
    end)
end
