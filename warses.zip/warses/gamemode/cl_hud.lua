surface.CreateFont("Warses_HUD_Score",  {font = "Roboto", size = 26, weight = 800, antialias = true})
surface.CreateFont("Warses_HUD_Time",   {font = "Roboto", size = 22, weight = 700, antialias = true})
surface.CreateFont("Warses_HUD_Tag",    {font = "Roboto", size = 13, weight = 700, antialias = true})
surface.CreateFont("Warses_HUD_Sub",    {font = "Roboto", size = 14, weight = 500, antialias = true})
surface.CreateFont("Warses_HUD_Pill",   {font = "Roboto", size = 15, weight = 800, antialias = true})
surface.CreateFont("Warses_HUD_Small",  {font = "Roboto", size = 11, weight = 600, antialias = true})
surface.CreateFont("Warses_HUD_Title",  {font = "Roboto", size = 56, weight = 900, antialias = true})
surface.CreateFont("Warses_HUD_BigSub", {font = "Roboto", size = 22, weight = 500, antialias = true})
surface.CreateFont("Warses_HUD_BigPill",{font = "Roboto", size = 36, weight = 900, antialias = true})

local surface         = surface
local draw            = draw
local math            = math
local string          = string
local ipairs          = ipairs
local pairs           = pairs
local Lerp            = Lerp
local FrameTime       = FrameTime
local CurTime         = CurTime
local IsValid         = IsValid
local ScrW            = ScrW
local ScrH            = ScrH
local GetGlobalInt    = GetGlobalInt
local team_GetColor   = team.GetColor
local team_GetName    = team.GetName
local math_floor      = math.floor
local math_sin        = math.sin
local math_cos        = math.cos
local math_pi         = math.pi
local math_pi2        = math.pi * 2
local math_pihalf     = math.pi / 2
local math_pow        = math.pow
local math_sqrt       = math.sqrt
local math_round      = math.Round
local math_clamp      = math.Clamp
local string_format   = string.format

local C_BG       = Color(12, 14, 20, 255)
local C_BG2      = Color(40, 44, 54, 230)
local C_PANEL_BG = Color(12, 14, 20, 220)
local C_RED      = Color(190, 35, 40, 255)
local C_WHITE    = Color(255, 255, 255, 255)
local C_GRAY     = Color(220, 220, 220, 255)
local C_GRAY2    = Color(180, 180, 180, 255)
local C_GRAY3    = Color(160, 170, 190, 200)
local C_SHADOW   = Color(0, 0, 0, 180)
local C_FILL     = Color(170, 170, 170, 240)
local C_PULSE    = Color(255, 255, 255, 255)
local C_HP_LOW   = Color(255, 90, 90, 255)
local C_HP_MID   = Color(255, 200, 80, 255)
local C_HP_HIGH  = Color(120, 230, 140, 255)
local C_DOT_DEAD = Color(255, 90, 90, 255)
local C_DOT_LOCK = Color(255, 150, 70, 255)
local C_DOT_GONE = Color(120, 120, 120, 255)

local TC_ALPHA, TC_BRAVO
local function refreshTeamColors()
    if team.Valid(TEAM_ALPHA) then TC_ALPHA = team_GetColor(TEAM_ALPHA) end
    if team.Valid(TEAM_BRAVO) then TC_BRAVO = team_GetColor(TEAM_BRAVO) end
end
refreshTeamColors()
hook.Add("InitPostEntity", "Warses_RefreshTeamColors", refreshTeamColors)
hook.Add("OnReloaded",     "Warses_RefreshTeamColors", refreshTeamColors)

local function getTeamColor(t)
    if t == TEAM_ALPHA then return TC_ALPHA or team_GetColor(TEAM_ALPHA) end
    if t == TEAM_BRAVO then return TC_BRAVO or team_GetColor(TEAM_BRAVO) end
    return team_GetColor(t)
end

local CV_ShowSpawn = nil
local function getShowSpawnCV()
    if not CV_ShowSpawn then CV_ShowSpawn = GetConVar("warses_show_spawn") end
    return CV_ShowSpawn
end

local hideHUD = {
    ["CHudHealth"]          = true,
    ["CHudBattery"]         = true,
    ["CHudAmmo"]            = true,
    ["CHudSecondaryAmmo"]   = true,
    ["CHudDamageIndicator"] = true,
}
hook.Add("HUDShouldDraw", "Warses_HideDefaultHUD", function(name)
    if hideHUD[name] then return false end
end)

local function Approach(cur, target, speed)
    return math.Approach(cur, target, FrameTime() * speed)
end

local SmoothState = {
    alphaScore = 0,
    bravoScore = 0,
    tickets    = 0,
    capProgress = {},
    fadeIn     = 0,
    deathFade  = 0,
}

hook.Add("Think", "Warses_HUDFade", function()
    local ply = LocalPlayer()
    if IsValid(ply) and ply:Alive() and ply:Team() ~= TEAM_SPECTATOR then
        SmoothState.fadeIn = Approach(SmoothState.fadeIn, 1, 2.5)
    else
        SmoothState.fadeIn = Approach(SmoothState.fadeIn, 0, 4)
    end
end)

local function DrawRect(x, y, w, h, c)
    surface.SetDrawColor(c.r, c.g, c.b, c.a or 255)
    surface.DrawRect(x, y, w, h)
end

local function DrawRectRGBA(x, y, w, h, r, g, b, a)
    surface.SetDrawColor(r, g, b, a)
    surface.DrawRect(x, y, w, h)
end

local function DrawText(text, font, x, y, col, alignX, alignY)
    surface.SetFont(font)
    local tw, th = surface.GetTextSize(text)
    if alignX == TEXT_ALIGN_CENTER then x = x - tw / 2
    elseif alignX == TEXT_ALIGN_RIGHT then x = x - tw end
    if alignY == TEXT_ALIGN_CENTER then y = y - th / 2
    elseif alignY == TEXT_ALIGN_BOTTOM then y = y - th end
    surface.SetTextColor(0, 0, 0, 180)
    surface.SetTextPos(x + 1, y + 1)
    surface.DrawText(text)
    surface.SetTextColor(col.r, col.g, col.b, col.a or 255)
    surface.SetTextPos(x, y)
    surface.DrawText(text)
end

local function DrawTextRGBA(text, font, x, y, r, g, b, a, alignX, alignY)
    surface.SetFont(font)
    local tw, th = surface.GetTextSize(text)
    if alignX == TEXT_ALIGN_CENTER then x = x - tw / 2
    elseif alignX == TEXT_ALIGN_RIGHT then x = x - tw end
    if alignY == TEXT_ALIGN_CENTER then y = y - th / 2
    elseif alignY == TEXT_ALIGN_BOTTOM then y = y - th end
    surface.SetTextColor(0, 0, 0, 180)
    surface.SetTextPos(x + 1, y + 1)
    surface.DrawText(text)
    surface.SetTextColor(r, g, b, a)
    surface.SetTextPos(x, y)
    surface.DrawText(text)
end

local _ringPoly = {{x=0,y=0},{x=0,y=0},{x=0,y=0},{x=0,y=0}}
local _ringCS = {}

local function _getRingCS(segments)
    local entry = _ringCS[segments]
    if entry then return entry end
    entry = {}
    local startAng = -math_pihalf
    local step = math_pi2 / segments
    for i = 0, segments do
        local a = startAng + i * step
        entry[i * 2 + 1] = math_cos(a)
        entry[i * 2 + 2] = math_sin(a)
    end
    _ringCS[segments] = entry
    return entry
end

local function DrawRadialRing(cx, cy, outerR, innerR, progress, color, segments)
    segments = segments or 60
    progress = math_clamp(progress, 0, 1)
    if progress <= 0 then return end

    surface.SetDrawColor(color.r, color.g, color.b, color.a or 255)
    draw.NoTexture()

    local fullAngle = progress * math_pi2
    local startAng  = -math_pihalf
    local cs = _getRingCS(segments)
    local poly = _ringPoly
    local step = math_pi2 / segments

    for i = 0, segments - 1 do
        local a1 = i * step
        local a2 = (i + 1) * step

        if a1 > fullAngle then break end

        local c1 = cs[i * 2 + 1]
        local s1 = cs[i * 2 + 2]
        local c2, s2
        if a2 > fullAngle then
            local cap = startAng + fullAngle
            c2 = math_cos(cap)
            s2 = math_sin(cap)
        else
            c2 = cs[(i + 1) * 2 + 1]
            s2 = cs[(i + 1) * 2 + 2]
        end

        poly[1].x = cx + c1 * outerR; poly[1].y = cy + s1 * outerR
        poly[2].x = cx + c2 * outerR; poly[2].y = cy + s2 * outerR
        poly[3].x = cx + c2 * innerR; poly[3].y = cy + s2 * innerR
        poly[4].x = cx + c1 * innerR; poly[4].y = cy + s1 * innerR
        surface.DrawPoly(poly)
    end
end

local _circlePolyCache = {}
local function _getCirclePolyTemplate(segments)
    local t = _circlePolyCache[segments]
    if t then return t end
    t = {}
    for i = 0, segments - 1 do
        local ang = (i / segments) * math_pi2
        t[i + 1] = { x = math_cos(ang), y = math_sin(ang) }
    end
    _circlePolyCache[segments] = t
    return t
end

local _circleScratch = {}
local function _getCircleScratch(segments)
    local s = _circleScratch[segments]
    if s and #s == segments then return s end
    s = {}
    for i = 1, segments do s[i] = { x = 0, y = 0 } end
    _circleScratch[segments] = s
    return s
end

local function DrawFilledCircle(cx, cy, r, color, segments)
    segments = segments or 48
    surface.SetDrawColor(color.r, color.g, color.b, color.a or 255)
    draw.NoTexture()
    local tpl = _getCirclePolyTemplate(segments)
    local scratch = _getCircleScratch(segments)
    for i = 1, segments do
        local t = tpl[i]
        local s = scratch[i]
        s.x = cx + t.x * r
        s.y = cy + t.y * r
    end
    surface.DrawPoly(scratch)
end

local _timeTextCache = { gt = -1, txt = "00:00" }
local function _formatGameTime(gt)
    if _timeTextCache.gt == gt then return _timeTextCache.txt end
    _timeTextCache.gt  = gt
    _timeTextCache.txt = string_format("%02d:%02d", math_floor(gt / 60), gt % 60)
    return _timeTextCache.txt
end

local function DrawTopPanel(scrW)
    local a = SmoothState.fadeIn
    if a <= 0.01 then return end

    local boxW, boxH = 320, 44
    local x = scrW / 2 - boxW / 2
    local y = Lerp(a, -boxH, 12)

    DrawRectRGBA(x, y, boxW, boxH, 12, 14, 20, 220 * a)
    DrawRectRGBA(x, y, boxW, 2,    190, 35, 40, 230 * a)

    if GAMEMODE.CurrentGameMode == "operation" then
        local tickets = GetGlobalInt("AttackerTickets", 0)
        local sector  = GetGlobalInt("ActiveSector", 1)
        SmoothState.tickets = Approach(SmoothState.tickets, tickets,
            math.max(20, math.abs(tickets - SmoothState.tickets) * 4))

        local timeText = _formatGameTime(GetGlobalInt("GameTime", 0))

        DrawTextRGBA("ТИКЕТЫ", "Warses_HUD_Tag", x + 50, y + 8,
            255, 110, 110, 220 * a, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        DrawTextRGBA(tostring(math_floor(SmoothState.tickets)), "Warses_HUD_Score",
            x + 50, y + 23, 255, 130, 130, 255 * a,
            TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

        DrawTextRGBA(timeText, "Warses_HUD_Time", x + boxW / 2, y + boxH / 2,
            255, 255, 255, 255 * a, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        DrawTextRGBA("СЕКТОР", "Warses_HUD_Tag", x + boxW - 50, y + 8,
            120, 170, 255, 220 * a, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        DrawTextRGBA(tostring(sector), "Warses_HUD_Score",
            x + boxW - 50, y + 23, 140, 180, 255, 255 * a,
            TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    else
        local aa = GetGlobalInt("AlphaScore", 0)
        local bb = GetGlobalInt("BravoScore", 0)
        SmoothState.alphaScore = Approach(SmoothState.alphaScore, aa,
            math.max(40, math.abs(aa - SmoothState.alphaScore) * 3))
        SmoothState.bravoScore = Approach(SmoothState.bravoScore, bb,
            math.max(40, math.abs(bb - SmoothState.bravoScore) * 3))

        local timeText = _formatGameTime(GetGlobalInt("GameTime", 0))

        local aCol = TC_ALPHA or getTeamColor(TEAM_ALPHA)
        local bCol = TC_BRAVO or getTeamColor(TEAM_BRAVO)

        DrawRectRGBA(x, y, 4, boxH, aCol.r, aCol.g, aCol.b, 230 * a)
        DrawTextRGBA(tostring(math_floor(SmoothState.alphaScore)), "Warses_HUD_Score",
            x + 50, y + boxH / 2, aCol.r, aCol.g, aCol.b, 255 * a,
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        DrawTextRGBA(timeText, "Warses_HUD_Time", x + boxW / 2, y + boxH / 2,
            255, 255, 255, 255 * a, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        DrawRectRGBA(x + boxW - 4, y, 4, boxH, bCol.r, bCol.g, bCol.b, 230 * a)
        DrawTextRGBA(tostring(math_floor(SmoothState.bravoScore)), "Warses_HUD_Score",
            x + boxW - 50, y + boxH / 2, bCol.r, bCol.g, bCol.b, 255 * a,
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local conflict = GAMEMODE.Conflicts[GAMEMODE.CurrentConflict]
    if conflict then
        local sub = conflict.subconflicts[GAMEMODE.CurrentSubconflict]
        if sub then
            local subLabel = sub.name
            if GAMEMODE.CurrentGameMode == "deathmatch" then
                local goal = Warses_CV_DMWinScore and Warses_CV_DMWinScore:GetInt() or 250
                subLabel = "DEATHMATCH • до " .. goal
            end
            DrawTextRGBA(subLabel, "Warses_HUD_Sub", scrW / 2, y + boxH + 4,
                220, 80, 75, 210 * a, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        end
    end
end

local function DrawTeamCard(scrW)
    local a = SmoothState.fadeIn
    if a <= 0.01 then return end

    local ply = LocalPlayer()
    local teamID = ply:Team()
    local tc = getTeamColor(teamID)
    local tn = team_GetName(teamID)

    local w, h = 180, 30
    local x = scrW / 2 + 180
    local y = 12

    DrawRectRGBA(x, y, w, h, 12, 14, 20, 200 * a)
    DrawRectRGBA(x, y, 3, h, tc.r, tc.g, tc.b, 230 * a)

    DrawTextRGBA(tn, "Warses_HUD_Pill", x + 10, y + h / 2,
        tc.r, tc.g, tc.b, 240 * a, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

    local cls = ply:GetNWString("Class", "")
    if cls == "" and LocalPlayerState then cls = LocalPlayerState.class or "" end
    if cls ~= "" and GAMEMODE.Classes[cls] then
        DrawTextRGBA(GAMEMODE.Classes[cls].name, "Warses_HUD_Small",
            x + w - 10, y + h / 2,
            220, 220, 220, 220 * a,
            TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
    end
end

local _activeCPs        = {}
local _sortNameCache    = {}
local _lastSortSig      = ""
local _sortedSig        = ""

local function _byPointName(a, b)
    return _sortNameCache[a] < _sortNameCache[b]
end

local function DrawCapturePoints(scrW)
    local a = SmoothState.fadeIn
    if a <= 0.01 then return end

    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local points = Warses_GetCPs()
    local nActive = 0
    local activeSector = GetGlobalInt("ActiveSector", 1)
    local isOperation = GAMEMODE.CurrentGameMode == "operation"

    for i = 1, #points do
        local p = points[i]
        if IsValid(p) then
            local ok = true
            if isOperation and p.GetSector then
                ok = p:GetSector() == activeSector
            end
            if ok then
                nActive = nActive + 1
                _activeCPs[nActive] = p
                _sortNameCache[p] = p:GetPointName() or ""
            end
        end
    end
    for i = nActive + 1, #_activeCPs do _activeCPs[i] = nil end
    if nActive == 0 then return end

    local sig = nActive .. ":" .. (_activeCPs[1] and _sortNameCache[_activeCPs[1]] or "")
    if nActive > 1 then
        sig = sig .. "|" .. (_sortNameCache[_activeCPs[nActive]] or "")
    end
    if sig ~= _sortedSig then
        if nActive > 1 then
            for i = 2, nActive do
                local cur = _activeCPs[i]
                local curName = _sortNameCache[cur]
                local j = i - 1
                while j >= 1 and _sortNameCache[_activeCPs[j]] > curName do
                    _activeCPs[j + 1] = _activeCPs[j]
                    j = j - 1
                end
                _activeCPs[j + 1] = cur
            end
        end
        _sortedSig = sig
    end

    local inZonePoint = nil
    for i = 1, nActive do
        local ent = _activeCPs[i]
        if ent.IsPlayerInZone and ent:IsPlayerInZone(ply) then
            inZonePoint = ent
            break
        end
    end

    local smallR, smallInR = 14, 10
    local bigR,   bigInR   = 56, 44
    local spacing  = 14
    local diameter = smallR * 2
    local totalW   = nActive * diameter + (nActive - 1) * spacing
    local startX   = (scrW - totalW) / 2
    local topY     = 88 + smallR
    local bigX, bigY = scrW / 2, ScrH() - 130

    SmoothState.capCircle = SmoothState.capCircle or {}
    local capCircle  = SmoothState.capCircle
    local capProg    = SmoothState.capProgress
    local ft         = FrameTime()
    local lerpFactor = ft * 6
    local plyEyePos  = ply:EyePos()
    local curT       = CurTime()
    local pulseSin   = 0.5 + 0.5 * math_sin(curT * 6)

    for i = 1, nActive do
        local ent = _activeCPs[i]
        local idx = ent:EntIndex()
        local isActive = (ent == inZonePoint) and 1 or 0

        local s = capCircle[idx]
        if not s then s = { t = 0 }; capCircle[idx] = s end
        s.t = Lerp(lerpFactor, s.t, isActive)
        local big = s.t

        local slotX  = startX + (i - 1) * (diameter + spacing) + smallR
        local cx     = Lerp(big, slotX, bigX)
        local cy     = Lerp(big, topY,  bigY)
        local outerR = Lerp(big, smallR,  bigR)
        local innerR = Lerp(big, smallInR, bigInR)

        local owner    = ent:GetOwningTeam()
        local progTeam = ent.GetProgressTeam and ent:GetProgressTeam() or 0
        local rawProg  = (ent.GetCaptureProgress and ent:GetCaptureProgress() or 0) / 100
        capProg[idx]   = Approach(capProg[idx] or 0, rawProg, 1.4)
        local progress = capProg[idx]

        local fillTeam = owner ~= 0 and owner or (progTeam ~= 0 and progTeam or 0)
        if fillTeam == TEAM_ALPHA then
            local c = TC_ALPHA or getTeamColor(TEAM_ALPHA)
            C_FILL.r, C_FILL.g, C_FILL.b = c.r, c.g, c.b
        elseif fillTeam == TEAM_BRAVO then
            local c = TC_BRAVO or getTeamColor(TEAM_BRAVO)
            C_FILL.r, C_FILL.g, C_FILL.b = c.r, c.g, c.b
        else
            C_FILL.r, C_FILL.g, C_FILL.b = 170, 170, 170
        end
        C_FILL.a = 240 * a

        C_BG2.a = 230 * a
        DrawRadialRing(cx, cy, outerR, innerR, 1, C_BG2, 48)

        if progress > 0 then
            DrawRadialRing(cx, cy, outerR, innerR, progress, C_FILL, 64)
        end

        local capTeam = ent.GetCapturingTeam and ent:GetCapturingTeam() or 0
        if capTeam > 0 then
            local c = getTeamColor(capTeam)
            C_PULSE.r = c.r; C_PULSE.g = c.g; C_PULSE.b = c.b
            C_PULSE.a = 180 * pulseSin * a
            DrawRadialRing(cx, cy, outerR + 2 + big * 4, outerR, 1, C_PULSE, 48)
        end

        if big > 0.05 then
            C_BG.a = 230 * big * a
            DrawFilledCircle(cx, cy, innerR + 2, C_BG, 48)
        end

        local letterFont = big > 0.5 and "Warses_HUD_BigPill" or "Warses_HUD_Pill"
        DrawTextRGBA(_sortNameCache[ent], letterFont,
            cx, cy - 8 * big,
            255, 255, 255, 255 * a, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        if big > 0.05 then
            local pct = math_round(progress * 100) .. "%"
            DrawTextRGBA(pct, "Warses_HUD_Sub",
                cx, cy + 18,
                C_FILL.r, C_FILL.g, C_FILL.b, 240 * big * a,
                TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end

        local target = ent.GetTopZonePos and ent:GetTopZonePos() or ent:GetPos()
        local distM  = math_round(plyEyePos:Distance(target) / 39.37)

        local progressOwner = owner > 0 and owner or (progTeam > 0 and progTeam or 0)
        local statusText = "НЕЙТРАЛЬНО"
        local sr, sg, sb = 220, 220, 220
        if capTeam > 0 then
            statusText = (progressOwner > 0 and progressOwner ~= capTeam)
                and "НЕЙТРАЛИЗАЦИЯ" or "ЗАХВАТ"
            local c = getTeamColor(capTeam); sr, sg, sb = c.r, c.g, c.b
        elseif owner > 0 then
            statusText = (progress < 1) and "ЗАКРЕПЛЕНИЕ" or team_GetName(owner)
            local c = getTeamColor(owner); sr, sg, sb = c.r, c.g, c.b
        end

        local labelY = cy + outerR + 10
        if big < 0.95 then
            DrawTextRGBA(distM .. " м", "Warses_HUD_Small",
                cx, labelY, 220, 220, 220, 220 * (1 - big) * a,
                TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        if big > 0.05 then
            DrawTextRGBA(statusText, "Warses_HUD_Sub",
                cx, labelY, sr, sg, sb, 240 * big * a,
                TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end
end

local _sidLookup    = {}
local _sidLookupT   = -1
local function _refreshSIDLookup()
    if CurTime() - _sidLookupT < 0.5 then return _sidLookup end
    _sidLookupT = CurTime()
    for k in pairs(_sidLookup) do _sidLookup[k] = nil end
    local plys = player.GetAll()
    for i = 1, #plys do
        local p = plys[i]
        if IsValid(p) then _sidLookup[p:SteamID()] = p end
    end
    return _sidLookup
end

local function DrawSquadWidget(scrW, scrH)
    local a = SmoothState.fadeIn
    if a <= 0.01 then return end
    if not WarsesGetMySquad then return end
    local squad = WarsesGetMySquad()
    if not squad then return end

    local ply = LocalPlayer()
    local mySID = ply:SteamID()
    local sidLookup = _refreshSIDLookup()

    local rowH    = 26
    local headerH = 28
    local pad     = 8
    local w       = 230
    local membersN = #squad.members
    local h = headerH + pad + membersN * rowH + pad
    local x = 16
    local y = scrH * 0.32

    DrawRectRGBA(x, y, w, h, 12, 14, 20, 220 * a)
    local teamCol = getTeamColor(ply:Team())
    DrawRectRGBA(x, y, 3, h, teamCol.r, teamCol.g, teamCol.b, 230 * a)

    DrawTextRGBA(squad.name or "ОТРЯД", "Warses_HUD_Pill",
        x + 10, y + headerH / 2,
        255, 255, 255, 240 * a,
        TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    DrawTextRGBA(membersN .. "/" .. (SQUAD_MAX_MEMBERS or 6), "Warses_HUD_Small",
        x + w - 10, y + headerH / 2,
        180, 200, 220, 220 * a,
        TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

    DrawRectRGBA(x, y + headerH, w, 1, 80, 90, 110, 120 * a)

    local ry  = y + headerH + pad / 2
    local now = CurTime()
    local members = squad.members
    for i = 1, membersN do
        local sid    = members[i]
        local member = sidLookup[sid]
        local isMe       = (sid == mySID)
        local isLeader   = (squad.leader == sid)

        local memberValid = IsValid(member)
        local alive       = memberValid and member:Alive()
        local lockLeft    = 0
        if alive then lockLeft = (member:GetNWFloat("WarsesSpawnLockUntil", 0) or 0) - now end

        local dr, dg, db
        if not memberValid then dr, dg, db = 120, 120, 120
        elseif not alive   then dr, dg, db = 255, 90,  90
        elseif lockLeft > 0 then dr, dg, db = 255, 150, 70
        else                     dr, dg, db = 120, 230, 140 end
        C_PULSE.r = dr; C_PULSE.g = dg; C_PULSE.b = db; C_PULSE.a = 240 * a
        DrawFilledCircle(x + 14, ry + rowH / 2, 5, C_PULSE, 16)

        local nick = memberValid and member:Nick() or "—"
        local namePrefix = isLeader and "★ " or ""
        local nr, ng, nb = 235, 235, 240
        if isMe then nr, ng, nb = 120, 255, 140 end
        DrawTextRGBA(namePrefix .. nick, "Warses_HUD_Small",
            x + 26, ry + 6, nr, ng, nb, 240 * a,
            TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

        if memberValid then
            local right = x + w - 10
            if alive and lockLeft > 0 then
                DrawTextRGBA(math.ceil(lockLeft) .. "с", "Warses_HUD_Small",
                    right, ry + 6, 255, 150, 70, 240 * a,
                    TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
            else
                local cls = member:GetNWString("Class", "")
                local clsName = (cls ~= "" and GAMEMODE.Classes[cls]) and GAMEMODE.Classes[cls].name or ""
                if alive and clsName ~= "" then
                    DrawTextRGBA(clsName, "Warses_HUD_Small",
                        right, ry + 6, 180, 200, 220, 220 * a,
                        TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
                end
            end
            if alive then
                local hp = math_clamp(member:Health() / 100, 0, 1)
                local bx, by, bw, bh = x + 26, ry + rowH - 6, w - 50, 2
                DrawRectRGBA(bx, by, bw, bh, 50, 55, 65, 200 * a)
                local hr, hg, hb
                if hp > 0.5 then hr, hg, hb = 120, 230, 140
                elseif hp > 0.25 then hr, hg, hb = 255, 200, 80
                else hr, hg, hb = 255, 90, 90 end
                DrawRectRGBA(bx, by, bw * hp, bh, hr, hg, hb, 230 * a)
            end
        end

        ry = ry + rowH
    end

    DrawTextRGBA("F3 — меню отрядов", "Warses_HUD_Small",
        x + 10, y + h + 4,
        160, 170, 190, 200 * a,
        TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
end

local function DrawDroneHint(scrW, scrH)
    local a = SmoothState.fadeIn
    if a <= 0.01 then return end

    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    if ply:GetNWString("Class", "") ~= "support" then return end
    if GAMEMODE.CurrentConflict ~= "modern" then return end
    if GAMEMODE.CurrentSubconflict ~= "nato" then return end

    local w, h = 150, 26
    local x = scrW - w - 16
    local y = scrH - h - 16

    DrawRectRGBA(x, y, w, h, 12, 14, 20, 220 * a)
    DrawRectRGBA(x, y, 3, h, 120, 200, 255, 230 * a)

    DrawRectRGBA(x + 8, y + 5, 16, 16, 40, 50, 70, 240 * a)
    DrawTextRGBA("T", "Warses_HUD_Small", x + 16, y + 13,
        255, 255, 255, 240 * a,
        TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

    DrawTextRGBA("Дрон-камикадзе", "Warses_HUD_Small",
        x + 32, y + h / 2,
        220, 240, 255, 220 * a,
        TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end

hook.Add("HUDPaint", "Warses_DrawHUD", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    local scrW, scrH = ScrW(), ScrH()

    DrawTopPanel(scrW)
    DrawCapturePoints(scrW)

    if ply:Alive() and ply:Team() ~= TEAM_SPECTATOR then
        DrawTeamCard(scrW)
        DrawSquadWidget(scrW, scrH)
        DrawDroneHint(scrW, scrH)
    end
end)

local OpNotify = { text = "", alpha = 0, color = Color(255, 255, 255), scale = 1, life = 0 }

net.Receive("Warses_OperationNotify", function()
    local teamWon = net.ReadInt(8)
    local myTeam = LocalPlayer():Team()
    if myTeam == teamWon then
        OpNotify.text  = "СЕКТОР ЗАХВАЧЕН"
        OpNotify.color = Color(120, 255, 130)
        surface.PlaySound("garrysmod/save_load1.wav")
    else
        OpNotify.text  = "СЕКТОР ПОТЕРЯН"
        OpNotify.color = Color(255, 110, 110)
        surface.PlaySound("buttons/button8.wav")
    end
    OpNotify.alpha = 255
    OpNotify.scale = 0.6
    OpNotify.life  = CurTime() + 3
end)

hook.Add("HUDPaint", "Warses_OperationNotifyDraw", function()
    if OpNotify.alpha <= 0 then return end
    local scrW, scrH = ScrW(), ScrH()
    OpNotify.scale = Lerp(FrameTime() * 6, OpNotify.scale, 1)
    if CurTime() > OpNotify.life then
        OpNotify.alpha = Approach(OpNotify.alpha, 0, 250)
    end

    local a = OpNotify.alpha
    local sc = OpNotify.scale
    local boxW, boxH = 420 * sc, 70 * sc
    local x = scrW / 2 - boxW / 2
    local y = scrH * 0.28
    local cr, cg, cb = OpNotify.color.r, OpNotify.color.g, OpNotify.color.b

    DrawRectRGBA(x, y, boxW, boxH, 12, 14, 20, 220 * a / 255)
    DrawRectRGBA(x, y, boxW, 3, cr, cg, cb, a)
    DrawRectRGBA(x, y + boxH - 3, boxW, 3, cr, cg, cb, a)

    DrawTextRGBA(OpNotify.text, "Warses_HUD_BigSub",
        scrW / 2, y + boxH / 2,
        cr, cg, cb, a,
        TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)

hook.Add("HUDPaint", "Warses_DeathScreen", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    if Warses_IsZombieCutsceneFullscreen and Warses_IsZombieCutsceneFullscreen() then
        SmoothState.deathFade = 0
        return
    end

    local dead = (not ply:Alive()) and ply:Team() ~= TEAM_SPECTATOR
    if dead then
        SmoothState.deathFade = Approach(SmoothState.deathFade, 1, 1.6)
    else
        SmoothState.deathFade = Approach(SmoothState.deathFade, 0, 4)
    end

    if SmoothState.deathFade <= 0.001 then return end

    local a = SmoothState.deathFade
    local scrW, scrH = ScrW(), ScrH()

    DrawRectRGBA(0, 0, scrW, scrH, 0, 0, 0, 170 * a)
    local bar = 60 * a
    DrawRectRGBA(0, 0, scrW, bar, 0, 0, 0, 255 * a)
    DrawRectRGBA(0, scrH - bar, scrW, bar, 0, 0, 0, 255 * a)

    local drift = math_sin(CurTime() * 1.2) * 4
    DrawTextRGBA("ВЫ УБИТЫ", "Warses_HUD_Title",
        scrW / 2, scrH / 2 - 30 + drift,
        255, 70, 70, 255 * a, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    DrawTextRGBA("Выберите класс и ждите возрождения", "Warses_HUD_BigSub",
        scrW / 2, scrH / 2 + 24 + drift,
        220, 220, 220, 220 * a, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)
