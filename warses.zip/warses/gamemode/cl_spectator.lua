WARSES_SPEC_FREE  = 0
WARSES_SPEC_FIRST = 1
WARSES_SPEC_CHASE = 2

local SPEC_CMD_CYCLE  = 1
local SPEC_CMD_MODE   = 2
local SPEC_CMD_DETACH = 3

local SpecState = {
    mode   = WARSES_SPEC_FREE,
    target = NULL,
    msg    = "",
    msgUntil = 0,
}

net.Receive("Warses_SpecState", function()
    SpecState.mode   = net.ReadInt(8)
    SpecState.target = net.ReadEntity()
end)

net.Receive("Warses_SpecMsg", function()
    SpecState.msg = net.ReadString()
    SpecState.msgUntil = CurTime() + 6
end)

local function SendCmd(cmd, dir)
    net.Start("Warses_SpecCmd")
        net.WriteInt(cmd, 8)
        net.WriteInt(dir or 0, 8)
    net.SendToServer()
end

local function IsLocalSpectating()
    local lp = LocalPlayer()
    if not IsValid(lp) then return false end
    return lp:Team() == TEAM_SPECTATOR
end

local nextInput = 0
hook.Add("CreateMove", "Warses_SpecInput", function(cmd)
    if not IsLocalSpectating() then return end
    if vgui.CursorVisible() then return end
    if CurTime() < nextInput then return end

    local b = cmd:GetButtons()
    local function pressed(flag) return bit.band(b, flag) ~= 0 end

    if pressed(IN_ATTACK) then
        SendCmd(SPEC_CMD_CYCLE, 1)
        nextInput = CurTime() + 0.25
    elseif pressed(IN_ATTACK2) then
        SendCmd(SPEC_CMD_CYCLE, -1)
        nextInput = CurTime() + 0.25
    elseif pressed(IN_RELOAD) then
        SendCmd(SPEC_CMD_MODE, 0)
        nextInput = CurTime() + 0.35
    elseif pressed(IN_JUMP) and SpecState.mode ~= WARSES_SPEC_FREE then
        SendCmd(SPEC_CMD_DETACH, 0)
        nextInput = CurTime() + 0.35
    end
end)

local chaseLerpPos = Vector(0, 0, 0)
local chaseLerpAng = Angle(0, 0, 0)
local chaseInit    = false

local _spec_view       = { origin = Vector(0, 0, 0), angles = Angle(0, 0, 0), fov = 0, drawviewer = true }
local _spec_traceMins  = Vector(-6, -6, -6)
local _spec_traceMaxs  = Vector( 6,  6,  6)
local _spec_filter     = { NULL, NULL }
local _spec_trace      = {
    start = Vector(0, 0, 0),
    endpos = Vector(0, 0, 0),
    mins = _spec_traceMins,
    maxs = _spec_traceMaxs,
    filter = _spec_filter,
    mask = MASK_SOLID,
}

hook.Add("CalcView", "Warses_SpecCalcView", function(ply, origin, angles, fov)
    if not IsLocalSpectating() then return end
    if SpecState.mode ~= WARSES_SPEC_CHASE then return end

    local target = SpecState.target
    if not (IsValid(target) and target:IsPlayer() and target:Alive()) then return end

    local desiredAng = target:EyeAngles()
    desiredAng.r = 0
    local back   = -desiredAng:Forward() * 80
    local up     = vector_up * 18
    local eye    = target:EyePos()
    local desiredPos = eye + back + up

    _spec_filter[1] = ply
    _spec_filter[2] = target
    _spec_trace.start  = eye
    _spec_trace.endpos = desiredPos
    local tr = util.TraceHull(_spec_trace)
    if tr.Hit then
        desiredPos = tr.HitPos + tr.HitNormal * 4
    end

    if not chaseInit then
        chaseLerpPos = desiredPos
        chaseLerpAng = desiredAng
        chaseInit = true
    else
        local ft = math.Clamp(FrameTime() * 10, 0, 1)
        chaseLerpPos = LerpVector(ft, chaseLerpPos, desiredPos)
        chaseLerpAng = LerpAngle(ft, chaseLerpAng, desiredAng)
    end

    _spec_view.origin = chaseLerpPos
    _spec_view.angles = chaseLerpAng
    _spec_view.fov    = fov
    _spec_view.drawviewer = true
    return _spec_view
end)

hook.Add("Think", "Warses_SpecChaseReset", function()
    if SpecState.mode ~= WARSES_SPEC_CHASE then chaseInit = false end
end)

surface.CreateFont("Warses_Spec_Title", {
    font = "Roboto", size = 28, weight = 700,
})
surface.CreateFont("Warses_Spec_Sub", {
    font = "Roboto", size = 18, weight = 500,
})
surface.CreateFont("Warses_Spec_Hint", {
    font = "Roboto", size = 16, weight = 400,
})

local function ModeName(m)
    if m == WARSES_SPEC_FREE  then return "Свободный полёт" end
    if m == WARSES_SPEC_FIRST then return "От 1-го лица" end
    if m == WARSES_SPEC_CHASE then return "От 3-го лица" end
    return "—"
end

hook.Add("HUDPaint", "Warses_SpecHUD", function()
    if not IsLocalSpectating() then return end

    local sw, sh = ScrW(), ScrH()
    local w, h = 380, 110
    local x, y = sw / 2 - w / 2, sh - h - 40

    surface.SetDrawColor(0, 0, 0, 170)
    surface.DrawRect(x, y, w, h)
    surface.SetDrawColor(150, 150, 150, 90)
    surface.DrawOutlinedRect(x, y, w, h, 1)

    local target = SpecState.target
    local title  = "Наблюдатель"
    local subCol = Color(200, 200, 200)
    if IsValid(target) and target:IsPlayer() then
        title = target:Nick()
        local tcol = team.GetColor(target:Team())
        subCol = Color(tcol.r, tcol.g, tcol.b)
    end

    draw.SimpleText(title, "Warses_Spec_Title",
        x + w / 2, y + 8,
        subCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

    draw.SimpleText("Режим: " .. ModeName(SpecState.mode), "Warses_Spec_Sub",
        x + w / 2, y + 42,
        Color(220, 220, 220), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

    local hint = "ЛКМ/ПКМ — цель    R — режим    ПРОБЕЛ — полёт"
    draw.SimpleText(hint, "Warses_Spec_Hint",
        x + w / 2, y + h - 22,
        Color(190, 190, 190), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

    if SpecState.msg ~= "" and CurTime() < SpecState.msgUntil then
        draw.SimpleText(SpecState.msg, "Warses_Spec_Hint",
            sw / 2, sh - h - 70,
            Color(255, 220, 130), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
    end
end)

hook.Add("HUDShouldDraw", "Warses_SpecHideHUD", function(name)
    if not IsLocalSpectating() then return end
    if name == "CHudHealth" or name == "CHudBattery"
        or name == "CHudAmmo" or name == "CHudSecondaryAmmo"
        or name == "CHudCrosshair" or name == "CHudWeaponSelection" then
        return false
    end
end)

if not Warses_BaseDrawMotionBlur then
    Warses_BaseDrawMotionBlur = DrawMotionBlur
    function DrawMotionBlur(...)
        if IsLocalSpectating() then return end
        return Warses_BaseDrawMotionBlur(...)
    end
end

hook.Add("PrePlayerDraw", "Warses_SpecHideBody", function(ply)
    if IsValid(ply) and ply:Team() == TEAM_SPECTATOR then
        return true
    end
end)
