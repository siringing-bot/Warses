local M_TO_UNITS      = 52.49
local SQUAD_RANGE     = 30 * M_TO_UNITS
local TEAM_RANGE      = 10 * M_TO_UNITS
local SQUAD_RANGE_SQR = SQUAD_RANGE * SQUAD_RANGE
local TEAM_RANGE_SQR  = TEAM_RANGE  * TEAM_RANGE

local COLOR_SQUAD  = Color( 80, 235, 110, 240)
local COLOR_TEAM   = Color(100, 170, 255, 230)
local COLOR_SUB    = Color(220, 220, 230, 210)

surface.CreateFont("Warses_Marker_Name", {font = "Roboto", size = 19, weight = 700, antialias = true})
surface.CreateFont("Warses_Marker_Sub",  {font = "Roboto", size = 14, weight = 500, antialias = true})

local IsValid, player_GetAll = IsValid, player.GetAll
local math_sqrt, math_round  = math.sqrt, math.Round
local math_clamp             = math.Clamp
local Vector_up14            = Vector(0, 0, 14)
local string_format          = string.format
local draw_SimpleText        = draw.SimpleText
local TXT_C, TXT_T           = TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP

local _classNameCache = {}
local function GetClassName(classID)
    if classID == "" or not classID then return "" end
    local cached = _classNameCache[classID]
    if cached ~= nil then return cached end
    local cls = GAMEMODE and GAMEMODE.Classes and GAMEMODE.Classes[classID]
    local n = (cls and cls.name) or classID
    _classNameCache[classID] = n
    return n
end

hook.Add("Warses_ConflictChanged", "Warses_MarkersClassCacheClear", function()
    _classNameCache = {}
end)

local function FadeAlpha(distSqr, rangeSqr)
    local fadeStart = rangeSqr * 0.64
    if distSqr <= fadeStart then return 1 end
    local a = 1 - (distSqr - fadeStart) / (rangeSqr - fadeStart)
    return math_clamp(a, 0.2, 1)
end

local _plyCache = setmetatable({}, {__mode = "k"})
local function _getPlyEntry(ply)
    local e = _plyCache[ply]
    if not e then e = { tNick = -1, tSub = -1 }; _plyCache[ply] = e end
    return e
end

local _C_SHADOW = Color(0, 0, 0, 200)
local _C_NAME   = Color(255, 255, 255, 255)
local _C_SUB    = Color(255, 255, 255, 255)

hook.Add("HUDPaint", "Warses_3DMarkers", function()
    local lp = LocalPlayer()
    if not IsValid(lp) then return end

    local myTeam = lp:Team()
    if myTeam ~= TEAM_ALPHA and myTeam ~= TEAM_BRAVO then return end

    local mySquadID = lp:GetNWInt("WarsesSquadID", 0)
    local myEye     = lp:EyePos()
    local plys      = player_GetAll()
    local now       = CurTime()

    for i = 1, #plys do
        local ply = plys[i]
        if IsValid(ply) and ply ~= lp and ply:Alive() and ply:Team() == myTeam then
            local theirSquadID = ply:GetNWInt("WarsesSquadID", 0)
            local sameSquad    = mySquadID ~= 0 and theirSquadID == mySquadID

            local rangeSqr = sameSquad and SQUAD_RANGE_SQR or TEAM_RANGE_SQR
            local headPos  = ply:EyePos() + Vector_up14
            local distSqr  = myEye:DistToSqr(headPos)

            if distSqr <= rangeSqr then
                local scr = headPos:ToScreen()
                if scr.visible then
                    local color = sameSquad and COLOR_SQUAD or COLOR_TEAM
                    local alpha = FadeAlpha(distSqr, rangeSqr)

                    local e = _getPlyEntry(ply)
                    if now - e.tNick > 1.0 then
                        e.nick = ply:Nick()
                        e.tNick = now
                    end
                    if now - e.tSub > 0.25 then
                        local distM   = math_round(math_sqrt(distSqr) / M_TO_UNITS)
                        local distStr = string_format("%d м", distM)
                        if sameSquad then
                            e.sub = distStr
                        else
                            local cls = GetClassName(ply:GetNWString("Class", ""))
                            e.sub = (cls ~= "") and (cls .. "  ·  " .. distStr) or distStr
                        end
                        e.tSub = now
                    end

                    _C_SHADOW.a = 200 * alpha
                    _C_NAME.r, _C_NAME.g, _C_NAME.b = color.r, color.g, color.b
                    _C_NAME.a = color.a * alpha

                    draw_SimpleText(e.nick, "Warses_Marker_Name",
                        scr.x + 1, scr.y - 21, _C_SHADOW, TXT_C, TXT_T)
                    draw_SimpleText(e.nick, "Warses_Marker_Name",
                        scr.x, scr.y - 22, _C_NAME, TXT_C, TXT_T)

                    if e.sub and e.sub ~= "" then
                        _C_SUB.r, _C_SUB.g, _C_SUB.b = COLOR_SUB.r, COLOR_SUB.g, COLOR_SUB.b
                        _C_SUB.a = COLOR_SUB.a * alpha
                        draw_SimpleText(e.sub, "Warses_Marker_Sub",
                            scr.x + 1, scr.y - 1, _C_SHADOW, TXT_C, TXT_T)
                        draw_SimpleText(e.sub, "Warses_Marker_Sub",
                            scr.x, scr.y - 2, _C_SUB, TXT_C, TXT_T)
                    end
                end
            end
        end
    end
end)

print("[Warses] 3D markers loaded.")
