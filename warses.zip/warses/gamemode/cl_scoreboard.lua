local scoreboard = nil

surface.CreateFont("Warses_SB_Title",  {font = "Roboto", size = 56, weight = 900, antialias = true})
surface.CreateFont("Warses_SB_Conf",   {font = "Roboto", size = 22, weight = 500, antialias = true})
surface.CreateFont("Warses_SB_Team",   {font = "Roboto", size = 26, weight = 800, antialias = true})
surface.CreateFont("Warses_SB_Row",    {font = "Roboto", size = 18, weight = 500, antialias = true})
surface.CreateFont("Warses_SB_Header", {font = "Roboto", size = 14, weight = 700, antialias = true})
surface.CreateFont("Warses_SB_Score",  {font = "Roboto", size = 40, weight = 900, antialias = true})

local function MakePlayerRow(parent, ply, w, h, teamCol, index)
    local row = vgui.Create("DPanel", parent)
    row:SetSize(w, h)
    row.hover = 0
    row.appear = 0
    row.start = SysTime() + index * 0.025

    local avatar = vgui.Create("AvatarImage", row)
    avatar:SetSize(h - 8, h - 8)
    avatar:SetPos(8, 4)
    avatar:SetPlayer(ply, 32)

    row.Think = function(self)
        local t = math.Clamp((SysTime() - self.start) * 2.5, 0, 1)
        self.appear = 1 - math.pow(1 - t, 3)

        local mx, my = self:LocalCursorPos()
        local hover = mx >= 0 and my >= 0 and mx < self:GetWide() and my < self:GetTall()
        self.hover = Lerp(FrameTime() * 8, self.hover, hover and 1 or 0)
    end

    row.Paint = function(self, pw, ph)
        if not IsValid(ply) then return end
        local a = self.appear
        local hov = self.hover

        local xOff = (1 - a) * 30

        local bgA = 200 + 30 * hov
        local me = ply == LocalPlayer()
        local dead = not ply:Alive()

        local r, g, b = 22, 24, 30
        if me then r, g, b = 30, 50, 40 end
        if dead then r, g, b = 40, 22, 22 end

        surface.SetDrawColor(r + hov * 20, g + hov * 20, b + hov * 22, bgA * a)
        surface.DrawRect(xOff, 0, pw, ph - 1)

        surface.SetDrawColor(teamCol.r, teamCol.g, teamCol.b, 220 * a)
        surface.DrawRect(xOff, 0, 3, ph - 1)

        local clsName = ""
        local cls = ply:GetNWString("Class", "")
        if cls ~= "" and GAMEMODE.Classes[cls] then
            clsName = GAMEMODE.Classes[cls].name
        end

        local nameCol = me and Color(255, 165, 150) or Color(240, 240, 240)
        draw.SimpleText(ply:Nick(), "Warses_SB_Row",
            xOff + ph + 8, ph / 2,
            Color(nameCol.r, nameCol.g, nameCol.b, 255 * a),
            TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        if clsName ~= "" then
            draw.SimpleText(clsName, "Warses_SB_Row",
                xOff + 240, ph / 2,
                Color(180, 180, 200, 220 * a),
                TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end

        draw.SimpleText(tostring(ply:Frags()), "Warses_SB_Row",
            xOff + pw - 200, ph / 2,
            Color(120, 255, 140, 250 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        draw.SimpleText(tostring(ply:Deaths()), "Warses_SB_Row",
            xOff + pw - 120, ph / 2,
            Color(255, 120, 120, 250 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        local ping = ply:Ping()
        local pingCol = ping < 80 and Color(120, 255, 140) or (ping < 160 and Color(255, 200, 80) or Color(255, 100, 100))
        draw.SimpleText(tostring(ping), "Warses_SB_Row",
            xOff + pw - 40, ph / 2,
            Color(pingCol.r, pingCol.g, pingCol.b, 250 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    return row
end

local function CreateTeamColumn(parent, teamID, x, w, h, title, scoreVar)
    local panel = vgui.Create("DPanel", parent)
    panel:SetPos(x, 0)
    panel:SetSize(w, h)
    panel.appear = 0
    panel.start = SysTime()

    local teamCol = team.GetColor(teamID)

    panel.Think = function(self)
        local t = math.Clamp((SysTime() - self.start) * 1.8, 0, 1)
        self.appear = 1 - math.pow(1 - t, 3)
    end

    panel.Paint = function(self, pw, ph)
        local a = self.appear

        surface.SetDrawColor(15, 16, 22, 235 * a)
        surface.DrawRect(0, 0, pw, ph)

        surface.SetDrawColor(teamCol.r * 0.35, teamCol.g * 0.35, teamCol.b * 0.35, 250 * a)
        surface.DrawRect(0, 0, pw, 70)

        surface.SetDrawColor(teamCol.r, teamCol.g, teamCol.b, 255 * a)
        surface.DrawRect(0, 70, pw, 3)

        draw.SimpleText(title, "Warses_SB_Team",
            20, 24,
            Color(255, 255, 255, 255 * a),
            TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

        local score = scoreVar and GetGlobalInt(scoreVar, 0) or 0
        draw.SimpleText(tostring(score), "Warses_SB_Score",
            pw - 24, 32,
            Color(teamCol.r, teamCol.g, teamCol.b, 255 * a),
            TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

        local hy = 86
        surface.SetDrawColor(255, 255, 255, 25 * a)
        surface.DrawRect(0, hy, pw, 22)

        draw.SimpleText("ИГРОК", "Warses_SB_Header",
            56, hy + 11,
            Color(180, 180, 180, 230 * a),
            TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText("КЛАСС", "Warses_SB_Header",
            240, hy + 11,
            Color(180, 180, 180, 230 * a),
            TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText("K", "Warses_SB_Header",
            pw - 200, hy + 11,
            Color(180, 180, 180, 230 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("D", "Warses_SB_Header",
            pw - 120, hy + 11,
            Color(180, 180, 180, 230 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("PING", "Warses_SB_Header",
            pw - 40, hy + 11,
            Color(180, 180, 180, 230 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local scroll = vgui.Create("DScrollPanel", panel)
    scroll:SetPos(0, 112)
    scroll:SetSize(w, h - 112)

    local sbar = scroll:GetVBar()
    sbar:SetWide(4)
    sbar.Paint = function(_, sw, sh) end
    sbar.btnUp.Paint = function() end
    sbar.btnDown.Paint = function() end
    sbar.btnGrip.Paint = function(_, sw, sh)
        surface.SetDrawColor(120, 120, 120, 180)
        surface.DrawRect(0, 0, sw, sh)
    end

    local function Populate()
        scroll:Clear()
        local players = team.GetPlayers(teamID)

        table.sort(players, function(a, b)
            if not IsValid(a) then return false end
            if not IsValid(b) then return true end
            return a:Frags() > b:Frags()
        end)

        local y = 0
        for i, ply in ipairs(players) do
            if IsValid(ply) then
                local row = MakePlayerRow(scroll, ply, w, 38, teamCol, i)
                row:SetPos(0, y)
                y = y + 40
            end
        end
    end

    panel.Refresh = Populate
    Populate()
    return panel
end

local function CreateScoreboard()
    if IsValid(scoreboard) then scoreboard:Remove() end

    local scrW, scrH = ScrW(), ScrH()
    local w, h = math.min(scrW * 0.86, 1400), math.min(scrH * 0.84, 850)

    scoreboard = vgui.Create("DPanel")
    scoreboard:SetSize(w, h)
    scoreboard:Center()

    scoreboard.start = SysTime()
    scoreboard.appear = 0

    scoreboard.Think = function(self)
        local t = math.Clamp((SysTime() - self.start) * 1.8, 0, 1)
        self.appear = 1 - math.pow(1 - t, 3)
    end

    scoreboard.Paint = function(self, pw, ph)
        local a = self.appear

        surface.SetDrawColor(8, 9, 14, 240 * a)
        surface.DrawRect(0, 0, pw, ph)

        surface.SetDrawColor(190, 35, 40, 230 * a)
        surface.DrawRect(0, 0, pw, 3)

        draw.SimpleText("WARSES", "Warses_SB_Title",
            pw / 2, 50,
            Color(220, 55, 55, 255 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        local confName = "Unknown Conflict"
        if GAMEMODE.Conflicts[GAMEMODE.CurrentConflict] then
            local conf = GAMEMODE.Conflicts[GAMEMODE.CurrentConflict]
            local sub = conf.subconflicts[GAMEMODE.CurrentSubconflict]
            if sub then confName = conf.name .. "  —  " .. sub.name end
        end
        draw.SimpleText(confName, "Warses_SB_Conf",
            pw / 2, 88,
            Color(220, 220, 220, 220 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        local t = GetGlobalInt("GameTime", 0)
        local timeText = string.format("%02d:%02d", math.floor(t / 60), t % 60)
        draw.SimpleText("Время боя: " .. timeText, "Warses_SB_Conf",
            pw / 2, ph - 26,
            Color(180, 180, 180, 220 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local container = vgui.Create("DPanel", scoreboard)
    container:SetPos(24, 120)
    container:SetSize(w - 48, h - 160)
    container.Paint = function() end

    local nameA, nameB = "Team Alpha", "Team Bravo"
    if GAMEMODE.Conflicts[GAMEMODE.CurrentConflict] then
        local conf = GAMEMODE.Conflicts[GAMEMODE.CurrentConflict]
        local sub = conf.subconflicts[GAMEMODE.CurrentSubconflict]
        if sub and sub.teams then
            if sub.teams[TEAM_ALPHA] then nameA = sub.teams[TEAM_ALPHA].name end
            if sub.teams[TEAM_BRAVO] then nameB = sub.teams[TEAM_BRAVO].name end
        end
    end

    local colW = (w - 48 - 24) / 2

    scoreboard.AlphaList = CreateTeamColumn(container, TEAM_ALPHA, 0, colW,
        h - 160, nameA, "AlphaScore")
    scoreboard.BravoList = CreateTeamColumn(container, TEAM_BRAVO, colW + 24, colW,
        h - 160, nameB, "BravoScore")

    scoreboard.Refresh = function(self)
        if IsValid(self.AlphaList) then self.AlphaList:Refresh() end
        if IsValid(self.BravoList) then self.BravoList:Refresh() end
    end
end

function GM:ScoreboardShow()
    if not IsValid(scoreboard) then
        CreateScoreboard()
    else
        scoreboard:Refresh()
    end
    if IsValid(scoreboard) then
        scoreboard:SetVisible(true)
        scoreboard:MakePopup()
        scoreboard:SetKeyboardInputEnabled(false)
        scoreboard:SetMouseInputEnabled(true)
    end
    return true
end

function GM:ScoreboardHide()
    if IsValid(scoreboard) then
        scoreboard:SetVisible(false)
        gui.EnableScreenClicker(false)
    end
end

hook.Add("ScoreboardShow", "Warses_ScoreboardShow_Hook", function()
    return GAMEMODE:ScoreboardShow()
end)
hook.Add("ScoreboardHide", "Warses_ScoreboardHide_Hook", function()
    GAMEMODE:ScoreboardHide()
end)

print("[Warses] Scoreboard remastered & loaded.")
