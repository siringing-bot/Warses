local function assertAdmin(ply)
    return IsValid(ply) and ply:IsSuperAdmin()
end

local function ensureConfig()
    GAMEMODE.MapConfig = GAMEMODE.MapConfig or {}
    GAMEMODE.MapConfig.spawns = GAMEMODE.MapConfig.spawns or {}
    GAMEMODE.MapConfig.spawns[TEAM_ALPHA] = GAMEMODE.MapConfig.spawns[TEAM_ALPHA] or {}
    GAMEMODE.MapConfig.spawns[TEAM_BRAVO] = GAMEMODE.MapConfig.spawns[TEAM_BRAVO] or {}
    GAMEMODE.MapConfig.points = GAMEMODE.MapConfig.points or {}
    GAMEMODE.MapConfig.bases = GAMEMODE.MapConfig.bases or {}
    GAMEMODE.MapConfig.vehicles = GAMEMODE.MapConfig.vehicles or {}
    GAMEMODE.MapConfig.gravity_zones = GAMEMODE.MapConfig.gravity_zones or {}
    GAMEMODE.MapConfig.operation_attack_spawns = GAMEMODE.MapConfig.operation_attack_spawns or {}
    GAMEMODE.MapConfig.operation_sector_spawns = GAMEMODE.MapConfig.operation_sector_spawns or {}
    GAMEMODE.MapConfig.operation_attack_sector_spawns = GAMEMODE.MapConfig.operation_attack_sector_spawns or {}
    GAMEMODE.MapConfig.operation_attack_team = GAMEMODE.MapConfig.operation_attack_team or TEAM_ALPHA
end

local function dropToFloor(pos)
    local tr = util.TraceLine({
        start = pos + Vector(0, 0, 10),
        endpos = pos + Vector(0, 0, -200),
        mask = MASK_SOLID_BRUSHONLY,
    })
    return tr.Hit and tr.HitPos or pos
end

local function CollectSpawnList()
    ensureConfig()
    local list = {}

    for teamID, positions in pairs(GAMEMODE.MapConfig.spawns) do
        for _, p in ipairs(positions) do
            local x, y, z
            if isvector(p) then x, y, z = p.x, p.y, p.z
            elseif istable(p) then x, y, z = p.x, p.y, p.z end
            if x then
                table.insert(list, { x = x, y = y, z = z,
                    team = teamID, type = 0, sector = 0 })
            end
        end
    end

    for _, p in ipairs(GAMEMODE.MapConfig.operation_attack_spawns) do
        local x, y, z
        if isvector(p) then x, y, z = p.x, p.y, p.z
        elseif istable(p) then x, y, z = p.x, p.y, p.z end
        if x then
            table.insert(list, { x = x, y = y, z = z,
                team = 0, type = 1, sector = 0 })
        end
    end

    for sec, positions in pairs(GAMEMODE.MapConfig.operation_sector_spawns) do
        for _, p in ipairs(positions) do
            local x, y, z
            if isvector(p) then x, y, z = p.x, p.y, p.z
            elseif istable(p) then x, y, z = p.x, p.y, p.z end
            if x then
                table.insert(list, { x = x, y = y, z = z,
                    team = 0, type = 2, sector = tonumber(sec) or 0 })
            end
        end
    end

    for sec, positions in pairs(GAMEMODE.MapConfig.operation_attack_sector_spawns) do
        for _, p in ipairs(positions) do
            local x, y, z
            if isvector(p) then x, y, z = p.x, p.y, p.z
            elseif istable(p) then x, y, z = p.x, p.y, p.z end
            if x then
                table.insert(list, { x = x, y = y, z = z,
                    team = 0, type = 3, sector = tonumber(sec) or 0 })
            end
        end
    end

    return list
end

local function BroadcastSpawnList(ply)
    local list = CollectSpawnList()
    net.Start("WarsesAdmin_SpawnsList")
    net.WriteTable(list)
    if IsValid(ply) then net.Send(ply) else
        local admins = {}
        for _, p in ipairs(player.GetAll()) do
            if p:IsSuperAdmin() then admins[#admins + 1] = p end
        end
        if #admins > 0 then net.Send(admins) end
    end
end

net.Receive("WarsesAdmin_Place", function(_, ply)
    if not assertAdmin(ply) then return end
    ensureConfig()

    local mode = net.ReadString()
    local pos = net.ReadVector()
    local ang = net.ReadAngle()
    local params = net.ReadTable() or {}
    local lookEnt = net.ReadEntity()

    if mode == "point" then
        local name = tostring(params.pointName or "Control Point")
        local ent = ents.Create("warses_capturepoint")
        if not IsValid(ent) then return end
        ent:SetPos(pos)
        ent:Spawn()
        ent:SetPointName(name)
        ent:DropToFloor()
        ply:ChatPrint("[Warses] Точка «" .. name .. "» поставлена.")

    elseif mode == "point_sek" then
        local name = tostring(params.pointName or "Sector Point")
        local sector = tonumber(params.sector) or 1
        local ent = ents.Create("warses_capturepoint")
        if not IsValid(ent) then return end
        ent:SetPos(pos)
        ent:Spawn()
        ent:SetPointName(name)
        if ent.SetSector then ent:SetSector(sector) end
        ent:DropToFloor()
        ply:ChatPrint("[Warses] Точка сектора «" .. name .. "» (S" .. sector .. ") поставлена.")

    elseif mode == "base" then
        local teamID = tonumber(params.team) or TEAM_ALPHA
        local ent = ents.Create("warses_base")
        if not IsValid(ent) then return end
        ent:SetPos(pos)
        ent:SetOwningTeam(teamID)
        ent:Spawn()
        ply:ChatPrint("[Warses] База " .. team.GetName(teamID) .. " поставлена.")

    elseif mode == "spawn" then
        local teamID = tonumber(params.team) or TEAM_ALPHA
        local floor = dropToFloor(pos)
        table.insert(GAMEMODE.MapConfig.spawns[teamID], floor)
        ply:ChatPrint("[Warses] Спаун " .. team.GetName(teamID) .. " добавлен.")
        BroadcastSpawnList()

    elseif mode == "op_attack" then
        local floor = dropToFloor(pos)
        table.insert(GAMEMODE.MapConfig.operation_attack_spawns, floor)
        ply:ChatPrint("[Warses] Спаун атаки (Operation) добавлен.")
        BroadcastSpawnList()

    elseif mode == "op_sector" then
        local sector = tonumber(params.sector) or 1
        GAMEMODE.MapConfig.operation_sector_spawns[sector] =
            GAMEMODE.MapConfig.operation_sector_spawns[sector] or {}
        local floor = dropToFloor(pos)
        table.insert(GAMEMODE.MapConfig.operation_sector_spawns[sector], floor)
        ply:ChatPrint("[Warses] Спаун сектора " .. sector .. " добавлен.")
        BroadcastSpawnList()

    elseif mode == "op_attack_sector" then
        local sector = tonumber(params.sector) or 1
        GAMEMODE.MapConfig.operation_attack_sector_spawns[sector] =
            GAMEMODE.MapConfig.operation_attack_sector_spawns[sector] or {}
        local floor = dropToFloor(pos)
        table.insert(GAMEMODE.MapConfig.operation_attack_sector_spawns[sector], floor)
        ply:ChatPrint("[Warses] Атакующий спаун сектора " .. sector .. " добавлен.")
        BroadcastSpawnList()

    elseif mode == "vehicle" then
        local class = tostring(params.vehicleClass or "jeep")
        local respawn = tonumber(params.vehicleRespawn) or 30
        local r = math.Clamp(tonumber(params.vehicleColorR) or 255, 0, 255)
        local g = math.Clamp(tonumber(params.vehicleColorG) or 255, 0, 255)
        local b = math.Clamp(tonumber(params.vehicleColorB) or 255, 0, 255)

        local ent = ents.Create("warses_vehicle_spawn")
        if not IsValid(ent) then return end
        ent:SetPos(pos + Vector(0, 0, 8))
        ent:SetAngles(ang)
        ent:Spawn()
        ent:SetVehicleClass(class)
        ent:SetRespawnTime(respawn)
        ent:SetColor(Color(r, g, b))
        if ent.SetVehicleSpawnColor then
            ent:SetVehicleSpawnColor(Vector(r / 255, g / 255, b / 255))
        end
        if ent.RespawnNow then ent:RespawnNow() end

        ply:ChatPrint(string.format(
            "[Warses] Транспорт %s (кд %ds, цвет %d,%d,%d) поставлен.",
            class, respawn, r, g, b))

    elseif mode == "gravity_zone" then
        ply:ChatPrint("[Warses] Зона гравитации ставится двумя ЛКМ по тулгану (углы куба).")

    elseif mode == "zone_edit" then
        local target = lookEnt
        if not IsValid(target) then
            ply:ChatPrint("[Warses] Наведитесь на точку/базу для применения зоны.")
            return
        end
        local cls = target:GetClass()
        if cls ~= "warses_capturepoint" and cls ~= "warses_base" and cls ~= "warses_gravity_zone" then
            ply:ChatPrint("[Warses] Цель должна быть warses_capturepoint, warses_base или warses_gravity_zone.")
            return
        end
        local zt = tonumber(params.zoneType) or 0
        target:SetZoneType(zt)
        target:SetZoneLength(tonumber(params.zoneLength) or 200)
        target:SetZoneWidth(tonumber(params.zoneWidth) or 200)
        target:SetZoneHeight(tonumber(params.zoneHeight) or 200)
        ply:ChatPrint(string.format(
            "[Warses] Зона применена: тип=%d, %dx%dx%d", zt,
            params.zoneLength or 0, params.zoneWidth or 0, params.zoneHeight or 0))

    elseif mode == "remove" then
        if IsValid(lookEnt) then
            local cls = lookEnt:GetClass()
            if cls == "warses_capturepoint"
                or cls == "warses_base"
                or cls == "warses_vehicle_spawn"
                or cls == "warses_gravity_zone" then
                if cls == "warses_vehicle_spawn" and IsValid(lookEnt.CurrentVehicle) then
                    lookEnt.CurrentVehicle:Remove()
                end
                lookEnt:Remove()
                ply:ChatPrint("[Warses] Удалено: " .. cls)
                return
            end
        end

        local radius = math.Clamp(tonumber(params.removeRadius) or 100, 16, 2048)
        local r2 = radius * radius

        local function tryRemove(list, label)
            local bestIdx, bestDist = nil, r2
            for i, p in ipairs(list) do
                local vec = isvector(p) and p or Vector(p.x or 0, p.y or 0, p.z or 0)
                local d = vec:DistToSqr(pos)
                if d < bestDist then bestDist = d; bestIdx = i end
            end
            if bestIdx then
                table.remove(list, bestIdx)
                ply:ChatPrint("[Warses] Удалён спаун: " .. label)
                BroadcastSpawnList()
                return true
            end
            return false
        end

        if tryRemove(GAMEMODE.MapConfig.spawns[TEAM_ALPHA], "ALPHA") then return end
        if tryRemove(GAMEMODE.MapConfig.spawns[TEAM_BRAVO], "BRAVO") then return end
        if tryRemove(GAMEMODE.MapConfig.operation_attack_spawns, "OP-ATTACK") then return end

        for sec, list in pairs(GAMEMODE.MapConfig.operation_sector_spawns) do
            if tryRemove(list, "OP-SECTOR " .. sec) then return end
        end
        for sec, list in pairs(GAMEMODE.MapConfig.operation_attack_sector_spawns) do
            if tryRemove(list, "OP-ATK-SEC " .. sec) then return end
        end

        ply:ChatPrint("[Warses] Ничего не найдено для удаления в радиусе " .. radius)
    end
end)

net.Receive("WarsesAdmin_PlaceGravityZone", function(_, ply)
    if not assertAdmin(ply) then return end
    ensureConfig()

    local p1 = net.ReadVector()
    local p2 = net.ReadVector()

    local minZ = math.min(p1.z, p2.z)
    local maxZ = math.max(p1.z, p2.z)

    local center = Vector(
        (p1.x + p2.x) * 0.5,
        (p1.y + p2.y) * 0.5,
        minZ
    )

    local length = math.abs(p2.x - p1.x)
    local width  = math.abs(p2.y - p1.y)
    local height = maxZ - minZ

    if length < 8 then length = 8 end
    if width  < 8 then width  = 8 end
    if height < 8 then height = 8 end

    local ent = ents.Create("warses_gravity_zone")
    if not IsValid(ent) then
        ply:ChatPrint("[Warses] Не удалось создать warses_gravity_zone.")
        return
    end
    ent:SetPos(center)
    ent:Spawn()
    ent:SetZoneType(1)
    ent:SetZoneLength(length)
    ent:SetZoneWidth(width)
    ent:SetZoneHeight(height)

    ply:ChatPrint(string.format(
        "[Warses] Зона гравитации (Box) %dx%dx%d создана.",
        length, width, height))
end)

net.Receive("WarsesAdmin_Remove", function(_, ply)
    if not assertAdmin(ply) then return end
    local ent = net.ReadEntity()
    if not IsValid(ent) then return end
    local cls = ent:GetClass()
    if cls ~= "warses_capturepoint"
        and cls ~= "warses_base"
        and cls ~= "warses_vehicle_spawn"
        and cls ~= "warses_gravity_zone" then return end

    if cls == "warses_vehicle_spawn" and IsValid(ent.CurrentVehicle) then
        ent.CurrentVehicle:Remove()
    end
    ent:Remove()
    ply:ChatPrint("[Warses] Удалено: " .. cls)
end)

net.Receive("WarsesAdmin_RemoveSpawnAt", function(_, ply)
    if not assertAdmin(ply) then return end
    ensureConfig()
    local pos = net.ReadVector()
    local radius = 80

    local function tryRemove(list)
        local bestIdx, bestDist = nil, radius * radius
        for i, p in ipairs(list) do
            local vec = isvector(p) and p or Vector(p.x or 0, p.y or 0, p.z or 0)
            local d = vec:DistToSqr(pos)
            if d < bestDist then bestDist = d; bestIdx = i end
        end
        if bestIdx then table.remove(list, bestIdx); return true end
        return false
    end

    if tryRemove(GAMEMODE.MapConfig.spawns[TEAM_ALPHA])
        or tryRemove(GAMEMODE.MapConfig.spawns[TEAM_BRAVO])
        or tryRemove(GAMEMODE.MapConfig.operation_attack_spawns) then
        ply:ChatPrint("[Warses] Спаун удалён.")
        BroadcastSpawnList()
        return
    end

    for sec, list in pairs(GAMEMODE.MapConfig.operation_sector_spawns) do
        if tryRemove(list) then
            ply:ChatPrint("[Warses] Спаун сектора " .. sec .. " удалён.")
            BroadcastSpawnList()
            return
        end
    end
    for sec, list in pairs(GAMEMODE.MapConfig.operation_attack_sector_spawns) do
        if tryRemove(list) then
            ply:ChatPrint("[Warses] Атак. спаун сектора " .. sec .. " удалён.")
            BroadcastSpawnList()
            return
        end
    end

    ply:ChatPrint("[Warses] Спаун в радиусе 80 не найден.")
end)

net.Receive("WarsesAdmin_Save", function(_, ply)
    if not assertAdmin(ply) then return end
    GAMEMODE:SaveMapConfig()
    ply:ChatPrint("[Warses] Конфиг карты сохранён.")
end)

net.Receive("WarsesAdmin_Load", function(_, ply)
    if not assertAdmin(ply) then return end
    GAMEMODE:LoadMapConfig()
    BroadcastSpawnList()
    ply:ChatPrint("[Warses] Конфиг загружен.")
end)

net.Receive("WarsesAdmin_Clear", function(_, ply)
    if not assertAdmin(ply) then return end
    GAMEMODE.MapConfig = {
        spawns = { [TEAM_ALPHA] = {}, [TEAM_BRAVO] = {} },
        points = {}, bases = {}, vehicles = {}, gravity_zones = {},
        operation_attack_team = TEAM_ALPHA,
        operation_attack_spawns = {},
        operation_sector_spawns = {},
        operation_attack_sector_spawns = {},
    }
    for _, e in ipairs(ents.FindByClass("warses_capturepoint")) do e:Remove() end
    for _, e in ipairs(ents.FindByClass("warses_base")) do e:Remove() end
    for _, e in ipairs(ents.FindByClass("warses_vehicle_spawn")) do e:Remove() end
    for _, e in ipairs(ents.FindByClass("warses_gravity_zone")) do e:Remove() end
    BroadcastSpawnList()
    ply:ChatPrint("[Warses] Конфиг очищен (не сохранён на диске).")
end)

net.Receive("WarsesAdmin_SetAttackTeam", function(_, ply)
    if not assertAdmin(ply) then return end
    ensureConfig()
    local t = net.ReadInt(8)
    if t ~= TEAM_ALPHA and t ~= TEAM_BRAVO then return end
    GAMEMODE.MapConfig.operation_attack_team = t
    ply:ChatPrint("[Warses] Команда атаки: " .. team.GetName(t))
end)

net.Receive("WarsesAdmin_GetSpawns", function(_, ply)
    if not assertAdmin(ply) then return end
    BroadcastSpawnList(ply)
end)

concommand.Add("warses_menu", function(ply)
    if not assertAdmin(ply) then return end
    net.Start("WarsesAdmin_OpenMenu")
    net.Send(ply)
    if not ply:HasWeapon("warses_admintool") then
        ply:Give("warses_admintool")
    end
    ply:SelectWeapon("warses_admintool")
end)

concommand.Add("warses_tool", function(ply)
    if not assertAdmin(ply) then return end
    if not ply:HasWeapon("warses_admintool") then
        ply:Give("warses_admintool")
    end
    ply:SelectWeapon("warses_admintool")
    ply:ChatPrint("[Warses] Тулган выдан.")
end)

hook.Add("InitPostEntity", "Warses_BroadcastSpawnsOnLoad", function()
    timer.Simple(3, BroadcastSpawnList)
end)

hook.Add("PlayerInitialSpawn", "Warses_AdminSpawnList", function(ply)
    timer.Simple(4, function()
        if IsValid(ply) and ply:IsSuperAdmin() then BroadcastSpawnList(ply) end
    end)
end)
