surface.CreateFont("Warses_ZombieLives", {
    font = "Roboto", size = 18, weight = 800, antialias = true
})
surface.CreateFont("Warses_ZombieBigTitle", {
    font = "Roboto", size = 130, weight = 900, antialias = true, shadow = true
})
surface.CreateFont("Warses_ZombieSubTitle", {
    font = "Roboto", size = 26, weight = 700, antialias = true
})

local LAUGH_PATH = "sound/zgrad/zombie_warses/Voicy_Cod zombies _ evil laugh.mp3"
local MUSIC_PATH = "sound/zgrad/zombie_warses/soundtrack.mp3"

local Z = {
    mode_active   = false,
    role          = "spectator",

    overlay_alpha = 0,
    overlay_to    = 0,
    overlay_speed = 220,

    anchor_x      = 0.05,
    anchor_y      = 0.92,
    anchor_scale  = 0.2,

    anchor_target_x = 0.05,
    anchor_target_y = 0.92,
    anchor_target_scale = 0.2,
    anchor_speed_pos = 1.5,
    anchor_speed_scale = 2.0,

    sticks = {
        {alpha = 0, color_r = 0, y_drift = 0, x_drift = 0},
        {alpha = 0, color_r = 0, y_drift = 0, x_drift = 0},
        {alpha = 0, color_r = 0, y_drift = 0, x_drift = 0},
    },

    cross_progress  = 0,
    cross_alpha     = 0,
    cross_glow      = 0,
    cross2_progress = 0,
    cross2_alpha    = 0,
    cross2_glow     = 0,
    shake_amp      = 0,
    flash_alpha    = 0,
    title_alpha    = 0,
    glow_pulse     = 0,
    spacing_mul    = 1.0,

    laugh_channel = nil,
    music_channel = nil,

    lives = 0,
    layout_count = 0,

    anim = nil,
}

function Warses_IsZombieCutsceneFullscreen()
    if not Z.anim then return false end
    return Z.anim.name == "intro"
        or Z.anim.name == "convert"
        or Z.anim.name == "finaldeath"
end

function Warses_IsZombieOverlayActive()
    return Z.overlay_alpha > 80
end

local function StopChannel(ch)
    if ch and IsValid(ch) then ch:Stop() end
end

local function PlayLaugh()
    StopChannel(Z.laugh_channel)
    sound.PlayFile(LAUGH_PATH, "noplay noblock", function(channel, errCode, errStr)
        if not IsValid(channel) then
            print("[Warses Zombie] Failed laugh: ", errCode, errStr)
            return
        end
        Z.laugh_channel = channel
        channel:SetVolume(1.0)
        channel:Play()
    end)
end

local function PlayMusicLoop()
    if Z.music_channel and IsValid(Z.music_channel) then return end
    sound.PlayFile(MUSIC_PATH, "noplay noblock", function(channel, errCode, errStr)
        if not IsValid(channel) then
            print("[Warses Zombie] Failed music: ", errCode, errStr)
            return
        end
        Z.music_channel = channel
        channel:EnableLooping(true)
        channel:SetVolume(0.55)
        channel:Play()
    end)
end

local function StopMusic()
    StopChannel(Z.music_channel)
    Z.music_channel = nil
end

local SPACING = 75
local function SlotOffsetX(slot, visibleCount)
    local SP = SPACING * (Z.spacing_mul or 1.0)
    local function offsetForN(slot, N)
        if N <= 1 then return 0 end
        if N == 2 then
            if slot == 0 then return -SP * 0.5 end
            if slot == 1 then return  SP * 0.5 end
            return SP
        end
        if N == 3 then
            if slot == 0 then return -SP end
            if slot == 1 then return 0 end
            return SP
        end
        return 0
    end

    if visibleCount == math.floor(visibleCount) then
        return offsetForN(slot, visibleCount)
    end

    local lo = math.floor(visibleCount)
    local hi = lo + 1
    local k  = visibleCount - lo
    return Lerp(k, offsetForN(slot, lo), offsetForN(slot, hi))
end

local function DrawRomanI(cx, cy, scale, alpha, colorR)
    if alpha <= 0 or scale <= 0 then return end

    local h      = 280 * scale
    local barW   = 36  * scale
    local serifW = 130 * scale
    local serifH = 22  * scale

    local r = math.floor(Lerp(colorR, 255, 220))
    local g = math.floor(Lerp(colorR, 255, 25))
    local b = math.floor(Lerp(colorR, 255, 25))

    surface.SetDrawColor(r, g, b, alpha)
    surface.DrawRect(cx - barW / 2, cy - h / 2, barW, h)
    surface.DrawRect(cx - serifW / 2, cy - h / 2, serifW, serifH)
    surface.DrawRect(cx - serifW / 2, cy + h / 2 - serifH, serifW, serifH)
end

local function DrawThickLine(x1, y1, x2, y2, thickness, r, g, b, a)
    local dx, dy = x2 - x1, y2 - y1
    local len = math.sqrt(dx * dx + dy * dy)
    if len < 1 then return end
    local cx, cy = (x1 + x2) * 0.5, (y1 + y2) * 0.5
    local ang = math.deg(math.atan2(dy, dx))
    surface.SetDrawColor(r, g, b, a)
    draw.NoTexture()
    surface.DrawTexturedRectRotated(cx, cy, len, thickness, ang)
end

local function StartAnim(name, dur)
    Z.anim = {name = name, start = SysTime(), dur = dur}
end

local function ClearAnim()
    Z.anim = nil
end

local function SetSticksByLives(lives, colorR)
    colorR = colorR or 1
    for i = 1, 3 do
        local slot = i - 1
        if slot < lives then
            Z.sticks[i].alpha   = 255
            Z.sticks[i].color_r = colorR
            Z.sticks[i].y_drift = 0
            Z.sticks[i].x_drift = 0
        else
            Z.sticks[i].alpha   = 0
            Z.sticks[i].color_r = colorR
            Z.sticks[i].y_drift = 0
            Z.sticks[i].x_drift = 0
        end
    end
    Z.lives = lives
    Z.spacing_mul = 1.0
    Z.cross_progress = 0; Z.cross_alpha = 0; Z.cross_glow = 0
    Z.cross2_progress = 0; Z.cross2_alpha = 0; Z.cross2_glow = 0
    Z.title_alpha = 0; Z.flash_alpha = 0; Z.shake_amp = 0; Z.glow_pulse = 0
end

local function MoveAnchor(x, y, scale)
    Z.anchor_target_x = x
    Z.anchor_target_y = y
    Z.anchor_target_scale = scale
end

local function SnapAnchor(x, y, scale)
    Z.anchor_x = x; Z.anchor_y = y; Z.anchor_scale = scale
    MoveAnchor(x, y, scale)
end

local function GoToCorner()
    MoveAnchor(0.05, 0.92, 0.2)
end

net.Receive("Warses_ZombieIntro", function()
    local dur   = net.ReadFloat()
    local role  = net.ReadString()
    local lives = net.ReadInt(8)

    Z.mode_active = true
    Z.role = role
    Z.lives = lives

    if Warses_CloseMapVoteUI then Warses_CloseMapVoteUI() end

    if dur <= 0 then
        Z.overlay_alpha = 0
        Z.overlay_to    = 0
        SnapAnchor(0.05, 0.92, 0.2)
        local cr = (role == "zombie") and 1 or 0
        SetSticksByLives(lives, cr)
        if not Z.music_channel or not IsValid(Z.music_channel) then PlayMusicLoop() end
        return
    end

    PlayLaugh()
    Z.overlay_alpha = 0
    Z.overlay_to    = 255
    SnapAnchor(0.5, 0.5, 0)
    for i = 1, 3 do Z.sticks[i].alpha = 0; Z.sticks[i].color_r = 0 end
    StartAnim("intro", dur)
end)

net.Receive("Warses_ZombieSpawned", function()
    local lives = net.ReadInt(8)
    local role  = net.ReadString()

    Z.lives = lives
    Z.role  = role
    Z.mode_active = true

    local cr = (role == "zombie") and 1 or 0
    SetSticksByLives(lives, cr)
    SnapAnchor(0.05, 0.92, 0.2)

    Z.overlay_to = 0
    if not Z.music_channel or not IsValid(Z.music_channel) then PlayMusicLoop() end
end)

net.Receive("Warses_ZombieConvert", function()
    PlayLaugh()
    StartAnim("convert", 10.0)
end)

net.Receive("Warses_ZombieLoseLife", function()
    local newCount = net.ReadInt(8)
    PlayLaugh()
    Z.anim = {name = "loselife", start = SysTime(), dur = 2.0, target_lives = newCount}
end)

net.Receive("Warses_ZombieFinalDeath", function()
    local originalLives = net.ReadInt(8)
    PlayLaugh()
    local dur = (originalLives == 3) and 17.0 or 13.0
    StartAnim("finaldeath", dur)
    Z.anim.original_lives = originalLives
    Z.anim.sounds_played  = {}
end)

net.Receive("Warses_ZombieEnd", function()
    Z.mode_active = false
    Z.role = "spectator"
    Z.overlay_to = 0
    Z.overlay_alpha = 0
    for i = 1, 3 do Z.sticks[i].alpha = 0 end
    Z.cross_alpha = 0
    Z.cross_progress = 0
    Z.cross_glow = 0
    Z.flash_alpha = 0
    Z.title_alpha = 0
    Z.shake_amp = 0
    Z.glow_pulse = 0
    StopMusic()
    StopChannel(Z.laugh_channel)
    ClearAnim()
end)

local function ApproachFrame(cur, target, speed)
    return math.Approach(cur, target, FrameTime() * speed)
end

hook.Add("Think", "Warses_ZombieThink", function()
    Z.overlay_alpha = ApproachFrame(Z.overlay_alpha, Z.overlay_to, Z.overlay_speed)

    Z.anchor_x = ApproachFrame(Z.anchor_x, Z.anchor_target_x, Z.anchor_speed_pos)
    Z.anchor_y = ApproachFrame(Z.anchor_y, Z.anchor_target_y, Z.anchor_speed_pos)
    Z.anchor_scale = ApproachFrame(Z.anchor_scale, Z.anchor_target_scale, Z.anchor_speed_scale)

    do
        local target = Z.lives
        if Z.anim and Z.anim.name == "loselife" then
            target = (Z.anim.target_lives or 0) + 1
        elseif Z.anim and Z.anim.name == "finaldeath" then
            target = (Z.anim.original_lives == 3) and 3 or 1
        elseif Z.anim and Z.anim.name == "intro" then
            local tt = SysTime() - Z.anim.start
            if tt < 10 then target = 1 end
        end
        Z.layout_count = ApproachFrame(Z.layout_count, target, 4.0)
    end

    if not Z.anim then return end
    local t   = SysTime() - Z.anim.start
    local dur = Z.anim.dur
    local k   = math.Clamp(t / dur, 0, 1)

    if Z.anim.name == "intro" then
        Z.overlay_to = 255

        if t < 3 then
            Z.sticks[1].alpha = 0
            Z.sticks[2].alpha = 0
            Z.sticks[3].alpha = 0
            SnapAnchor(0.5, 0.5, 0)
        elseif t < 5 then
            local kk = (t - 3) / 2
            Z.sticks[1].alpha   = math.Clamp(kk * 255, 0, 255)
            Z.sticks[1].color_r = 0
            SnapAnchor(0.5, 0.5, math.Clamp(kk, 0, 1))
        elseif t < 8 then
            local kk = (t - 5) / 3
            Z.sticks[1].alpha   = 255
            Z.sticks[1].color_r = (Z.role == "zombie") and math.Clamp(kk, 0, 1) or 0
            SnapAnchor(0.5, 0.5, 1)
        elseif t < 10 then
            local kk = (t - 8) / 2
            local cr = (Z.role == "zombie") and 1 or 0
            Z.sticks[1].alpha   = 255
            Z.sticks[1].color_r = cr
            Z.anchor_x     = Lerp(kk, 0.5, 0.05)
            Z.anchor_y     = Lerp(kk, 0.5, 0.92)
            Z.anchor_scale = Lerp(kk, 1, 0.2)
            Z.anchor_target_x = 0.05; Z.anchor_target_y = 0.92; Z.anchor_target_scale = 0.2

            if Z.role == "zombie" and Z.lives >= 2 then
                Z.sticks[2].alpha   = math.Clamp(kk * 255, 0, 255)
                Z.sticks[2].color_r = cr
            end
            if Z.role == "zombie" and Z.lives >= 3 then
                Z.sticks[3].alpha   = math.Clamp(kk * 255, 0, 255)
                Z.sticks[3].color_r = cr
            end
        else
            SnapAnchor(0.05, 0.92, 0.2)
            local cr = (Z.role == "zombie") and 1 or 0
            local n = Z.lives
            for i = 1, 3 do
                Z.sticks[i].alpha   = (i <= n) and 255 or 0
                Z.sticks[i].color_r = cr
            end
        end

        if t >= dur - 2 and (not Z.music_channel or not IsValid(Z.music_channel)) then
            PlayMusicLoop()
        end

        if t >= dur then
            ClearAnim()
        end

    elseif Z.anim.name == "convert" then
        local function easeInOut(x)
            x = math.Clamp(x, 0, 1)
            return x * x * (3 - 2 * x)
        end

        Z.overlay_to = 255

        if t < 2.0 then
            local k  = t / 2.0
            local ek = easeInOut(k)
            Z.overlay_alpha = math.max(Z.overlay_alpha, 255 * ek)
            Z.anchor_x = Lerp(ek, 0.05, 0.5)
            Z.anchor_y = Lerp(ek, 0.92, 0.5)
            Z.anchor_scale = Lerp(ek, 0.2, 1.2)
            Z.anchor_target_x = 0.5
            Z.anchor_target_y = 0.5
            Z.anchor_target_scale = 1.2
            Z.sticks[1].alpha   = 255
            Z.sticks[1].color_r = 0
            Z.sticks[1].x_drift = 0
            Z.sticks[1].y_drift = 0
            Z.glow_pulse = 0

        elseif t < 3.5 then
            Z.overlay_alpha = 255
            Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.2
            Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.2
            Z.sticks[1].alpha   = 255
            Z.sticks[1].color_r = 0
            Z.glow_pulse = 0.05 + math.sin(t * 3) * 0.05

        elseif t < 6.0 then
            local k  = (t - 3.5) / 2.5
            local ek = easeInOut(k)
            Z.overlay_alpha = 255
            Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.2
            Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.2
            Z.sticks[1].alpha   = 255
            Z.sticks[1].color_r = ek
            Z.glow_pulse = ek * 0.7

        elseif t < 7.0 then
            Z.overlay_alpha = 255
            Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.2
            Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.2
            Z.sticks[1].alpha   = 255
            Z.sticks[1].color_r = 1
            Z.glow_pulse = 0.55 + math.sin(t * 5) * 0.15

        elseif t < 9.0 then
            local k  = (t - 7.0) / 2.0
            local ek = easeInOut(k)
            Z.overlay_alpha = 255
            Z.anchor_x = Lerp(ek, 0.5, 0.05)
            Z.anchor_y = Lerp(ek, 0.5, 0.92)
            Z.anchor_scale = Lerp(ek, 1.2, 0.2)
            Z.anchor_target_x = 0.05
            Z.anchor_target_y = 0.92
            Z.anchor_target_scale = 0.2
            Z.sticks[1].alpha   = 255
            Z.sticks[1].color_r = 1
            Z.glow_pulse = (1 - ek) * 0.4

        else
            Z.overlay_alpha = 255
            Z.anchor_x = 0.05; Z.anchor_y = 0.92; Z.anchor_scale = 0.2
            Z.anchor_target_x = 0.05; Z.anchor_target_y = 0.92; Z.anchor_target_scale = 0.2
            Z.sticks[1].alpha   = 255
            Z.sticks[1].color_r = 1
            Z.glow_pulse = 0
        end

        if t >= dur then ClearAnim() end

    elseif Z.anim.name == "loselife" then
        local nNew = Z.anim.target_lives or 0
        local nOld = nNew + 1
        local fadingSlot = nOld

        local kk = math.Clamp(t / dur, 0, 1)
        if Z.sticks[fadingSlot] then
            Z.sticks[fadingSlot].alpha = math.Clamp((1 - kk) * 255, 0, 255)
        end
        if t >= dur then
            Z.lives = nNew
            if Z.sticks[fadingSlot] then Z.sticks[fadingSlot].alpha = 0 end
            ClearAnim()
        end

    elseif Z.anim.name == "finaldeath" then
        Z.overlay_to = 255

        local function easeInOut(x)
            x = math.Clamp(x, 0, 1)
            return x * x * (3 - 2 * x)
        end

        local function PlaySoundOnce(id, path)
            if not Z.anim.sounds_played then Z.anim.sounds_played = {} end
            if Z.anim.sounds_played[id] then return end
            Z.anim.sounds_played[id] = true
            surface.PlaySound(path)
        end

        local SND_SLAM   = "ambient/atmosphere/thunder1.wav"
        local SND_RUMBLE = "npc/zombie/moan_loop1.wav"
        local SND_DRAMA  = "npc/zombie/zombie_alert1.wav"
        local SND_SWING  = "weapons/iceaxe/iceaxe_swing1.wav"
        local SND_HIT    = "weapons/iceaxe/iceaxe_impact_hard1.wav"

        local isGerman = (Z.anim.original_lives == 3)

        Z.cross2_progress = 0; Z.cross2_alpha = 0; Z.cross2_glow = 0

        if isGerman then

            if t < 1.5 then
                local k = t / 1.5
                Z.overlay_alpha = math.max(Z.overlay_alpha, 255 * easeInOut(k))
                Z.sticks[1].alpha = 0; Z.sticks[2].alpha = 0; Z.sticks[3].alpha = 0
                Z.cross_progress = 0; Z.cross_alpha = 0; Z.cross_glow = 0
                Z.shake_amp   = 0
                Z.flash_alpha = 0
                Z.title_alpha = 0
                Z.spacing_mul = 1.0
                Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.3
                Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.3

            elseif t < 3.5 then
                local k = (t - 1.5) / 2.0
                Z.overlay_alpha = 255
                local scale
                if k < 0.6 then
                    local kk = easeInOut(k / 0.6)
                    scale = Lerp(kk, 0, 1.5)
                else
                    local kk = (k - 0.6) / 0.4
                    scale = Lerp(easeInOut(kk), 1.5, 1.3)
                end
                Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = scale
                Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = scale
                Z.sticks[1].alpha   = math.Clamp(easeInOut(k * 1.5) * 255, 0, 255)
                Z.sticks[1].color_r = 0
                Z.sticks[1].x_drift = 0
                Z.sticks[1].y_drift = 0
                Z.shake_amp = (k > 0.5 and k < 0.7) and 12 * (1 - math.abs(k - 0.6) * 10) or 0
                Z.shake_amp = math.max(Z.shake_amp, 0)
                Z.spacing_mul = 1.0
                if k > 0.55 then PlaySoundOnce("slam", SND_SLAM) end

            elseif t < 5.5 then
                local k = (t - 3.5) / 2.0
                local ek = easeInOut(k)
                Z.overlay_alpha = 255
                Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.3
                Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.3
                Z.sticks[1].alpha = 255; Z.sticks[1].color_r = 0
                Z.sticks[1].x_drift = Lerp(ek, 0, -SPACING)
                Z.sticks[1].y_drift = 0
                Z.shake_amp = 0
                Z.spacing_mul = 1.0

            elseif t < 7.5 then
                local k = (t - 5.5) / 2.0
                local ek = easeInOut(k)
                Z.overlay_alpha = 255
                Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.3
                Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.3
                Z.sticks[1].alpha = 255; Z.sticks[1].color_r = 0; Z.sticks[1].x_drift = -SPACING
                Z.sticks[2].alpha = math.Clamp(ek * 255, 0, 255); Z.sticks[2].color_r = 0
                Z.sticks[2].y_drift = Lerp(ek, 450, 0)
                Z.sticks[3].alpha = math.Clamp(ek * 255, 0, 255); Z.sticks[3].color_r = 0
                Z.sticks[3].y_drift = Lerp(ek, 450, 0)
                Z.spacing_mul = 1.0
                Z.shake_amp = 0
                if k > 0.1 then PlaySoundOnce("ghosts", SND_RUMBLE) end

            elseif t < 9.5 then
                local k = (t - 7.5) / 2.0
                local ek = easeInOut(k)
                Z.overlay_alpha = 255
                Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.3
                Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.3
                for i = 1, 3 do
                    Z.sticks[i].alpha   = 255
                    Z.sticks[i].color_r = ek
                    Z.sticks[i].y_drift = 0
                end
                Z.sticks[1].x_drift = Lerp(ek, -SPACING, 0)
                Z.spacing_mul = Lerp(ek, 1.0, 0.55)
                Z.shake_amp = 0

            elseif t < 10.5 then
                Z.overlay_alpha = 255
                Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.3
                Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.3
                for i = 1, 3 do
                    Z.sticks[i].alpha = 255; Z.sticks[i].color_r = 1; Z.sticks[i].y_drift = 0
                end
                Z.sticks[1].x_drift = 0
                Z.spacing_mul = 0.55
                Z.shake_amp = 1
                PlaySoundOnce("drama", SND_DRAMA)

            elseif t < 13.0 then
                local k = (t - 10.5) / 2.5
                local ek = easeInOut(k)
                Z.overlay_alpha = 255
                Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.3
                Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.3
                for i = 1, 3 do
                    Z.sticks[i].alpha = 255; Z.sticks[i].color_r = 1; Z.sticks[i].y_drift = 0
                end
                Z.sticks[1].x_drift = 0
                Z.spacing_mul = 0.55
                Z.cross_progress = ek
                Z.cross_alpha    = 255
                Z.cross_glow     = ek
                Z.shake_amp = 1 + ek * 4
                PlaySoundOnce("swing", SND_SWING)
                if k > 0.7 then PlaySoundOnce("laugh2", LAUGH_PATH) end

            elseif t < 13.5 then
                local k = (t - 13.0) / 0.5
                Z.overlay_alpha = 255
                Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.3
                Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.3
                for i = 1, 3 do
                    Z.sticks[i].alpha = 255; Z.sticks[i].color_r = 1
                end
                Z.sticks[1].x_drift = 0
                Z.spacing_mul = 0.55
                Z.cross_progress = 1; Z.cross_alpha = 255; Z.cross_glow = 1
                if k < 0.5 then
                    Z.flash_alpha = 220 * (k / 0.5)
                else
                    Z.flash_alpha = 220 * (1 - (k - 0.5) / 0.5)
                end
                Z.shake_amp = 22 * (1 - k)
                PlaySoundOnce("hit", SND_HIT)

            elseif t < 15.5 then
                local k = (t - 13.5) / 2.0
                local ek = easeInOut(k)
                Z.overlay_alpha = 255
                Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.3
                Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.3
                for i = 1, 3 do
                    Z.sticks[i].alpha   = math.Clamp(255 * (1 - ek * 0.3), 0, 255)
                    Z.sticks[i].color_r = 1
                end
                Z.sticks[1].x_drift = 0
                Z.spacing_mul = 0.55
                Z.cross_progress = 1; Z.cross_alpha = 255; Z.cross_glow = 1 - ek * 0.3
                Z.title_alpha = math.Clamp(ek * 255, 0, 255)
                Z.flash_alpha = 0
                Z.shake_amp = 0

            else
                local k = (t - 15.5) / 1.5
                local ek = easeInOut(k)
                Z.overlay_alpha = 255
                Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.3
                Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.3
                local a = math.Clamp((1 - ek) * 255, 0, 255)
                for i = 1, 3 do
                    Z.sticks[i].alpha   = math.min(Z.sticks[i].alpha, a * 0.7)
                    Z.sticks[i].color_r = 1
                end
                Z.sticks[1].x_drift = 0
                Z.spacing_mul = 0.55
                Z.cross_alpha = math.min(Z.cross_alpha, a * 0.7)
                Z.cross_glow  = (1 - ek) * 0.5
                Z.title_alpha = math.Clamp((1 - ek) * 255, 0, 255)
                Z.shake_amp   = 0
            end
        else

            if t < 1.5 then
                local k = t / 1.5
                Z.overlay_alpha = math.max(Z.overlay_alpha, 255 * easeInOut(k))
                Z.sticks[1].alpha = 0; Z.sticks[2].alpha = 0; Z.sticks[3].alpha = 0
                Z.cross_progress = 0; Z.cross_alpha = 0; Z.cross_glow = 0
                Z.shake_amp = 0; Z.flash_alpha = 0; Z.title_alpha = 0
                Z.spacing_mul = 1.0
                Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.3
                Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.3

            elseif t < 3.5 then
                local k = (t - 1.5) / 2.0
                Z.overlay_alpha = 255
                local scale
                if k < 0.6 then
                    scale = Lerp(easeInOut(k / 0.6), 0, 1.5)
                else
                    scale = Lerp(easeInOut((k - 0.6) / 0.4), 1.5, 1.3)
                end
                Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = scale
                Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = scale
                Z.sticks[1].alpha   = math.Clamp(easeInOut(k * 1.5) * 255, 0, 255)
                Z.sticks[1].color_r = 0
                Z.sticks[1].x_drift = 0
                Z.sticks[1].y_drift = 0
                Z.shake_amp = (k > 0.5 and k < 0.7) and 12 * (1 - math.abs(k - 0.6) * 10) or 0
                Z.shake_amp = math.max(Z.shake_amp, 0)
                Z.spacing_mul = 1.0
                if k > 0.55 then PlaySoundOnce("slam", SND_SLAM) end

            elseif t < 5.0 then
                Z.overlay_alpha = 255
                Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.3
                Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.3
                Z.sticks[1].alpha = 255; Z.sticks[1].color_r = 0
                Z.shake_amp = 0
                Z.spacing_mul = 1.0

            elseif t < 7.0 then
                local k = (t - 5.0) / 2.0
                local ek = easeInOut(k)
                Z.overlay_alpha = 255
                Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.3
                Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.3
                Z.sticks[1].alpha = 255
                Z.sticks[1].color_r = ek
                Z.shake_amp = 0
                Z.spacing_mul = 1.0
                if k > 0.1 then PlaySoundOnce("rumble", SND_RUMBLE) end

            elseif t < 8.0 then
                Z.overlay_alpha = 255
                Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.3
                Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.3
                Z.sticks[1].alpha = 255; Z.sticks[1].color_r = 1
                Z.shake_amp = 1
                PlaySoundOnce("drama", SND_DRAMA)

            elseif t < 10.5 then
                local k = (t - 8.0) / 2.5
                local ek = easeInOut(k)
                Z.overlay_alpha = 255
                Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.3
                Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.3
                Z.sticks[1].alpha = 255; Z.sticks[1].color_r = 1
                Z.cross_progress = ek
                Z.cross_alpha    = 255
                Z.cross_glow     = ek
                Z.shake_amp = 1 + ek * 4
                PlaySoundOnce("swing", SND_SWING)
                if k > 0.7 then PlaySoundOnce("laugh2", LAUGH_PATH) end

            elseif t < 11.0 then
                local k = (t - 10.5) / 0.5
                Z.overlay_alpha = 255
                Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.3
                Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.3
                Z.sticks[1].alpha = 255; Z.sticks[1].color_r = 1
                Z.cross_progress = 1; Z.cross_alpha = 255; Z.cross_glow = 1
                if k < 0.5 then
                    Z.flash_alpha = 220 * (k / 0.5)
                else
                    Z.flash_alpha = 220 * (1 - (k - 0.5) / 0.5)
                end
                Z.shake_amp = 22 * (1 - k)
                PlaySoundOnce("hit", SND_HIT)

            elseif t < 12.5 then
                local k = (t - 11.0) / 1.5
                local ek = easeInOut(k)
                Z.overlay_alpha = 255
                Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.3
                Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.3
                Z.sticks[1].alpha   = math.Clamp(255 * (1 - ek * 0.3), 0, 255)
                Z.sticks[1].color_r = 1
                Z.cross_progress = 1; Z.cross_alpha = 255; Z.cross_glow = 1 - ek * 0.3
                Z.title_alpha = math.Clamp(ek * 255, 0, 255)
                Z.flash_alpha = 0
                Z.shake_amp = 0

            else
                local k = (t - 12.5) / 0.5
                local ek = easeInOut(k)
                Z.overlay_alpha = 255
                Z.anchor_x = 0.5; Z.anchor_y = 0.5; Z.anchor_scale = 1.3
                Z.anchor_target_x = 0.5; Z.anchor_target_y = 0.5; Z.anchor_target_scale = 1.3
                local a = math.Clamp((1 - ek) * 255, 0, 255)
                Z.sticks[1].alpha = math.min(Z.sticks[1].alpha, a * 0.7)
                Z.sticks[1].color_r = 1
                Z.cross_alpha = math.min(Z.cross_alpha, a * 0.7)
                Z.cross_glow  = (1 - ek) * 0.5
                Z.title_alpha = math.Clamp((1 - ek) * 255, 0, 255)
                Z.shake_amp   = 0
            end
        end

        if t >= dur then
            ClearAnim()
            Z.cross_progress = 0; Z.cross_alpha = 0; Z.cross_glow = 0
            Z.cross2_progress = 0; Z.cross2_alpha = 0; Z.cross2_glow = 0
            Z.flash_alpha = 0; Z.title_alpha = 0; Z.shake_amp = 0; Z.glow_pulse = 0
            Z.spacing_mul = 1.0
            for i = 1, 3 do
                Z.sticks[i].alpha = 0
                Z.sticks[i].x_drift = 0
                Z.sticks[i].y_drift = 0
            end
            Z.lives = 0
        end
    end
end)

hook.Add("HUDPaint", "Warses_ZombieHUD", function()
    if Z.overlay_alpha > 0 then
        surface.SetDrawColor(0, 0, 0, Z.overlay_alpha)
        surface.DrawRect(0, 0, ScrW(), ScrH())
    end

    if not Z.mode_active and Z.overlay_alpha <= 0 then return end

    local shakeX, shakeY = 0, 0
    if Z.shake_amp and Z.shake_amp > 0 then
        shakeX = (math.random() - 0.5) * 2 * Z.shake_amp
        shakeY = (math.random() - 0.5) * 2 * Z.shake_amp
    end

    local ax = ScrW() * Z.anchor_x + shakeX
    local ay = ScrH() * Z.anchor_y + shakeY
    local s  = Z.anchor_scale

    local visN = Z.layout_count

    for i = 1, 3 do
        local stick = Z.sticks[i]
        if stick.alpha > 0 then
            local off = SlotOffsetX(i - 1, visN) * s
            local cx = ax + off + (stick.x_drift or 0) * s
            local cy = ay + (stick.y_drift or 0) * s
            DrawRomanI(cx, cy, s, stick.alpha, stick.color_r)
        end
    end

    local function DrawSlashLine(startX, startY, endX, endY, progress, alpha, glow)
        if alpha <= 0 or progress <= 0 then return end
        local px = Lerp(progress, startX, endX)
        local py = Lerp(progress, startY, endY)
        if glow > 0.01 then
            for layer = 1, 3 do
                local thick = (22 + layer * 12) * s
                local ga = math.floor(alpha * 0.35 * glow / layer)
                if ga > 0 then
                    DrawThickLine(startX, startY, px, py, thick, 255, 40, 40, ga)
                end
            end
        end
        DrawThickLine(startX, startY, px, py, 24 * s, 255, 230, 230,
            math.floor(alpha * 0.7))
        DrawThickLine(startX, startY, px, py, 14 * s, 240, 30, 30, alpha)
    end

    if Z.cross_alpha > 0 or Z.cross2_alpha > 0 then
        local extend = SPACING * 0.55
        local leftX  = ax + (-SPACING - extend) * s
        local rightX = ax + ( SPACING + extend) * s
        local topY   = ay - 180 * s
        local botY   = ay + 180 * s

        DrawSlashLine(rightX, topY, leftX, botY,
            Z.cross_progress or 0, Z.cross_alpha or 0, Z.cross_glow or 0)
        DrawSlashLine(leftX, topY, rightX, botY,
            Z.cross2_progress or 0, Z.cross2_alpha or 0, Z.cross2_glow or 0)
    end

    if Z.flash_alpha and Z.flash_alpha > 0 then
        surface.SetDrawColor(255, 255, 255, Z.flash_alpha)
        surface.DrawRect(0, 0, ScrW(), ScrH())
    end

    if Z.title_alpha and Z.title_alpha > 0 then
        local cx, cy = ScrW() / 2 + shakeX, ScrH() * 0.78 + shakeY
        surface.SetFont("Warses_ZombieBigTitle")
        local tw, th = surface.GetTextSize("СМЕРТЬ")
        surface.SetTextColor(0, 0, 0, Z.title_alpha)
        surface.SetTextPos(cx - tw / 2 + 3, cy - th / 2 + 3)
        surface.DrawText("СМЕРТЬ")
        surface.SetTextColor(220, 30, 30, Z.title_alpha)
        surface.SetTextPos(cx - tw / 2, cy - th / 2)
        surface.DrawText("СМЕРТЬ")

        surface.SetFont("Warses_ZombieSubTitle")
        local stxt = "Все жизни потрачены"
        local stw, sth = surface.GetTextSize(stxt)
        surface.SetTextColor(0, 0, 0, Z.title_alpha * 0.85)
        surface.SetTextPos(cx - stw / 2 + 2, cy + th / 2 + 2)
        surface.DrawText(stxt)
        surface.SetTextColor(180, 180, 180, Z.title_alpha * 0.85)
        surface.SetTextPos(cx - stw / 2, cy + th / 2)
        surface.DrawText(stxt)
    end

    if Z.mode_active and not Z.anim and GAMEMODE.CurrentGameMode == "zombie" then
        local ply = LocalPlayer()
        if IsValid(ply) and ply:Team() ~= TEAM_SPECTATOR then
            local txt = "Жизней: " .. Z.lives
            surface.SetFont("Warses_ZombieLives")
            local tw, _ = surface.GetTextSize(txt)
            local x = ax - tw / 2
            local y = ay + 60
            surface.SetTextColor(0, 0, 0, 220)
            surface.SetTextPos(x + 1, y + 1)
            surface.DrawText(txt)
            surface.SetTextColor(220, 60, 60, 255)
            surface.SetTextPos(x, y)
            surface.DrawText(txt)
        end
    end
end)

local HIDE_DURING_CUTSCENE = {
    ["CHudDeathNotice"] = true,
    ["CHudChat"]        = false,
}

hook.Add("HUDShouldDraw", "Warses_ZombieHideHUD", function(name)
    if not Warses_IsZombieCutsceneFullscreen() then return end
    if HIDE_DURING_CUTSCENE[name] then return false end
end)

hook.Add("ShutDown", "Warses_ZombieShutdown", function()
    StopMusic()
    StopChannel(Z.laugh_channel)
end)
