WARSES_VIP_GROUPS = {
    ["vip"]        = true,
    ["admin"]      = true,
    ["superadmin"] = true,
}

local function GroupIsVIP(group)
    local guard = 0
    while group and guard < 32 do
        if WARSES_VIP_GROUPS[group] then return true end
        local gdata = ULib and ULib.ucl and ULib.ucl.groups and ULib.ucl.groups[group]
        group = gdata and gdata.inherit_from
        guard = guard + 1
    end
    return false
end
Warses_GroupIsVIP = GroupIsVIP

function Warses_IsVIP(ply)
    if not IsValid(ply) or not ply:IsPlayer() then return false end

    if GroupIsVIP(ply:GetUserGroup()) then return true end

    if ULib and ULib.ucl and isfunction(ply.CheckGroup) then
        for g in pairs(WARSES_VIP_GROUPS) do
            local ok, res = pcall(ply.CheckGroup, ply, g)
            if ok and res then return true end
        end
    end

    if ply:IsAdmin() then return true end

    return false
end

if SERVER then
    local cvReserved = CreateConVar("warses_vip_reserved_slots", "10",
        {FCVAR_ARCHIVE, FCVAR_NOTIFY},
        "Сколько слотов сервера зарезервировано под VIP+. 0 = выключить.")

    local cvAutoVisible = CreateConVar("warses_vip_autovisible", "1",
        {FCVAR_ARCHIVE},
        "1 = авто-выставлять sv_visiblemaxplayers = maxplayers - reserved.")

    local function HasGroupSource()
        return ULib and ULib.ucl and ULib.ucl.users ~= nil
    end

    function Warses_IsSteamIDVIP(steamID)
        if not steamID or not HasGroupSource() then return false end

        local authed = ULib.ucl.authed and ULib.ucl.authed[steamID]
        if authed and GroupIsVIP(authed.group) then return true end

        local u = ULib.ucl.users[steamID]
        if u and GroupIsVIP(u.group) then return true end

        return false
    end

    hook.Add("CheckPassword", "Warses_VIPReservedSlots",
        function(steamID64, ipAddress, svPassword, clPassword, name)
            local reserved = cvReserved:GetInt()
            if reserved <= 0 then return end

            local maxp    = game.MaxPlayers()
            local visible = maxp - reserved
            if visible < 1 then return end

            if player.GetCount() < visible then return end

            if not HasGroupSource() then return end

            local steamID = util.SteamIDFrom64(steamID64)
            if steamID and Warses_IsSteamIDVIP(steamID) then
                return
            end

            return false, "Сервер заполнен. Свободные слоты зарезервированы для VIP."
        end)

    local function ApplyVIPSlotConfig()
        local reserved = cvReserved:GetInt()
        local maxp     = game.MaxPlayers()

        if reserved <= 0 then
            print("[Warses][VIP] Зарезервированные слоты выключены (warses_vip_reserved_slots = 0).")
            return
        end

        if reserved >= maxp then
            print(string.format(
                "[Warses][VIP] ВНИМАНИЕ: warses_vip_reserved_slots (%d) >= maxplayers (%d). " ..
                "Резерв слотов отключён — увеличь maxplayers сервера.", reserved, maxp))
            return
        end

        local visible = maxp - reserved
        if cvAutoVisible:GetBool() then
            RunConsoleCommand("sv_visiblemaxplayers", tostring(visible))
        end

        if not HasGroupSource() then
            print("[Warses][VIP] ВНИМАНИЕ: ULib/ULX не найден — VIP по SteamID не определяется, " ..
                  "резерв слотов работать НЕ будет.")
        end

        print(string.format(
            "[Warses][VIP] Слоты: maxplayers=%d, видимый лимит=%d, зарезервировано под VIP=%d.",
            maxp, visible, reserved))
    end

    hook.Add("InitPostEntity", "Warses_VIPSlotConfig", function()
        timer.Simple(1, ApplyVIPSlotConfig)
    end)

    cvars.AddChangeCallback("warses_vip_reserved_slots", function()
        timer.Simple(0, ApplyVIPSlotConfig)
    end, "Warses_VIPSlotConfig")
end
