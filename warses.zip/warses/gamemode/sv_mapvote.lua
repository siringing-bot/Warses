AddCSLuaFile("cl_mapvote.lua")

util.AddNetworkString("MapVote_Era")
util.AddNetworkString("MapVote_EraUpdate")
util.AddNetworkString("MapVote_EraVote")

util.AddNetworkString("MapVote_Start")
util.AddNetworkString("MapVote_Update")
util.AddNetworkString("MapVote_CastVote")

util.AddNetworkString("MapVote_Phase2")
util.AddNetworkString("MapVote_Phase2Update")
util.AddNetworkString("MapVote_Phase2Vote")

util.AddNetworkString("MapVote_Phase3")
util.AddNetworkString("MapVote_Phase3Update")
util.AddNetworkString("MapVote_Phase3Vote")

local MapVote = {}
MapVote.Active = false
MapVote.Phase = 0
MapVote.Duration = 30
MapVote.Votes = {}

MapVote.EraList = {}
MapVote.WinnerEraID = nil

MapVote.ConflictList = {}
MapVote.WinnerEntry = nil

function MapVote.BuildEraList()
    local list = {}
    for eraID, era in pairs(GAMEMODE.Conflicts) do
        local subCount = 0
        local mapCount = 0
        for _, sub in pairs(era.subconflicts) do
            subCount = subCount + 1
            if sub.maps then mapCount = mapCount + #sub.maps end
        end
        table.insert(list, {
            eraID       = eraID,
            name        = era.name or eraID,
            period      = era.period or "",
            description = era.description or "",
            order       = era.order or 99,
            subCount    = subCount,
            mapCount    = mapCount,
        })
    end
    table.sort(list, function(a, b)
        if a.order == b.order then return a.name < b.name end
        return a.order < b.order
    end)
    return list
end

function MapVote.BuildConflictList(eraID)
    local list = {}
    local era = GAMEMODE.Conflicts[eraID]
    if not era then return list end

    for subconflictID, subconflict in pairs(era.subconflicts) do
        table.insert(list, {
            conflictID      = eraID,
            subconflictID   = subconflictID,
            conflictName    = era.name,
            subconflictName = subconflict.name,
            description     = subconflict.description or "",
            maps            = subconflict.maps or {},
            voteID          = eraID .. "/" .. subconflictID,
        })
    end
    return list
end

hook.Add("StartMapVote", "Warses_StartVoteSystem", function()
    MapVote.Start()
end)

function MapVote.Start()
    if MapVote.Active then return end

    MapVote.Active = true
    SetGlobalBool("MapVote_Active", true)
    MapVote.Phase = 1
    MapVote.Votes = {}
    MapVote.EraList = MapVote.BuildEraList()

    print("[Warses] Map Vote — Phase 1 (Era)")

    net.Start("MapVote_Era")
    net.WriteUInt(MapVote.Duration, 8)
    net.WriteTable(MapVote.EraList)
    net.Broadcast()

    timer.Create("MapVote_EndTimer", MapVote.Duration, 1, MapVote.EndPhase1)

    if GAMEMODE.ZombiePending and Warses_StartZombieCutscene then
        local interrupt = math.random(8, math.min(22, MapVote.Duration - 3))
        timer.Create("Warses_ZombieInterrupt", interrupt, 1, function()
            Warses_StartZombieCutscene()
        end)
    end
end

function MapVote.EndPhase1()
    MapVote.Phase = 0

    local counts = {}
    for _, entry in ipairs(MapVote.EraList) do counts[entry.eraID] = 0 end
    for _, eraID in pairs(MapVote.Votes) do
        counts[eraID] = (counts[eraID] or 0) + 1
    end

    local maxVotes, candidates = -1, {}
    for eraID, n in pairs(counts) do
        if n > maxVotes then
            maxVotes = n
            candidates = {eraID}
        elseif n == maxVotes then
            table.insert(candidates, eraID)
        end
    end

    local winnerEra = candidates[math.random(#candidates)]
    if not winnerEra or not GAMEMODE.Conflicts[winnerEra] then
        winnerEra = MapVote.EraList[1] and MapVote.EraList[1].eraID
    end

    MapVote.WinnerEraID = winnerEra
    local eraData = GAMEMODE.Conflicts[winnerEra]
    PrintMessage(HUD_PRINTTALK, "Выбрана эпоха: " .. (eraData and eraData.name or winnerEra))

    MapVote.ConflictList = MapVote.BuildConflictList(winnerEra)
    if #MapVote.ConflictList <= 1 then
        local only = MapVote.ConflictList[1]
        if only then
            MapVote.WinnerEntry = only
            MapVote.AfterConflictChosen()
            return
        end
    end

    MapVote.StartPhase2()
end

function MapVote.StartPhase2()
    MapVote.Phase = 2
    MapVote.Votes = {}

    print("[Warses] Map Vote — Phase 2 (Conflict)")

    net.Start("MapVote_Start")
    net.WriteUInt(MapVote.Duration, 8)
    net.WriteTable(MapVote.ConflictList)
    net.Broadcast()

    timer.Create("MapVote_EndTimer", MapVote.Duration, 1, MapVote.EndPhase2)
end

function MapVote.EndPhase2()
    MapVote.Phase = 0

    local counts = {}
    for _, entry in ipairs(MapVote.ConflictList) do counts[entry.voteID] = 0 end
    for _, voteID in pairs(MapVote.Votes) do
        counts[voteID] = (counts[voteID] or 0) + 1
    end

    local maxVotes, candidates = -1, {}
    for voteID, n in pairs(counts) do
        if n > maxVotes then
            maxVotes = n
            candidates = {voteID}
        elseif n == maxVotes then
            table.insert(candidates, voteID)
        end
    end

    local winnerID = candidates[math.random(#candidates)]
    local winnerEntry
    for _, entry in ipairs(MapVote.ConflictList) do
        if entry.voteID == winnerID then winnerEntry = entry break end
    end
    if not winnerEntry then winnerEntry = MapVote.ConflictList[1] end

    MapVote.WinnerEntry = winnerEntry
    PrintMessage(HUD_PRINTTALK, "Выбран конфликт: " .. winnerEntry.subconflictName)

    MapVote.AfterConflictChosen()
end

function MapVote.AfterConflictChosen()
    local entry = MapVote.WinnerEntry
    if #entry.maps <= 1 then
        local finalMap = entry.maps[1] or "gm_flatgrass"
        local supportedModes = GAMEMODE.MapGameModes[finalMap] or {"capture"}
        if #supportedModes > 1 then
            MapVote.StartPhase3(finalMap, supportedModes)
        else
            MapVote.Finalize(finalMap, supportedModes[1])
        end
    else
        MapVote.StartPhase3_Map()
    end
end

function MapVote.StartPhase3_Map()
    MapVote.Phase = 3
    MapVote.Votes = {}

    local entry = MapVote.WinnerEntry
    local mapChoices = {}
    for _, m in ipairs(entry.maps) do table.insert(mapChoices, m) end
    table.insert(mapChoices, "__random__")

    print("[Warses] Map Vote — Phase 3 (Map) для " .. entry.subconflictName)

    net.Start("MapVote_Phase2")
    net.WriteUInt(MapVote.Duration, 8)
    net.WriteString(entry.subconflictName)
    net.WriteTable(mapChoices)
    net.Broadcast()

    timer.Create("MapVote_EndTimer", MapVote.Duration, 1, MapVote.EndPhase3_Map)
end

function MapVote.EndPhase3_Map()
    MapVote.Phase = 0

    local entry = MapVote.WinnerEntry
    local mapChoices = {}
    for _, m in ipairs(entry.maps) do table.insert(mapChoices, m) end
    table.insert(mapChoices, "__random__")

    local counts = {}
    for _, m in ipairs(mapChoices) do counts[m] = 0 end
    for _, mapName in pairs(MapVote.Votes) do
        counts[mapName] = (counts[mapName] or 0) + 1
    end

    local maxVotes, candidates = -1, {}
    for mapName, n in pairs(counts) do
        if n > maxVotes then
            maxVotes = n
            candidates = {mapName}
        elseif n == maxVotes then
            table.insert(candidates, mapName)
        end
    end

    local winnerMap = candidates[math.random(#candidates)]
    if winnerMap == "__random__" then
        winnerMap = entry.maps[math.random(#entry.maps)]
    end

    local supportedModes = GAMEMODE.MapGameModes[winnerMap] or {"capture"}
    if #supportedModes > 1 then
        MapVote.StartPhase3(winnerMap, supportedModes)
    else
        MapVote.Finalize(winnerMap, supportedModes[1])
    end
end

function MapVote.StartPhase3(mapName, modes)
    MapVote.Phase = 4
    MapVote.Votes = {}
    MapVote.WinnerMap = mapName
    MapVote.AvailableModes = modes

    print("[Warses] Map Vote — Phase 4 (GameMode) для " .. mapName)

    net.Start("MapVote_Phase3")
    net.WriteUInt(MapVote.Duration, 8)
    net.WriteString(mapName)
    net.WriteTable(modes)
    net.Broadcast()

    timer.Create("MapVote_EndTimer", MapVote.Duration, 1, MapVote.EndPhase3)
end

function MapVote.EndPhase3()
    MapVote.Phase = 0

    local counts = {}
    for _, m in ipairs(MapVote.AvailableModes) do counts[m] = 0 end
    for _, modeName in pairs(MapVote.Votes) do
        counts[modeName] = (counts[modeName] or 0) + 1
    end

    local maxVotes, candidates = -1, {}
    for modeName, n in pairs(counts) do
        if n > maxVotes then
            maxVotes = n
            candidates = {modeName}
        elseif n == maxVotes then
            table.insert(candidates, modeName)
        end
    end

    local winnerMode = candidates[math.random(#candidates)] or "capture"
    MapVote.Finalize(MapVote.WinnerMap, winnerMode)
end

function MapVote.Finalize(mapName, modeName)
    MapVote.Active = false
    SetGlobalBool("MapVote_Active", false)
    MapVote.Phase = 0

    file.Write("warses_next_gamemode.txt", modeName)

    local modeDesc = GAMEMODE.GameModesList[modeName] or modeName
    PrintMessage(HUD_PRINTTALK, "Следующая карта: " .. tostring(mapName) .. " (" .. modeDesc .. ")")
    print("[Warses] Map Vote Winner: " .. tostring(mapName) .. " | Mode: " .. modeName)

    timer.Simple(3, function()
        RunConsoleCommand("changelevel", mapName)
    end)
end

net.Receive("MapVote_EraVote", function(len, ply)
    if not MapVote.Active or MapVote.Phase ~= 1 then return end
    local eraID = net.ReadString()

    local isValid = false
    for _, entry in ipairs(MapVote.EraList) do
        if entry.eraID == eraID then isValid = true break end
    end
    if not isValid then return end

    MapVote.Votes[ply:SteamID()] = eraID
    net.Start("MapVote_EraUpdate")
    net.WriteTable(MapVote.Votes)
    net.Broadcast()
end)

net.Receive("MapVote_CastVote", function(len, ply)
    if not MapVote.Active or MapVote.Phase ~= 2 then return end
    local voteID = net.ReadString()

    local isValid = false
    for _, entry in ipairs(MapVote.ConflictList) do
        if entry.voteID == voteID then isValid = true break end
    end
    if not isValid then return end

    MapVote.Votes[ply:SteamID()] = voteID
    net.Start("MapVote_Update")
    net.WriteTable(MapVote.Votes)
    net.Broadcast()
end)

net.Receive("MapVote_Phase2Vote", function(len, ply)
    if not MapVote.Active or MapVote.Phase ~= 3 then return end
    local mapName = net.ReadString()

    local entry = MapVote.WinnerEntry
    local isValid = false
    if entry then
        for _, m in ipairs(entry.maps) do
            if m == mapName then isValid = true break end
        end
        if mapName == "__random__" then isValid = true end
    end
    if not isValid then return end

    MapVote.Votes[ply:SteamID()] = mapName
    net.Start("MapVote_Phase2Update")
    net.WriteTable(MapVote.Votes)
    net.Broadcast()
end)

net.Receive("MapVote_Phase3Vote", function(len, ply)
    if not MapVote.Active or MapVote.Phase ~= 4 then return end
    local modeName = net.ReadString()

    local isValid = false
    if MapVote.AvailableModes then
        for _, m in ipairs(MapVote.AvailableModes) do
            if m == modeName then isValid = true break end
        end
    end
    if not isValid then return end

    MapVote.Votes[ply:SteamID()] = modeName
    net.Start("MapVote_Phase3Update")
    net.WriteTable(MapVote.Votes)
    net.Broadcast()
end)
