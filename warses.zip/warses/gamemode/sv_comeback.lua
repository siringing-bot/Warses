local CV_ON     = CreateConVar("warses_comeback_threshold_on",  "200", {FCVAR_ARCHIVE, FCVAR_NOTIFY}, "Разрыв в очках для активации мобилизации")
local CV_OFF    = CreateConVar("warses_comeback_threshold_off", "100", {FCVAR_ARCHIVE, FCVAR_NOTIFY}, "Разрыв в очках, при котором мобилизация снимается")
local CV_RESP   = CreateConVar("warses_comeback_respawn_reduction", "2", {FCVAR_ARCHIVE, FCVAR_NOTIFY}, "На сколько секунд короче респ у отстающей команды")
local CV_SCORE  = CreateConVar("warses_comeback_score_bonus",   "1",   {FCVAR_ARCHIVE, FCVAR_NOTIFY}, "+N очков к каждому событию начисления для отстающей команды")

GAMEMODE = GAMEMODE or GM
GAMEMODE.ComebackTeam = 0

local function Broadcast(teamID)
    SetGlobalInt("WarsesComebackTeam", teamID or 0)
end
Broadcast(0)

local function ComputeComebackTeam(currentlyActive)
    if GAMEMODE.CurrentGameMode ~= "capture" then return 0 end

    local a = GetGlobalInt("AlphaScore", 0)
    local b = GetGlobalInt("BravoScore", 0)
    local on  = CV_ON:GetInt()
    local off = CV_OFF:GetInt()

    if currentlyActive == TEAM_ALPHA then
        if (b - a) > off then return TEAM_ALPHA else return 0 end
    elseif currentlyActive == TEAM_BRAVO then
        if (a - b) > off then return TEAM_BRAVO else return 0 end
    else
        if (a - b) > on then return TEAM_BRAVO end
        if (b - a) > on then return TEAM_ALPHA end
        return 0
    end
end

timer.Create("Warses_ComebackTick", 2, 0, function()
    if Warses_IsGameOver and Warses_IsGameOver() then return end
    local newTeam = ComputeComebackTeam(GAMEMODE.ComebackTeam or 0)
    if newTeam ~= GAMEMODE.ComebackTeam then
        GAMEMODE.ComebackTeam = newTeam
        Broadcast(newTeam)
        if newTeam ~= 0 then
            PrintMessage(HUD_PRINTTALK,
                "[Warses] " .. team.GetName(newTeam)
                .. ": активирована мобилизация (-" .. CV_RESP:GetInt() .. "с к респу, +"
                .. CV_SCORE:GetInt() .. " к очкам).")
        else
            PrintMessage(HUD_PRINTTALK, "[Warses] Мобилизация снята.")
        end
    end
end)

function Warses_ComebackScoreBonus(teamID)
    if GAMEMODE.ComebackTeam == teamID and teamID ~= 0 then
        return CV_SCORE:GetInt()
    end
    return 0
end

hook.Add("PlayerDeath", "Warses_Comeback_Respawn", function(victim)
    if not IsValid(victim) then return end
    if GAMEMODE.ComebackTeam == 0 or GAMEMODE.ComebackTeam ~= victim:Team() then return end

    local data = GAMEMODE.PlayerData and GAMEMODE.PlayerData[victim:SteamID()]
    if not data or not data.respawnTime then return end

    local reduction = CV_RESP:GetInt()
    data.respawnTime = math.max(CurTime() + 1, data.respawnTime - reduction)
end)

hook.Add("ShutDown", "Warses_Comeback_Cleanup", function()
    timer.Remove("Warses_ComebackTick")
end)

print("[Warses] Comeback system loaded.")
