AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("cl_teammenu.lua")
AddCSLuaFile("cl_classmenu.lua")
AddCSLuaFile("cl_hud.lua")
AddCSLuaFile("cl_scoreboard.lua")
AddCSLuaFile("cl_adminmenu.lua")
AddCSLuaFile("cl_squadmenu.lua")
AddCSLuaFile("cl_zombie.lua")
AddCSLuaFile("cl_markers.lua")
AddCSLuaFile("cl_spectator.lua")
AddCSLuaFile("sh_safevehicle.lua")
AddCSLuaFile("sh_vip.lua")

include("shared.lua")
include("sh_vip.lua")
include("sv_mapsetup.lua")
include("sv_mapvote.lua")
include("sv_admintool.lua")
include("sv_squads.lua")
include("sv_zombie.lua")
include("sv_comeback.lua")
include("sv_spectator.lua")
include("sh_safevehicle.lua")

GM.PlayerData = {}

function Warses_RandomizeBodygroups(ply)
    if not IsValid(ply) then return end
    local n = ply:GetNumBodyGroups() or 0
    for i = 0, n - 1 do
        local count = ply:GetBodygroupCount(i)
        if count and count > 1 then
            ply:SetBodygroup(i, math.random(0, count - 1))
        end
    end
end

local WIN_SCORE = 1000
local GAME_OVER = false

function Warses_IsGameOver() return GAME_OVER end
function Warses_SetGameOver(state) GAME_OVER = state and true or false end

function GM:DetermineGameMode()
    local map = string.lower(game.GetMap())
    local supportedModes = self.MapGameModes[map]

    if supportedModes and supportedModes[1] then
        self.CurrentGameMode = supportedModes[1]
    else
        self.CurrentGameMode = "capture"
    end

    if supportedModes then
        local nextModeFile = "warses_next_gamemode.txt"
        if file.Exists(nextModeFile, "DATA") then
            local nextMode = string.Trim(file.Read(nextModeFile, "DATA"))
            for _, m in ipairs(supportedModes) do
                if m == nextMode then
                    self.CurrentGameMode = nextMode
                    break
                end
            end
            file.Delete(nextModeFile)
        end
    end
    print("[Warses] Current GameMode: " .. self.CurrentGameMode)
end

local HOSTNAME_PREFIX = "Warses №1"

function GM:UpdateHostname()
    local parts = {}

    local conflict = self.Conflicts[self.CurrentConflict]
    if istable(conflict) then
        if conflict.name then table.insert(parts, conflict.name) end

        if istable(conflict.subconflicts) then
            local sub = conflict.subconflicts[self.CurrentSubconflict]
            if istable(sub) and sub.name then table.insert(parts, sub.name) end
        end
    end

    local name = HOSTNAME_PREFIX
    if #parts > 0 then
        name = name .. " | " .. table.concat(parts, " · ")
    end

    RunConsoleCommand("hostname", name)
    print("[Warses] Hostname → " .. name)
end

function GM:Initialize()
    self:CreateTeams()
    self:DetectConflictByMap()
    self:UpdateHostname()
    timer.Simple(3, function()
        if GAMEMODE and GAMEMODE.UpdateHostname then GAMEMODE:UpdateHostname() end
    end)
    self:DetermineGameMode()

    GAME_OVER = false
    SetGlobalInt("AlphaScore", 0)
    SetGlobalInt("BravoScore", 0)
    SetGlobalInt("GameTime", 0)

    if self.CurrentGameMode == "operation" then
        SetGlobalInt("AttackerTickets", 0)
        SetGlobalInt("ActiveSector", 1)
        self.TicketRewardedPlayers = {}
    end

    timer.Create("Warses_ScoringLoop", 1, 0, function()
        if GAME_OVER then return end

        local curTime = GetGlobalInt("GameTime") + 1
        SetGlobalInt("GameTime", curTime)

        if GAMEMODE.CurrentGameMode == "zombie" then
            return
        end

        if GAMEMODE.CurrentGameMode == "deathmatch" then
            return
        end

        if GAMEMODE.CurrentGameMode == "operation" then
            local activeSector = GetGlobalInt("ActiveSector", 1)
            local attackTeam = GAMEMODE.MapConfig.operation_attack_team or TEAM_ALPHA
            local defendTeam = attackTeam == TEAM_ALPHA and TEAM_BRAVO or TEAM_ALPHA

            local allCaptured = true
            local pointsInSector = 0
            local nextSector = activeSector + 1
            local hasNextSector = false

            local cps = Warses_GetCPs()
            for i = 1, #cps do
                local cp = cps[i]
                if IsValid(cp) and cp.GetSector then
                    local sec = cp:GetSector()
                    if sec == activeSector then
                        pointsInSector = pointsInSector + 1
                        if cp:GetOwningTeam() ~= attackTeam then
                            allCaptured = false
                        end
                    elseif sec == nextSector then
                        hasNextSector = true
                    end
                end
            end

            if pointsInSector > 0 and allCaptured then
                if GAMEMODE.MapConfig.operation_sector_spawns and GAMEMODE.MapConfig.operation_sector_spawns[nextSector] then
                    hasNextSector = true
                end

                net.Start("Warses_OperationNotify")
                net.WriteInt(attackTeam, 8)
                net.Broadcast()

                if hasNextSector then
                    SetGlobalInt("ActiveSector", nextSector)
                    SetGlobalInt("AttackerTickets", GetGlobalInt("AttackerTickets") + 50)
                else
                    Warses_EndGame(attackTeam)
                end
            end
        else
            if curTime % 5 == 0 then
                local alphaPoints = 0
                local bravoPoints = 0

                local cps = Warses_GetCPs()
                for i = 1, #cps do
                    local cp = cps[i]
                    if IsValid(cp) then
                        local owner = cp:GetOwningTeam()
                        if owner == TEAM_ALPHA then
                            alphaPoints = alphaPoints + 4
                        elseif owner == TEAM_BRAVO then
                            bravoPoints = bravoPoints + 4
                        end
                    end
                end

                local alphaBonus = Warses_ComebackScoreBonus and Warses_ComebackScoreBonus(TEAM_ALPHA) or 0
                local bravoBonus = Warses_ComebackScoreBonus and Warses_ComebackScoreBonus(TEAM_BRAVO) or 0
                SetGlobalInt("AlphaScore", GetGlobalInt("AlphaScore") + 2 + alphaPoints + alphaBonus)
                SetGlobalInt("BravoScore", GetGlobalInt("BravoScore") + 2 + bravoPoints + bravoBonus)

                if GetGlobalInt("AlphaScore") >= WIN_SCORE then
                    Warses_EndGame(TEAM_ALPHA)
                elseif GetGlobalInt("BravoScore") >= WIN_SCORE then
                    Warses_EndGame(TEAM_BRAVO)
                end
            end
        end
    end)

    print("[Warses] Gamemode initialized with Scoring Logic!")
end

function GM:InitPostEntity()
    self:LoadMapConfig()

    if self.CurrentGameMode == "operation" then
        local attackTeam = self.MapConfig.operation_attack_team or TEAM_ALPHA
        local defendTeam = attackTeam == TEAM_ALPHA and TEAM_BRAVO or TEAM_ALPHA
        local cps = Warses_GetCPs()
        for i = 1, #cps do
            local cp = cps[i]
            if IsValid(cp) then
                cp:SetOwningTeam(defendTeam)
                cp:SetCaptureProgress(100)
                cp:SetProgressTeam(defendTeam)
            end
        end
    end
    print("[Warses] Map configuration loaded.")
end

function GM:PlayerInitialSpawn(ply)
    ply:SetTeam(TEAM_SPECTATOR)

    self.PlayerData[ply:SteamID()] = {
        team = nil,
        class = nil,
        respawnTime = 0,
        deaths = 0,
        kills = 0
    }

    timer.Simple(1, function()
        if IsValid(ply) then
            self:SyncGameState(ply)
            net.Start("Warses_OpenTeamMenu")
            net.Send(ply)
        end
    end)
end

function GM:PlayerDisconnected(ply)
    self.PlayerData[ply:SteamID()] = nil
end

function GM:GetCustomSpawnPos(teamID)
    if self.CurrentGameMode == "operation" then
        local attackTeam = self.MapConfig.operation_attack_team or TEAM_ALPHA
        local activeSector = GetGlobalInt("ActiveSector", 1)

        if teamID == attackTeam then
            local spawns = nil
            if activeSector > 1 and self.MapConfig.operation_attack_sector_spawns and self.MapConfig.operation_attack_sector_spawns[activeSector - 1] and #self.MapConfig.operation_attack_sector_spawns[activeSector - 1] > 0 then
                spawns = self.MapConfig.operation_attack_sector_spawns[activeSector - 1]
            elseif self.MapConfig.operation_attack_spawns and #self.MapConfig.operation_attack_spawns > 0 then
                spawns = self.MapConfig.operation_attack_spawns
            end
            if spawns and #spawns > 0 then return spawns[math.random(#spawns)] end
        else
            if self.MapConfig.operation_sector_spawns and self.MapConfig.operation_sector_spawns[activeSector] and #self.MapConfig.operation_sector_spawns[activeSector] > 0 then
                local spawns = self.MapConfig.operation_sector_spawns[activeSector]
                return spawns[math.random(#spawns)]
            elseif self.MapConfig.spawns and self.MapConfig.spawns[teamID] and #self.MapConfig.spawns[teamID] > 0 then
                local spawns = self.MapConfig.spawns[teamID]
                return spawns[math.random(#spawns)]
            end
        end
    elseif self.MapConfig and self.MapConfig.spawns then
         local teamSpawns = self.MapConfig.spawns[teamID]
         if teamSpawns and #teamSpawns > 0 then
             return teamSpawns[math.random(#teamSpawns)]
         end
    end
    return nil
end

local function CPHullClear(pos, ply)
    local mins, maxs = ply:OBBMins(), ply:OBBMaxs()
    local tr = util.TraceHull({
        start  = pos + Vector(0, 0, 4),
        endpos = pos + Vector(0, 0, 4),
        mins   = mins,
        maxs   = maxs,
        filter = ply,
        mask   = MASK_PLAYERSOLID,
    })
    return not tr.StartSolid and not tr.AllSolid
end

local function FindSafeSpawnAtCP(cp, spawningPly)
    if not IsValid(cp) then return nil, nil end
    local basePos = cp:GetPos()
    local r = 80
    local zt = cp.GetZoneType and cp:GetZoneType() or 0
    if zt == 1 then
        r = math.max((cp:GetZoneLength() or 200) / 2, (cp:GetZoneWidth() or 200) / 2) - 30
    elseif zt == 2 then
        r = (cp:GetZoneWidth() or 200) - 30
    else
        r = (cp:GetZoneWidth() or 200) - 30
    end
    r = math.max(40, r)

    local attempts = {
        Vector(0, 0, 0),
        Vector(r,  0, 0), Vector(-r, 0, 0),
        Vector(0,  r, 0), Vector(0, -r, 0),
        Vector(r * 0.7,  r * 0.7, 0), Vector(-r * 0.7,  r * 0.7, 0),
        Vector(r * 0.7, -r * 0.7, 0), Vector(-r * 0.7, -r * 0.7, 0),
    }
    for i = #attempts, 2, -1 do
        local j = math.random(i)
        attempts[i], attempts[j] = attempts[j], attempts[i]
    end

    for _, off in ipairs(attempts) do
        local pos = basePos + off + Vector(0, 0, 16)
        if CPHullClear(pos, spawningPly) then
            local tr = util.TraceLine({
                start  = pos + Vector(0, 0, 16),
                endpos = pos - Vector(0, 0, 256),
                filter = { spawningPly, cp },
                mask   = MASK_PLAYERSOLID,
            })
            if tr.Hit and not tr.StartSolid then
                pos = tr.HitPos + Vector(0, 0, 2)
            end
            local ang = Angle(0, 0, 0)
            if off:LengthSqr() > 1 then
                ang = (basePos - pos):Angle()
                ang.p = 0; ang.r = 0
            end
            return pos, ang
        end
    end
    return nil, nil
end

function Warses_TryCapturePointSpawn(ply, cpIndex)
    if not IsValid(ply) then return nil end
    if GAMEMODE.CurrentGameMode == "operation" then
        if ply.ChatPrint then ply:ChatPrint("[Спавн] В режиме Операция спавн на точках отключён.") end
        return nil
    end
    local cp = Entity(tonumber(cpIndex) or 0)
    if not IsValid(cp) or cp:GetClass() ~= "warses_capturepoint" then
        if ply.ChatPrint then ply:ChatPrint("[Спавн] Точка не найдена.") end
        return nil
    end
    if cp:GetOwningTeam() ~= ply:Team() then
        if ply.ChatPrint then ply:ChatPrint("[Спавн] Точка не принадлежит вашей команде.") end
        return nil
    end
    local until_ = cp.GetAttackUntil and cp:GetAttackUntil() or 0
    if until_ > CurTime() then
        local left = math.ceil(until_ - CurTime())
        if ply.ChatPrint then ply:ChatPrint("[Спавн] Точка под атакой ещё " .. left .. " сек.") end
        return nil
    end
    local pos, ang = FindSafeSpawnAtCP(cp, ply)
    if not pos then
        if ply.ChatPrint then ply:ChatPrint("[Спавн] Нет свободного места у точки.") end
        return nil
    end
    return { pos = pos, ang = ang }
end

function GM:PlayerSpawn(ply)
    local data = self.PlayerData[ply:SteamID()]

    if not data or not data.team or not data.class then
        if not (GAMEMODE.ZombieActive) and Warses_EnterSpectator then
            Warses_EnterSpectator(ply)
        else
            ply:Spectate(OBS_MODE_ROAMING)
        end
        return
    end

    if GAME_OVER then
        ply:Freeze(true)
    end

    if Warses_ExitSpectator then Warses_ExitSpectator(ply) end
    ply:UnSpectate()
    ply:SetupHands()

    local squadSpawnPos, squadSpawnAng
    if ply.WarsesNextSpawnTarget and ply.WarsesNextSpawnTarget ~= "" then
        local tgt = ply.WarsesNextSpawnTarget
        local result
        if string.sub(tgt, 1, 3) == "cp:" and Warses_TryCapturePointSpawn then
            local cpIdx = tonumber(string.sub(tgt, 4)) or 0
            result = Warses_TryCapturePointSpawn(ply, cpIdx)
        else
            result = Warses_TrySquadSpawn(ply, tgt)
        end
        if result then
            squadSpawnPos = result.pos
            squadSpawnAng = result.ang
        end
        ply.WarsesNextSpawnTarget = nil
    end

    if squadSpawnPos then
        ply:SetPos(squadSpawnPos)
        if squadSpawnAng then ply:SetEyeAngles(squadSpawnAng) end
        timer.Simple(0, function()
            if IsValid(ply) and ply:Alive() then
                ply:SetPos(squadSpawnPos)
                if squadSpawnAng then ply:SetEyeAngles(squadSpawnAng) end
            end
        end)
    else
        local customPos = self:GetCustomSpawnPos(data.team)
        if customPos then
            if type(customPos) == "table" and customPos.x then customPos = Vector(customPos.x, customPos.y, customPos.z) end
            ply:SetPos(customPos)

            timer.Simple(0, function()
                if IsValid(ply) and ply:Alive() then
                    ply:SetPos(customPos)
                end
            end)
        end
    end

    local teamInfo = self:GetTeamInfo(data.team)
    local classInfo = self.Classes[data.class]

    if self.CurrentGameMode == "zombie" and data.class == "zombie" and classInfo and classInfo.zombie_models then
        local zm = classInfo.zombie_models
        ply:SetModel(zm[math.random(#zm)])
    elseif teamInfo and teamInfo.models then
        if teamInfo.models[data.class] then
            local classModels = teamInfo.models[data.class]
            ply:SetModel(classModels[math.random(#classModels)])
        elseif type(teamInfo.models[1]) == "string" then
            ply:SetModel(teamInfo.models[math.random(#teamInfo.models)])
        end
    elseif classInfo then
        ply:SetModel(classInfo.model)
    end

    timer.Simple(0, function()
        if not IsValid(ply) or not ply:Alive() then return end
        Warses_RandomizeBodygroups(ply)
    end)

    if classInfo then
        ply:SetHealth(classInfo.health or 100)
        ply:SetArmor(classInfo.armor or 0)
    end

    self:PlayerLoadout(ply)
end

function GM:PlayerLoadout(ply)
    local data = self.PlayerData[ply:SteamID()]
    if not data or not data.class then return end

    local classInfo = self.Classes[data.class]
    if not classInfo then return end

    ply:StripWeapons()
    ply:RemoveAllAmmo()

    local weapons = nil
    local conflict = self.Conflicts[self.CurrentConflict]
    local subconflict = conflict and conflict.subconflicts[self.CurrentSubconflict] or nil

    if subconflict and subconflict.weaponLoadouts then
        local teamLoadout = subconflict.weaponLoadouts[data.team]
        if teamLoadout then
            weapons = teamLoadout[data.class]
        end
    end

    if not weapons then
        weapons = classInfo.weapons
    end

    local ammoOverrides = nil
    if weapons and ply.WarsesWeaponChoice then
        local choice = ply.WarsesWeaponChoice
        weapons = table.Copy(weapons)
        for _, slot in ipairs({"primary", "secondary"}) do
            local idx = (slot == "primary") and 1 or 2
            if choice[slot] and weapons[idx] then
                local v = self:FindWeaponVariant(data.team, data.class, slot, choice[slot])
                if v then
                    weapons[idx] = v.wep
                    if v.ammo then
                        ammoOverrides = ammoOverrides or {}
                        for k, val in pairs(v.ammo) do
                            ammoOverrides[k] = val
                        end
                    end
                end
            end
        end
    end

    if weapons then
        for _, weapon in ipairs(weapons) do
            local wep = ply:Give(weapon)

            local attachments = nil
            if subconflict and subconflict.attachmentLoadouts then
                local teamAtts = subconflict.attachmentLoadouts[data.team]
                if teamAtts then
                    attachments = teamAtts[data.class]
                end
            end

            if attachments and IsValid(wep) and wep.attachments and hg and hg.AddAttachmentForce then
                timer.Simple(0.2, function()
                    if IsValid(wep) and IsValid(ply) then
                        for _, att in ipairs(attachments) do
                            local cleanAtt = att
                            if string.StartWith(att, "ent_att_") then
                                cleanAtt = string.sub(att, 9)
                            end
                            print("[Warses] Auto-attaching " .. cleanAtt .. " to " .. wep:GetClass() .. " for " .. ply:Nick())
                            hg.AddAttachmentForce(ply, wep, cleanAtt)
                        end
                    end
                end)
            end
        end

        if weapons[1] then
            ply:SelectWeapon(weapons[1])
        end
    end

    local ammo = nil
    if conflict then
        local subconflict = conflict.subconflicts[self.CurrentSubconflict]
        if subconflict and subconflict.ammoLoadouts then
            local teamAmmo = subconflict.ammoLoadouts[data.team]
            if teamAmmo then
                ammo = teamAmmo[data.class]
            end
        end
    end

    if not ammo then
        ammo = classInfo.ammo
    end

    if ammoOverrides then
        ammo = ammo and table.Copy(ammo) or {}
        for k, v in pairs(ammoOverrides) do ammo[k] = v end
    end

    if ammo then
        for ammoType, amount in pairs(ammo) do
            if amount and amount > 0 then
                self:warses_give_ammo(ply, ammoType, amount)
            end
        end
    end
end

function GM:warses_give_ammo(ply, ammoType, amount)
    if not IsValid(ply) then return end

    local entClass = ammoType
    if not scripted_ents.Get(entClass) then
        entClass = "ent_ammo_" .. ammoType
    end

    if scripted_ents.Get(entClass) then
        local ent = ents.Create(entClass)
        if IsValid(ent) then
            ent:SetPos(ply:GetPos())
            ent:Spawn()

            if amount then
                ent.AmmoCount = amount
            end

            if ent.Use then
                ent:Use(ply, ply, SIMPLE_USE, 0)
            end

            if IsValid(ent) then ent:Remove() end

            print("[Warses] Gave ammo entity: " .. entClass .. " (" .. tostring(amount) .. ")")
            return
        end
    end

    ply:GiveAmmo(amount, ammoType)
end

function GM:DoPlayerDeath(ply, attacker, dmginfo)
    if not dmginfo:IsDamageType(DMG_REMOVENORAGDOLL) then
        ply:CreateRagdoll()
    end

    ply:AddDeaths(1)

    if IsValid(attacker) and attacker:IsPlayer() and attacker ~= ply then
        attacker:AddFrags(1)
    end
end

function Warses_DM_AddScore(teamID, delta)
    if GAMEMODE.CurrentGameMode ~= "deathmatch" then return end
    if Warses_IsGameOver() then return end
    if delta == 0 then return end

    local key
    if teamID == TEAM_ALPHA then
        key = "AlphaScore"
    elseif teamID == TEAM_BRAVO then
        key = "BravoScore"
    else
        return
    end

    local newScore = math.max(0, GetGlobalInt(key, 0) + delta)
    SetGlobalInt(key, newScore)

    if delta > 0 and newScore >= Warses_CV_DMWinScore:GetInt() then
        Warses_EndGame(teamID)
    end
end

function GM:PlayerDeath(victim, inflictor, attacker)
    local data = self.PlayerData[victim:SteamID()]
    if data then
        data.deaths = (data.deaths or 0) + 1
        data.respawnTime = CurTime() + Warses_CV_Respawn:GetInt()
        victim:SetDeaths(data.deaths)
    end

    Warses_DM_AddScore(victim:Team(), -Warses_CV_DMDeathPenalty:GetInt())

    if self.CurrentGameMode == "operation" then
        local attackTeam = self.MapConfig and self.MapConfig.operation_attack_team or TEAM_ALPHA
        local defendTeam = attackTeam == TEAM_ALPHA and TEAM_BRAVO or TEAM_ALPHA
        if victim:Team() == attackTeam then
            local t = GetGlobalInt("AttackerTickets") - 1
            SetGlobalInt("AttackerTickets", math.max(0, t))
            if t <= 0 and not GAME_OVER then
                Warses_EndGame(defendTeam)
            end
        end
    end

    local realAttacker = attacker
    if (not IsValid(realAttacker) or not realAttacker:IsPlayer() or realAttacker == victim) then
        if IsValid(victim.WarsesLastAttacker) and victim.WarsesLastAttacker:IsPlayer() and victim.WarsesLastAttacker ~= victim then
            realAttacker = victim.WarsesLastAttacker
        end
    end

    if IsValid(realAttacker) and realAttacker:IsPlayer() and realAttacker ~= victim then
        local isTeamkill = (realAttacker:Team() == victim:Team())

        if isTeamkill then
            realAttacker.WarsesTKCount = (realAttacker.WarsesTKCount or 0) + 1
            realAttacker:ChatPrint("Вы убили союзника! (" .. realAttacker.WarsesTKCount .. "/5)")

            if realAttacker.WarsesTKCount >= 5 and realAttacker:GetUserGroup() == "user" then
                local targetID = realAttacker:SteamID()
                timer.Simple(0.1, function()
                    if IsValid(realAttacker) then
                        realAttacker:Kick("Бан на 30 минут: Убийство 5 союзников")
                        RunConsoleCommand("ulx", "banid", targetID, "30", "Массовый Тимкилл (Gilt System)")
                        RunConsoleCommand("banid", "30", targetID)
                        RunConsoleCommand("writeid")
                    end
                end)
            end
        else
            local attackerData = self.PlayerData[realAttacker:SteamID()]
            if attackerData then
                attackerData.kills = (attackerData.kills or 0) + 1
                realAttacker:SetFrags(attackerData.kills)
            end

            Warses_DM_AddScore(realAttacker:Team(), Warses_CV_DMKillPoints:GetInt())
        end
    end

    victim.WarsesLastAttacker = nil

    timer.Simple(9, function()
        if not IsValid(victim) then return end
        local ragdoll = victim:GetRagdollEntity()
        if IsValid(ragdoll) then ragdoll:Remove() end
    end)

    if self.ZombieActive then return end

    local MENU_DELAY = 4
    timer.Simple(MENU_DELAY, function()
        if not IsValid(victim) then return end
        if victim:Alive() then return end

        local respawnTime = Warses_CV_Respawn:GetFloat()
        local data = GAMEMODE.PlayerData[victim:SteamID()]
        local remaining = respawnTime - MENU_DELAY
        if data and data.respawnTime then
            remaining = math.max(0, data.respawnTime - CurTime())
        end

        net.Start("Warses_OpenClassMenu")
        net.WriteBool(true)
        net.WriteFloat(math.max(0, remaining))
        net.Send(victim)
    end)
end

function GM:PlayerDeathThink(ply)
    local data = self.PlayerData[ply:SteamID()]
    if not data then return false end

    if CurTime() < (data.respawnTime or 0) then
        return false
    end

    return false
end

function GM:PlayerRequestSpawn(ply, targetSID)
    local data = self.PlayerData[ply:SteamID()]
    if not data then return end

    if CurTime() < (data.respawnTime or 0) then
        return
    end

    if not data.class then
        return
    end

    ply.WarsesNextSpawnTarget = targetSID
    ply:Spawn()
end

function GM:PlayerSelectSpawn(ply)
    local data = self.PlayerData[ply:SteamID()]
    local teamID = data and data.team

    local customPos = self:GetCustomSpawnPos(teamID)
    if customPos then
        if type(customPos) == "table" and customPos.x then customPos = Vector(customPos.x, customPos.y, customPos.z) end

        if not IsValid(self.DummySpawnPos) then
            self.DummySpawnPos = ents.Create("info_target")
            self.DummySpawnPos:Spawn()
        end
        self.DummySpawnPos:SetPos(customPos)
        return self.DummySpawnPos
    end

    local spawns = ents.FindByClass("info_player_start")
    table.Add(spawns, ents.FindByClass("info_player_terrorist"))
    table.Add(spawns, ents.FindByClass("info_player_counterterrorist"))

    if #spawns > 0 then
        return spawns[math.random(#spawns)]
    end

    return nil
end

function GM:PlayerShouldTakeDamage(ply, attacker)
    if not Warses_CV_FriendlyFire:GetBool() and IsValid(attacker) and attacker:IsPlayer() then
        if ply:Team() == attacker:Team() and ply ~= attacker then
            return false
        end
    end
    return true
end

util.AddNetworkString("Warses_OpenTeamMenu")
util.AddNetworkString("Warses_OpenClassMenu")
util.AddNetworkString("Warses_SelectTeam")
util.AddNetworkString("Warses_SelectClass")
util.AddNetworkString("Warses_RequestSpawn")
util.AddNetworkString("Warses_UpdateConflict")
util.AddNetworkString("Warses_SyncGameState")
util.AddNetworkString("Warses_SpawnKamikaze")
util.AddNetworkString("Warses_OperationNotify")
util.AddNetworkString("Warses_BaseAlert")
util.AddNetworkString("Warses_WeaponChoice")

net.Receive("Warses_SpawnKamikaze", function(len, ply)
    if not IsValid(ply) or not ply:Alive() then return end

    local data = GAMEMODE.PlayerData[ply:SteamID()]
    if not data or data.class ~= "support" then
        ply:ChatPrint("Только класс Support может спаунить дрон!")
        return
    end

    if GAMEMODE.CurrentConflict ~= "modern" or GAMEMODE.CurrentSubconflict ~= "nato" then
        ply:ChatPrint("Дроны доступны только в современных конфликтах (NATO vs Russia)!")
        return
    end

    local lastUsage = data.lastKamikaze or 0
    local cooldown = 120
    if CurTime() < lastUsage + cooldown then
        local remaining = math.ceil((lastUsage + cooldown) - CurTime())
        ply:ChatPrint("Кулдаун дрона: " .. remaining .. " сек.")
        return
    end

    local drone = ents.Create("fpv_at")
    if IsValid(drone) then
        local pos = ply:GetPos() + ply:GetForward() * 60 + Vector(0, 0, 45)

        drone:SetPos(pos)
        drone:SetAngles(Angle(0, ply:EyeAngles().y, 0))
        drone:Spawn()
        drone:Activate()

        if drone.SetOwner then drone:SetOwner(ply) end
        if drone.SetCreator then drone:SetCreator(ply) end

        data.lastKamikaze = CurTime()
        ply:ChatPrint("Дрон камикадзе заспавнен!")
    else
        ply:ChatPrint("Ошибка: Сущность 'fpv_at' не найдена!")
    end
end)

net.Receive("Warses_SelectTeam", function(len, ply)
    local teamID = net.ReadInt(16)

    if teamID ~= TEAM_ALPHA and teamID ~= TEAM_BRAVO and teamID ~= TEAM_SPECTATOR then
        return
    end

    if GAMEMODE.ZombieActive or GAMEMODE.ZombiePending or timer.Exists("Warses_ZombieStartGameplay") then
        ply:ChatPrint("[Зомби] Смена команды сейчас недоступна.")
        return
    end

    local data = GAMEMODE.PlayerData[ply:SteamID()]
    if not data then return end

    local currentTeam = ply:Team()

    if teamID == TEAM_SPECTATOR then
        if currentTeam == TEAM_SPECTATOR then return end

        if Warses_CleanupOnTeamChange then
            Warses_CleanupOnTeamChange(ply)
        end

        data.team = TEAM_SPECTATOR
        data.class = nil
        data.respawnTime = 0
        ply.WarsesNextSpawnTarget = nil
        ply:SetNWString("Class", "")

        if ply:Alive() then ply:KillSilent() end
        ply:SetTeam(TEAM_SPECTATOR)
        ply:Spawn()
        return
    end

    if currentTeam ~= teamID then
        local otherTeam = (teamID == TEAM_ALPHA) and TEAM_BRAVO or TEAM_ALPHA
        local targetTeamCount = team.NumPlayers(teamID)
        local otherTeamCount = team.NumPlayers(otherTeam)

        if currentTeam == otherTeam then
            otherTeamCount = otherTeamCount - 1
        end

        if targetTeamCount > otherTeamCount then
            ply:ChatPrint("Эта команда переполнена! Выберите команду с меньшим числом игроков для баланса.")
            return
        end
    end

    if GAMEMODE.CurrentGameMode == "operation" and currentTeam ~= teamID then
        local attackTeam = GAMEMODE.MapConfig and GAMEMODE.MapConfig.operation_attack_team or TEAM_ALPHA
        if teamID == attackTeam and not GAMEMODE.TicketRewardedPlayers[ply:SteamID()] then
            GAMEMODE.TicketRewardedPlayers[ply:SteamID()] = true
            SetGlobalInt("AttackerTickets", GetGlobalInt("AttackerTickets") + 10)
        end
    end

    local isRespawning = false
    local respawnTime = 0
    if data.respawnTime and CurTime() < data.respawnTime then
        isRespawning = true
        respawnTime = data.respawnTime - CurTime()
    end

    if currentTeam ~= teamID and Warses_CleanupOnTeamChange then
        Warses_CleanupOnTeamChange(ply)
    end

    data.team = teamID
    ply:SetTeam(teamID)

    data.class = nil
    ply:SetNWString("Class", "")
    ply.WarsesWeaponChoice = nil

    if currentTeam == TEAM_SPECTATOR then
        if Warses_ExitSpectator then Warses_ExitSpectator(ply) end
        if ply:Alive() then ply:KillSilent() end
    end

    if Warses_BroadcastSquads then
        Warses_BroadcastSquads(teamID)
    end

    net.Start("Warses_OpenClassMenu")
    net.WriteBool(isRespawning)
    net.WriteFloat(respawnTime)
    net.Send(ply)
end)

net.Receive("Warses_SelectClass", function(len, ply)
    if GAMEMODE.ZombieActive or GAMEMODE.ZombiePending or timer.Exists("Warses_ZombieStartGameplay") then return end

    local classID = net.ReadString()

    local availableClasses = GAMEMODE:GetAvailableClasses(ply:Team())
    if not availableClasses[classID] then
        return
    end

    local data = GAMEMODE.PlayerData[ply:SteamID()]
    if not data or not data.team then return end

    local classInfo = availableClasses[classID]

    if classInfo and classInfo.max_players and not Warses_IsVIP(ply) then
        local count = 0
        for _, p in ipairs(player.GetAll()) do
            if p:Team() == data.team and p:GetNWString("Class") == classID then
                count = count + 1
            end
        end

        if count >= classInfo.max_players and ply:GetNWString("Class") ~= classID then
            ply:ChatPrint("Этот класс переполнен! (" .. count .. "/" .. classInfo.max_players .. ")")
            return
        end
    end

    if data.class ~= classID then
        ply.WarsesWeaponChoice = nil
    end
    data.class = classID
    ply:SetNWString("Class", classID)
end)

net.Receive("Warses_WeaponChoice", function(len, ply)
    if not IsValid(ply) then return end
    local slot     = net.ReadString()
    local wepClass = net.ReadString()

    if slot ~= "primary" and slot ~= "secondary" then return end

    local data = GAMEMODE.PlayerData[ply:SteamID()]
    if not data or not data.team or not data.class then return end

    if wepClass == "" then
        if ply.WarsesWeaponChoice then ply.WarsesWeaponChoice[slot] = nil end
        return
    end

    local variant = GAMEMODE:FindWeaponVariant(data.team, data.class, slot, wepClass)
    if not variant then return end

    ply.WarsesWeaponChoice = ply.WarsesWeaponChoice or {}
    ply.WarsesWeaponChoice[slot] = wepClass
end)

net.Receive("Warses_RequestSpawn", function(len, ply)
    if GAMEMODE.ZombieActive or GAMEMODE.ZombiePending or timer.Exists("Warses_ZombieStartGameplay") then return end

    local hasTarget = net.ReadBool()
    local targetSID = nil
    if hasTarget then
        targetSID = net.ReadString()
    end
    GAMEMODE:PlayerRequestSpawn(ply, targetSID)
end)

function GM:SyncGameState(ply)
    net.Start("Warses_SyncGameState")
    net.WriteString(self.CurrentConflict)
    net.WriteString(self.CurrentSubconflict)
    net.WriteString(self.CurrentGameMode)
    net.Send(ply)
end

function GM:PlayerDroppedWeapon(ply, weapon)
    if IsValid(weapon) then
        timer.Simple(10, function()
            if IsValid(weapon) and not IsValid(weapon:GetOwner()) then
                weapon:Remove()
            end
        end)
    end
end

function Warses_EndGame(winningTeam)
    GAME_OVER = true
    timer.Remove("Warses_ScoringLoop")

    PrintMessage(HUD_PRINTTALK,
        team.GetName(winningTeam) .. " wins the match!"
    )

    for _, ply in ipairs(player.GetAll()) do
        ply:Freeze(true)
    end

    if Warses_CheckZombieTrigger and Warses_CheckZombieTrigger(winningTeam) then
        print("[Warses] Zombie mode armed for upcoming map vote")
    end

    timer.Simple(5, function()
        hook.Run("StartMapVote")
    end)
end

hook.Add("InitPostEntity", "WarsesAttachmentLimits", function()
    timer.Simple(1, function()
        if not hg or not hg.AddAttachment then return end

        local oldAddAttachment = hg.AddAttachment
        function hg.AddAttachment(ply, wep, att)
            if not IsValid(ply) or not IsValid(wep) then return oldAddAttachment(ply, wep, att) end

            local steamid = ply:SteamID()
            local data = GM.PlayerData[steamid]
            if data and data.class then
                local classInfo = GM.Classes[data.class]
                if classInfo and classInfo.att_slots then
                    local count = 0
                    for _, slotData in pairs(wep.attachments or {}) do
                        if istable(slotData) and slotData[1] and slotData[1] ~= "empty" then
                            count = count + 1
                        end
                    end

                    local placement = nil
                    for plc, tbl in pairs(hg.attachments) do
                        if tbl[att] then placement = plc break end
                    end

                    local isReplacing = false
                    if placement and wep.attachments[placement] and wep.attachments[placement][1] ~= "empty" then
                        isReplacing = true
                    end

                    if not isReplacing and count >= classInfo.att_slots then
                        ply:ChatPrint("У вашего класса лимит слотов для аттачментов: " .. classInfo.att_slots)
                        return false
                    end
                end
            end

            return oldAddAttachment(ply, wep, att)
        end
        print("[Warses] Attachment limits initialized.")
    end)
end)

local function Warses_PlayerInAnyGravityZone(ply)
    if not IsValid(ply) then return false end
    local zones = Warses_GetGZs()
    for i = 1, #zones do
        local zone = zones[i]
        if IsValid(zone) and zone.IsPlayerInZone and zone:IsPlayerInZone(ply) then
            return true
        end
    end
    return false
end

local function Warses_ApplyZeroGravity(ply)
    if not IsValid(ply) then return end
    ply:SetGravity(0.0001)
    ply.WarsesInZeroG = true
end

local function Warses_ApplyNormalGravity(ply)
    if not IsValid(ply) then return end
    ply:SetGravity(1)
    ply.WarsesInZeroG = false
end

function GM:Warses_UpdateGravityState(ply)
    if not IsValid(ply) or not ply:Alive() then return end
    if ply:Team() == TEAM_SPECTATOR then return end

    if not GAMEMODE:IsZeroGravityConflict() then
        if ply.WarsesInZeroG then Warses_ApplyNormalGravity(ply) end
        return
    end

    if Warses_PlayerInAnyGravityZone(ply) then
        if ply.WarsesInZeroG ~= false then Warses_ApplyNormalGravity(ply) end
    else
        if ply.WarsesInZeroG ~= true then Warses_ApplyZeroGravity(ply) end
    end
end

hook.Add("PlayerSpawn", "Warses_GravityOnSpawn", function(ply)
    timer.Simple(0.1, function()
        if IsValid(ply) then GAMEMODE:Warses_UpdateGravityState(ply) end
    end)
end)

timer.Create("Warses_GravityZoneTick", 0.5, 0, function()
    if not GAMEMODE then return end
    if not GAMEMODE:IsZeroGravityConflict() then return end
    local zones = Warses_GetGZs()
    local hasZones = false
    for i = 1, #zones do
        if IsValid(zones[i]) then hasZones = true; break end
    end
    local plys = player.GetAll()
    if not hasZones then
        for i = 1, #plys do
            local ply = plys[i]
            if IsValid(ply) and ply:Alive() and ply:Team() ~= TEAM_SPECTATOR and ply.WarsesInZeroG ~= true then
                Warses_ApplyZeroGravity(ply)
            end
        end
        return
    end
    for i = 1, #plys do
        GAMEMODE:Warses_UpdateGravityState(plys[i])
    end
end)

hook.Add("EntityTakeDamage", "Warses_Gilt_TrackDamage", function(target, dmginfo)
    if not IsValid(target) or not target:IsPlayer() then return end

    local attacker = dmginfo:GetAttacker()
    if not IsValid(attacker) then return end

    if attacker:IsVehicle() and IsValid(attacker:GetDriver()) then
        attacker = attacker:GetDriver()
    elseif not attacker:IsPlayer() and IsValid(attacker:GetOwner()) and attacker:GetOwner():IsPlayer() then
        attacker = attacker:GetOwner()
    end

    if attacker:IsPlayer() and attacker ~= target then
        target.WarsesLastAttacker = attacker
        target.WarsesLastAttackerTime = CurTime()
    end
end)
