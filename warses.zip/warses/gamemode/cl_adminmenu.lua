CreateClientConVar("warses_show_spawn", "0", true, false,
    "Показывать границы зон и маркеры спаунов (admin only)")

surface.CreateFont("Warses_AM_Title",  {font = "Roboto", size = 28, weight = 800, antialias = true})
surface.CreateFont("Warses_AM_Sub",    {font = "Roboto", size = 16, weight = 600, antialias = true})
surface.CreateFont("Warses_AM_Btn",    {font = "Roboto", size = 15, weight = 700, antialias = true})
surface.CreateFont("Warses_AM_Small",  {font = "Roboto", size = 13, weight = 500, antialias = true})
surface.CreateFont("Warses_AM_Mode",   {font = "Roboto", size = 14, weight = 600, antialias = true})

WarsesAdminTool = WarsesAdminTool or {
    mode = "point",
    params = {
        pointName       = "Control Point",
        sector          = 0,
        team            = 1,
        vehicleClass    = "jeep",
        vehicleRespawn  = 30,
        vehicleColorR   = 255,
        vehicleColorG   = 255,
        vehicleColorB   = 255,
        zoneType        = 0,
        zoneLength      = 200,
        zoneWidth       = 200,
        zoneHeight      = 200,
        removeRadius    = 100,
    }
}

local Modes = {
    {id = "point",            name = "Точка захвата",        desc = "Обычная точка для режима «Захват»"},
    {id = "point_sek",        name = "Точка сектора",         desc = "Точка для режима «Операция» с номером сектора"},
    {id = "base",             name = "База",                  desc = "Зона базы команды"},
    {id = "spawn",            name = "Спаун команды",         desc = "Точка возрождения для выбранной команды"},
    {id = "op_attack",        name = "Спаун атаки (Op)",      desc = "Начальный спаун атакующей команды"},
    {id = "op_sector",        name = "Спаун сектора",         desc = "Спаун защитников указанного сектора"},
    {id = "op_attack_sector", name = "Спаун ат. сектора",     desc = "Спаун атакующих после взятия сектора N"},
    {id = "vehicle",          name = "Транспорт",             desc = "Спаунер транспорта с классом, кд и цветом"},
    {id = "zone_edit",        name = "Редактор зоны",         desc = "Применить тип и размер зоны к точке/базе/гравитации"},
    {id = "gravity_zone",     name = "Зона гравитации",       desc = "Space War: внутри зоны действует обычная гравитация"},
    {id = "remove",           name = "Удалить",               desc = "ЛКМ — удалить точку/базу/транспорт/зону или ближайший спаун"},
}

local Frame = nil

local function teamColor(id)
    if id == TEAM_ALPHA then return Color(60, 130, 220) end
    if id == TEAM_BRAVO then return Color(220, 60, 60) end
    return Color(180, 180, 180)
end

local function teamName(id)
    if id == TEAM_ALPHA then return "Alpha" end
    if id == TEAM_BRAVO then return "Bravo" end
    return "?"
end

local function PaintShadow(panel, w, h, col)
    surface.SetDrawColor(col.r, col.g, col.b, col.a or 255)
    surface.DrawRect(0, 0, w, h)
end

local function MakeButton(parent, text, accent, doClick)
    local btn = vgui.Create("DButton", parent)
    btn:SetText("")
    btn.anim = 0
    btn.Paint = function(self, w, h)
        self.anim = Lerp(FrameTime() * 10, self.anim, self:IsHovered() and 1 or 0)
        local base = Color(28, 32, 42)
        local hov  = Color(accent.r * 0.3, accent.g * 0.3, accent.b * 0.3)
        local r = math.Round(Lerp(self.anim, base.r, hov.r))
        local g = math.Round(Lerp(self.anim, base.g, hov.g))
        local b = math.Round(Lerp(self.anim, base.b, hov.b))
        surface.SetDrawColor(r, g, b, 240)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(accent.r, accent.g, accent.b, 220)
        surface.DrawRect(0, h - 2, w, 2)
        draw.SimpleText(text, "Warses_AM_Btn", w / 2, h / 2,
            Color(235, 240, 250), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    btn.DoClick = doClick
    return btn
end

local function BuildForm(parent, mode)
    parent:Clear()

    local y = 6
    local function row(label)
        local lbl = vgui.Create("DLabel", parent)
        lbl:SetPos(8, y)
        lbl:SetSize(parent:GetWide() - 16, 18)
        lbl:SetText(label)
        lbl:SetFont("Warses_AM_Small")
        lbl:SetTextColor(Color(180, 195, 220))
        y = y + 20
    end

    local function textEntry(key, default)
        local te = vgui.Create("DTextEntry", parent)
        te:SetPos(8, y)
        te:SetSize(parent:GetWide() - 16, 26)
        te:SetText(tostring(WarsesAdminTool.params[key] or default))
        te:SetFont("Warses_AM_Small")
        te.Paint = function(s, w, h)
            surface.SetDrawColor(20, 24, 32, 240)
            surface.DrawRect(0, 0, w, h)
            surface.SetDrawColor(80, 100, 130, 200)
            surface.DrawOutlinedRect(0, 0, w, h)
            s:DrawTextEntryText(Color(230, 240, 250), Color(120, 160, 220), Color(255, 255, 255))
        end
        te.OnChange = function(s)
            WarsesAdminTool.params[key] = s:GetValue()
        end
        y = y + 30
        return te
    end

    local function numEntry(key, default)
        local te = textEntry(key, default)
        te:SetNumeric(true)
        te.OnChange = function(s)
            WarsesAdminTool.params[key] = tonumber(s:GetValue()) or default
        end
        return te
    end

    local function teamPicker(key)
        local cur = WarsesAdminTool.params[key] or TEAM_ALPHA

        local function btn(x, w, id, label)
            local b = vgui.Create("DButton", parent)
            b:SetText("")
            b:SetPos(x, y)
            b:SetSize(w, 28)
            local col = teamColor(id)
            b.Paint = function(s, ww, hh)
                local sel = (WarsesAdminTool.params[key] == id)
                surface.SetDrawColor(sel and col.r * 0.5 or 28, sel and col.g * 0.5 or 32, sel and col.b * 0.5 or 42, 240)
                surface.DrawRect(0, 0, ww, hh)
                surface.SetDrawColor(col.r, col.g, col.b, sel and 255 or 120)
                surface.DrawRect(0, hh - 2, ww, 2)
                draw.SimpleText(label, "Warses_AM_Btn", ww / 2, hh / 2,
                    Color(235, 240, 250), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            b.DoClick = function()
                WarsesAdminTool.params[key] = id
                surface.PlaySound("ui/buttonclick.wav")
            end
        end

        local w = (parent:GetWide() - 24) / 2
        btn(8,             w, TEAM_ALPHA, "ALPHA")
        btn(16 + w,        w, TEAM_BRAVO, "BRAVO")
        y = y + 32
    end

    local function zoneTypePicker(key)
        local types = { [0] = "Сфера", [1] = "Куб", [2] = "Цилиндр" }
        local w = (parent:GetWide() - 32) / 3
        for i = 0, 2 do
            local b = vgui.Create("DButton", parent)
            b:SetText("")
            b:SetPos(8 + i * (w + 4), y)
            b:SetSize(w, 28)
            b.Paint = function(s, ww, hh)
                local sel = (WarsesAdminTool.params[key] == i)
                surface.SetDrawColor(sel and 50 or 28, sel and 70 or 32, sel and 100 or 42, 240)
                surface.DrawRect(0, 0, ww, hh)
                surface.SetDrawColor(120, 170, 240, sel and 255 or 120)
                surface.DrawRect(0, hh - 2, ww, 2)
                draw.SimpleText(types[i], "Warses_AM_Btn", ww / 2, hh / 2,
                    Color(235, 240, 250), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            b.DoClick = function()
                WarsesAdminTool.params[key] = i
                surface.PlaySound("ui/buttonclick.wav")
            end
        end
        y = y + 32
    end

    local function colorMixer()
        row("Цвет транспорта (RGB)")
        local cm = vgui.Create("DColorMixer", parent)
        cm:SetPos(8, y)
        cm:SetSize(parent:GetWide() - 16, 160)
        cm:SetPalette(true)
        cm:SetAlphaBar(false)
        cm:SetWangs(true)
        cm:SetColor(Color(
            WarsesAdminTool.params.vehicleColorR or 255,
            WarsesAdminTool.params.vehicleColorG or 255,
            WarsesAdminTool.params.vehicleColorB or 255))
        cm.ValueChanged = function(s, col)
            WarsesAdminTool.params.vehicleColorR = col.r
            WarsesAdminTool.params.vehicleColorG = col.g
            WarsesAdminTool.params.vehicleColorB = col.b
        end
        y = y + 164
    end

    if mode == "point" then
        row("Название точки")
        textEntry("pointName", "Control Point")

    elseif mode == "point_sek" then
        row("Название точки")
        textEntry("pointName", "Sector Point")
        row("Номер сектора")
        numEntry("sector", 1)

    elseif mode == "base" then
        row("Команда базы")
        teamPicker("team")

    elseif mode == "spawn" then
        row("Команда спауна")
        teamPicker("team")

    elseif mode == "op_attack" then
        row("Начальный спаун атаки. Параметры не нужны.")

    elseif mode == "op_sector" then
        row("Номер сектора (защитники)")
        numEntry("sector", 1)

    elseif mode == "op_attack_sector" then
        row("Номер сектора (после захвата)")
        numEntry("sector", 1)

    elseif mode == "vehicle" then
        row("Класс транспорта (jeep, airboat, simfphys_*…)")
        textEntry("vehicleClass", "jeep")
        row("Время респауна (сек)")
        numEntry("vehicleRespawn", 30)
        colorMixer()

    elseif mode == "zone_edit" then
        row("Тип зоны")
        zoneTypePicker("zoneType")
        row("Длина (для куба)")
        numEntry("zoneLength", 200)
        row("Ширина / радиус")
        numEntry("zoneWidth", 200)
        row("Высота")
        numEntry("zoneHeight", 200)
        row("Применить ЛКМ на точку/базу/зону")

    elseif mode == "gravity_zone" then
        row("Внутри зоны игроки получают обычную гравитацию.")
        row("Активна только в конфликте Space War.")
        row(" ")
        row("ЛКМ — отметить первую точку (один угол куба).")
        row("ЛКМ ещё раз — отметить вторую точку (противоположный угол).")
        row("R — сбросить отмеченную точку.")
        row(" ")

        local status = vgui.Create("DPanel", parent)
        status:SetPos(8, y)
        status:SetSize(parent:GetWide() - 16, 56)
        status.Paint = function(s, w, h)
            local p1 = WarsesAdminTool and WarsesAdminTool.gravityFirstPoint or nil
            local hasP1 = p1 ~= nil

            local bg = hasP1 and Color(40, 80, 50, 230) or Color(30, 38, 50, 230)
            surface.SetDrawColor(bg)
            surface.DrawRect(0, 0, w, h)

            local edge = hasP1 and Color(120, 230, 140, 240) or Color(120, 170, 240, 200)
            surface.SetDrawColor(edge)
            surface.DrawRect(0, h - 2, w, 2)

            local title = hasP1 and "Жду вторую точку (ЛКМ)…" or "Жду первую точку (ЛКМ)…"
            draw.SimpleText(title, "Warses_AM_Btn", 10, 8,
                Color(235, 240, 250), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

            if hasP1 then
                draw.SimpleText(
                    string.format("p1 = %d, %d, %d", math.Round(p1.x), math.Round(p1.y), math.Round(p1.z)),
                    "Warses_AM_Small", 10, 30,
                    Color(180, 220, 200), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            else
                draw.SimpleText("Подсказка: первый ЛКМ — нижний угол, второй — верхний.",
                    "Warses_AM_Small", 10, 30,
                    Color(170, 190, 220), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            end
        end
        y = y + 60

    elseif mode == "remove" then
        row("ЛКМ по объекту — удалить точку/базу/транспорт.")
        row("ЛКМ по полу — удалить ближайший спаун в радиусе.")
        row("Радиус поиска спауна (юниты)")
        numEntry("removeRadius", 100)
        row(" ")
        row("Также работает клавиша R на любом инструменте.")
    end
end

WarsesAdminSpawns = WarsesAdminSpawns or {}

net.Receive("WarsesAdmin_SpawnsList", function()
    WarsesAdminSpawns = net.ReadTable()
end)

function OpenWarsesAdminMenu()
    if not LocalPlayer():IsSuperAdmin() then return end
    if IsValid(Frame) then Frame:Close() end

    net.Start("WarsesAdmin_GetSpawns")
    net.SendToServer()

    local W, H = 640, 600
    Frame = vgui.Create("DFrame")
    Frame:SetSize(W, H)
    Frame:Center()
    Frame:SetTitle("")
    Frame:ShowCloseButton(false)
    Frame:SetDraggable(true)
    Frame:MakePopup()
    Frame:SetKeyboardInputEnabled(true)

    Frame.anim = 0
    Frame.Paint = function(s, w, h)
        s.anim = math.Approach(s.anim, 1, FrameTime() * 5)
        local a = s.anim

        DermaDrawShadow = nil
        surface.SetDrawColor(8, 10, 14, 240 * a)
        surface.DrawRect(0, 0, w, h)

        surface.SetDrawColor(18, 22, 32, 255 * a)
        surface.DrawRect(0, 0, w, 44)
        surface.SetDrawColor(190, 35, 40, 235 * a)
        surface.DrawRect(0, 44, w, 2)

        draw.SimpleText("WARSES · АДМИН-МЕНЮ", "Warses_AM_Title",
            16, 22, Color(255, 170, 160, 255 * a),
            TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        local conflict = GAMEMODE.Conflicts[GAMEMODE.CurrentConflict]
        if conflict then
            local sub = conflict.subconflicts[GAMEMODE.CurrentSubconflict]
            if sub then
                draw.SimpleText(conflict.name .. " · " .. sub.name,
                    "Warses_AM_Sub", w - 16, 22,
                    Color(180, 200, 230, 230 * a),
                    TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
            end
        end
    end

    local close = vgui.Create("DButton", Frame)
    close:SetText("")
    close:SetPos(W - 36, 8)
    close:SetSize(28, 28)
    close.Paint = function(s, w, h)
        surface.SetDrawColor(s:IsHovered() and 200 or 50, 40, 40, 240)
        surface.DrawRect(0, 0, w, h)
        draw.SimpleText("✕", "Warses_AM_Btn", w / 2, h / 2,
            Color(240, 240, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    close.DoClick = function() Frame:Close() end

    local leftPanel = vgui.Create("DScrollPanel", Frame)
    leftPanel:SetPos(12, 56)
    leftPanel:SetSize(220, H - 130)
    leftPanel.Paint = function(s, w, h)
        surface.SetDrawColor(14, 18, 26, 220)
        surface.DrawRect(0, 0, w, h)
    end
    local lbar = leftPanel:GetVBar()
    lbar:SetWide(4)
    lbar.Paint = function() end
    lbar.btnUp.Paint = function() end
    lbar.btnDown.Paint = function() end
    lbar.btnGrip.Paint = function(s, w, h)
        surface.SetDrawColor(120, 130, 150, 200)
        surface.DrawRect(0, 0, w, h)
    end

    local rightPanel = vgui.Create("DPanel", Frame)
    rightPanel:SetPos(244, 56)
    rightPanel:SetSize(W - 256, H - 130)
    rightPanel.Paint = function(s, w, h)
        surface.SetDrawColor(14, 18, 26, 220)
        surface.DrawRect(0, 0, w, h)
        draw.SimpleText("ПАРАМЕТРЫ", "Warses_AM_Sub", 10, 6,
            Color(255, 170, 160), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        surface.SetDrawColor(70, 80, 100, 180)
        surface.DrawRect(10, 28, w - 20, 1)
    end

    local formHost = vgui.Create("DPanel", rightPanel)
    formHost:SetPos(0, 36)
    formHost:SetSize(rightPanel:GetWide(), rightPanel:GetTall() - 40)
    formHost.Paint = function() end

    local function selectMode(id)
        WarsesAdminTool.mode = id
        BuildForm(formHost, id)
    end

    for _, m in ipairs(Modes) do
        local item = vgui.Create("DButton", leftPanel)
        item:SetText("")
        item:Dock(TOP)
        item:DockMargin(4, 4, 4, 0)
        item:SetTall(54)

        item.anim = 0
        item.Paint = function(s, w, h)
            local sel = (WarsesAdminTool.mode == m.id)
            s.anim = Lerp(FrameTime() * 10, s.anim, (sel or s:IsHovered()) and 1 or 0)
            local r = math.Round(Lerp(s.anim, 24, sel and 60 or 38))
            local g = math.Round(Lerp(s.anim, 28, sel and 80 or 44))
            local b = math.Round(Lerp(s.anim, 38, sel and 120 or 60))
            surface.SetDrawColor(r, g, b, 240)
            surface.DrawRect(0, 0, w, h)

            if sel then
                surface.SetDrawColor(200, 45, 50, 240)
                surface.DrawRect(0, 0, 3, h)
            end

            draw.SimpleText(m.name, "Warses_AM_Mode", 10, 10,
                Color(235, 240, 250), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            draw.SimpleText(m.desc, "Warses_AM_Small", 10, 30,
                Color(160, 175, 195), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        end
        item.DoClick = function()
            selectMode(m.id)
            surface.PlaySound("ui/buttonclick.wav")
        end
    end

    selectMode(WarsesAdminTool.mode or "point")

    local bottom = vgui.Create("DPanel", Frame)
    bottom:SetPos(12, H - 66)
    bottom:SetSize(W - 24, 54)
    bottom.Paint = function(s, w, h)
        surface.SetDrawColor(14, 18, 26, 220)
        surface.DrawRect(0, 0, w, h)
    end

    local bx = 8
    local function bbtn(text, w, accent, click)
        local b = MakeButton(bottom, text, accent, click)
        b:SetPos(bx, 6)
        b:SetSize(w, 42)
        bx = bx + w + 6
        return b
    end

    bbtn("ПОСТАВИТЬ ЗДЕСЬ", 150, Color(120, 200, 120), function()
        local tr = LocalPlayer():GetEyeTrace()
        local ang = LocalPlayer():EyeAngles()
        ang.p, ang.r = 0, 0
        net.Start("WarsesAdmin_Place")
        net.WriteString(WarsesAdminTool.mode)
        net.WriteVector(LocalPlayer():GetPos())
        net.WriteAngle(ang)
        net.WriteTable(WarsesAdminTool.params)
        net.WriteEntity(NULL)
        net.SendToServer()
        surface.PlaySound("buttons/button14.wav")
    end)

    bbtn("СОХРАНИТЬ", 100, Color(200, 45, 50), function()
        net.Start("WarsesAdmin_Save"); net.SendToServer()
    end)

    bbtn("ЗАГРУЗИТЬ", 100, Color(120, 170, 240), function()
        net.Start("WarsesAdmin_Load"); net.SendToServer()
    end)

    bbtn("ОЧИСТИТЬ", 100, Color(220, 80, 80), function()
        Derma_Query("Полностью очистить конфиг карты?", "Warses",
            "Да, очистить", function()
                net.Start("WarsesAdmin_Clear"); net.SendToServer()
            end,
            "Отмена", function() end)
    end)

    bbtn("АТАК. КОМАНДА", 130, Color(180, 130, 220), function()
        local menu = DermaMenu()
        menu:AddOption("Alpha — атакующие", function()
            net.Start("WarsesAdmin_SetAttackTeam"); net.WriteInt(TEAM_ALPHA, 8); net.SendToServer()
        end)
        menu:AddOption("Bravo — атакующие", function()
            net.Start("WarsesAdmin_SetAttackTeam"); net.WriteInt(TEAM_BRAVO, 8); net.SendToServer()
        end)
        menu:Open()
    end)

    local toggle = vgui.Create("DButton", Frame)
    toggle:SetText("")
    toggle:SetPos(W - 200, H - 96)
    toggle:SetSize(186, 24)
    toggle.Paint = function(s, w, h)
        local on = GetConVar("warses_show_spawn"):GetBool()
        surface.SetDrawColor(on and 60 or 22, on and 120 or 28, on and 60 or 36, 240)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(on and 120 or 80, on and 220 or 100, on and 120 or 120, 220)
        surface.DrawRect(0, h - 2, w, 2)
        draw.SimpleText("Показ зон/спаунов: " .. (on and "ВКЛ" or "ВЫКЛ"),
            "Warses_AM_Small", w / 2, h / 2,
            Color(235, 240, 250), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    toggle.DoClick = function()
        local cur = GetConVar("warses_show_spawn"):GetBool()
        RunConsoleCommand("warses_show_spawn", cur and "0" or "1")
        if not cur then
            net.Start("WarsesAdmin_GetSpawns"); net.SendToServer()
        end
        surface.PlaySound("ui/buttonclick.wav")
    end
end

concommand.Add("warses_menu", function()
    if not LocalPlayer():IsSuperAdmin() then
        chat.AddText(Color(255, 80, 80), "[Warses] Только супер-админ.")
        return
    end
    OpenWarsesAdminMenu()
end)

net.Receive("WarsesAdmin_OpenMenu", function()
    OpenWarsesAdminMenu()
end)

local spawnTypeNames = {
    [0] = "SPAWN",
    [1] = "OP-ATTACK",
    [2] = "OP-SECTOR",
    [3] = "OP-ATK-SEC",
}

hook.Add("PostDrawTranslucentRenderables", "Warses_DrawAdminSpawns", function()
    if not LocalPlayer():IsSuperAdmin() then return end
    if not GetConVar("warses_show_spawn"):GetBool() then return end
    if not WarsesAdminSpawns then return end

    render.SetColorMaterial()

    for _, s in ipairs(WarsesAdminSpawns) do
        local pos = Vector(s.x, s.y, s.z)
        local col = teamColor(s.team or 0)
        if s.type == 1 then col = Color(255, 180, 60)
        elseif s.type == 2 then col = Color(120, 220, 180)
        elseif s.type == 3 then col = Color(255, 120, 180) end

        render.DrawSphere(pos + Vector(0, 0, 8), 9, 12, 12,
            Color(col.r, col.g, col.b, 220))
        render.DrawSphere(pos + Vector(0, 0, 8), 11, 12, 12,
            Color(col.r, col.g, col.b, 60))
    end

    cam.IgnoreZ(true)
    for _, s in ipairs(WarsesAdminSpawns) do
        local pos = Vector(s.x, s.y, s.z) + Vector(0, 0, 50)
        local ang = Angle(0, LocalPlayer():EyeAngles().y - 90, 90)
        local col = teamColor(s.team or 0)
        if s.type == 1 then col = Color(255, 180, 60)
        elseif s.type == 2 then col = Color(120, 220, 180)
        elseif s.type == 3 then col = Color(255, 120, 180) end

        local txt = spawnTypeNames[s.type or 0] or "?"
        if (s.team or 0) > 0 then txt = txt .. " · " .. teamName(s.team) end
        if (s.sector or 0) > 0 then txt = txt .. " · S" .. s.sector end

        cam.Start3D2D(pos, ang, 0.08)
            draw.SimpleText(txt, "Warses_AM_Mode", 0, 0,
                Color(col.r, col.g, col.b, 255),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        cam.End3D2D()
    end
    cam.IgnoreZ(false)
end)

local function Warses_IsHoldingAdmintool()
    local ply = LocalPlayer()
    if not IsValid(ply) then return false end
    local wep = ply:GetActiveWeapon()
    return IsValid(wep) and wep:GetClass() == "warses_admintool"
end

hook.Add("PostDrawTranslucentRenderables", "Warses_DrawGravityZonePreview", function()
    if not LocalPlayer():IsSuperAdmin() then return end
    if not Warses_IsHoldingAdmintool() then return end
    if not WarsesAdminTool or WarsesAdminTool.mode ~= "gravity_zone" then return end

    local p1 = WarsesAdminTool.gravityFirstPoint
    if not p1 then return end

    local tr = LocalPlayer():GetEyeTrace()
    local p2 = tr.HitPos

    local minV = Vector(math.min(p1.x, p2.x), math.min(p1.y, p2.y), math.min(p1.z, p2.z))
    local maxV = Vector(math.max(p1.x, p2.x), math.max(p1.y, p2.y), math.max(p1.z, p2.z))

    render.SetColorMaterial()

    render.DrawBox(Vector(0, 0, 0), Angle(0, 0, 0), minV, maxV,
        Color(80, 220, 120, 50))

    render.DrawWireframeBox(Vector(0, 0, 0), Angle(0, 0, 0), minV, maxV,
        Color(120, 240, 140, 240), true)

    render.DrawSphere(p1, 8, 16, 16, Color(120, 240, 140, 230))
end)

hook.Add("HUDPaint", "Warses_GravityZoneHUD", function()
    if not LocalPlayer():IsSuperAdmin() then return end
    if not Warses_IsHoldingAdmintool() then return end
    if not WarsesAdminTool or WarsesAdminTool.mode ~= "gravity_zone" then return end

    local sw, sh = ScrW(), ScrH()
    local boxW, boxH = 420, 56
    local x = (sw - boxW) / 2
    local y = sh - boxH - 80

    local hasP1 = WarsesAdminTool.gravityFirstPoint ~= nil

    surface.SetDrawColor(0, 0, 0, 200)
    surface.DrawRect(x, y, boxW, boxH)

    local edge = hasP1 and Color(120, 230, 140, 240) or Color(120, 170, 240, 220)
    surface.SetDrawColor(edge)
    surface.DrawRect(x, y + boxH - 2, boxW, 2)

    local title = hasP1
        and "ЗОНА ГРАВИТАЦИИ · ЛКМ — отметить вторую точку"
        or  "ЗОНА ГРАВИТАЦИИ · ЛКМ — отметить первую точку"
    draw.SimpleText(title, "Warses_AM_Btn",
        x + boxW / 2, y + 14,
        Color(235, 240, 250), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

    local sub = hasP1
        and "R — сбросить выбор"
        or  "ПКМ — открыть админ-меню"
    draw.SimpleText(sub, "Warses_AM_Small",
        x + boxW / 2, y + 36,
        Color(180, 200, 220), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)
