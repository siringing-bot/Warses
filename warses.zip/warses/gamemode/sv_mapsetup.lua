GM.MapConfig = {
    spawns = {
        [TEAM_ALPHA] = {},
        [TEAM_BRAVO] = {}
    },
    points = {},
    bases = {},
    vehicles = {},
    gravity_zones = {},
    operation_attack_team = TEAM_ALPHA,
    operation_attack_spawns = {},
    operation_sector_spawns = {},
    operation_attack_sector_spawns = {}
}

local DATA_DIR = "warses/maps/"

if not file.Exists("warses", "DATA") then file.CreateDir("warses") end
if not file.Exists(DATA_DIR, "DATA") then file.CreateDir(DATA_DIR) end

function GM:SaveMapConfig()
    local map = string.lower(game.GetMap())

    local saveData = {
        spawns = {},
        points = {},
        bases = {},
        vehicles = {},
        gravity_zones = {},
        operation_attack_team = self.MapConfig.operation_attack_team or TEAM_ALPHA,
        operation_attack_spawns = {},
        operation_sector_spawns = {},
        operation_attack_sector_spawns = {}
    }

    if self.MapConfig.spawns then
        for teamID, positions in pairs(self.MapConfig.spawns) do
            saveData.spawns[teamID] = {}
            for _, pos in ipairs(positions) do
                local x, y, z
                if type(pos) == "Vector" then
                    x, y, z = pos.x, pos.y, pos.z
                elseif type(pos) == "table" then
                     x, y, z = pos.x, pos.y, pos.z
                end

                if x then
                    table.insert(saveData.spawns[teamID], {x=x, y=y, z=z})
                end
            end
        end
    end

    for _, ent in ipairs(ents.FindByClass("warses_capturepoint")) do
        local sector = ent.GetSector and ent:GetSector() or 0
        table.insert(saveData.points, {
            pos = {
                x = ent:GetPos().x,
                y = ent:GetPos().y,
                z = ent:GetPos().z
            },
            name = ent:GetPointName(),
            zoneType = ent:GetZoneType(),
            zoneHeight = ent:GetZoneHeight(),
            zoneLength = ent:GetZoneLength(),
            zoneWidth = ent:GetZoneWidth(),
            sector = sector > 0 and sector or nil,
        })
    end

    for _, ent in ipairs(ents.FindByClass("warses_base")) do
        table.insert(saveData.bases, {
            pos = {
                x = ent:GetPos().x,
                y = ent:GetPos().y,
                z = ent:GetPos().z
            },
            owningTeam = ent:GetOwningTeam(),
            zoneType = ent:GetZoneType(),
            zoneHeight = ent:GetZoneHeight(),
            zoneLength = ent:GetZoneLength(),
            zoneWidth = ent:GetZoneWidth()
        })
    end

    for _, ent in ipairs(ents.FindByClass("warses_gravity_zone")) do
        table.insert(saveData.gravity_zones, {
            pos = {
                x = ent:GetPos().x,
                y = ent:GetPos().y,
                z = ent:GetPos().z
            },
            zoneType = ent:GetZoneType(),
            zoneHeight = ent:GetZoneHeight(),
            zoneLength = ent:GetZoneLength(),
            zoneWidth = ent:GetZoneWidth()
        })
    end

    if self.MapConfig.operation_attack_spawns then
        for _, pos in pairs(self.MapConfig.operation_attack_spawns) do
            local x, y, z
            if type(pos) == "Vector" then x, y, z = pos.x, pos.y, pos.z
            elseif type(pos) == "table" then x, y, z = pos.x, pos.y, pos.z end
            if x then table.insert(saveData.operation_attack_spawns, {x=x, y=y, z=z}) end
        end
    end

    if self.MapConfig.operation_sector_spawns then
        for sec, positions in pairs(self.MapConfig.operation_sector_spawns) do
            local strStr = tostring(sec)
            saveData.operation_sector_spawns[strStr] = {}
            for _, pos in pairs(positions) do
                local x, y, z
                if type(pos) == "Vector" then x, y, z = pos.x, pos.y, pos.z
                elseif type(pos) == "table" then x, y, z = pos.x, pos.y, pos.z end
                if x then table.insert(saveData.operation_sector_spawns[strStr], {x=x, y=y, z=z}) end
            end
        end
    end

    if self.MapConfig.operation_attack_sector_spawns then
        for sec, positions in pairs(self.MapConfig.operation_attack_sector_spawns) do
            local strStr = tostring(sec)
            saveData.operation_attack_sector_spawns[strStr] = {}
            for _, pos in pairs(positions) do
                local x, y, z
                if type(pos) == "Vector" then x, y, z = pos.x, pos.y, pos.z
                elseif type(pos) == "table" then x, y, z = pos.x, pos.y, pos.z end
                if x then table.insert(saveData.operation_attack_sector_spawns[strStr], {x=x, y=y, z=z}) end
            end
        end
    end

    for _, ent in ipairs(ents.FindByClass("warses_vehicle_spawn")) do
         local cv = ent:GetVehicleSpawnColor() or Vector(1, 1, 1)
         table.insert(saveData.vehicles, {
             pos = {
                 x = ent:GetPos().x,
                 y = ent:GetPos().y,
                 z = ent:GetPos().z
             },
             ang = {
                 p = ent:GetAngles().p,
                 y = ent:GetAngles().y,
                 r = ent:GetAngles().r
             },
             class = ent:GetVehicleClass(),
             respawnTime = ent:GetRespawnTime(),
             color = {
                 r = math.floor(cv.x * 255),
                 g = math.floor(cv.y * 255),
                 b = math.floor(cv.z * 255)
             }
         })
    end

    local data = util.TableToJSON(saveData, true)
    file.Write(DATA_DIR .. map .. ".json", data)
    print("[Warses] Map configuration saved for " .. map)
end

function GM:LoadMapConfig()
    local map = string.lower(game.GetMap())
    local path = DATA_DIR .. map .. ".json"

    if file.Exists(path, "DATA") then
        local content = file.Read(path, "DATA")
        local data = util.JSONToTable(content)

        if data then
            self.MapConfig = data
            self.MapConfig.spawns = self.MapConfig.spawns or {}
            self.MapConfig.spawns[TEAM_ALPHA] = self.MapConfig.spawns[TEAM_ALPHA] or {}
            self.MapConfig.spawns[TEAM_BRAVO] = self.MapConfig.spawns[TEAM_BRAVO] or {}

            for teamID, spawns in pairs(self.MapConfig.spawns) do
                for k, v in ipairs(spawns) do
                    if type(v) == "table" then
                        spawns[k] = Vector(v.x, v.y, v.z)
                    end
                end
            end
            self.MapConfig.points = self.MapConfig.points or {}
            self.MapConfig.bases = self.MapConfig.bases or {}
            self.MapConfig.vehicles = self.MapConfig.vehicles or {}
            self.MapConfig.gravity_zones = self.MapConfig.gravity_zones or {}

            self.MapConfig.operation_attack_team = data.operation_attack_team or TEAM_ALPHA

            local oldAttSpawns = data.operation_attack_spawns
            self.MapConfig.operation_attack_spawns = {}
            if oldAttSpawns then
                for k, v in pairs(oldAttSpawns) do
                    if type(v) == "table" then table.insert(self.MapConfig.operation_attack_spawns, Vector(v.x, v.y, v.z)) end
                end
            end

            local oldSecSpawns = data.operation_sector_spawns
            self.MapConfig.operation_sector_spawns = {}
            if oldSecSpawns then
                for secStr, spawns in pairs(oldSecSpawns) do
                    local secNum = tonumber(secStr) or secStr
                    self.MapConfig.operation_sector_spawns[secNum] = {}
                    for k, v in pairs(spawns) do
                        if type(v) == "table" then table.insert(self.MapConfig.operation_sector_spawns[secNum], Vector(v.x, v.y, v.z)) end
                    end
                end
            end

            local oldAttSecSpawns = data.operation_attack_sector_spawns
            self.MapConfig.operation_attack_sector_spawns = {}
            if oldAttSecSpawns then
                for secStr, spawns in pairs(oldAttSecSpawns) do
                    local secNum = tonumber(secStr) or secStr
                    self.MapConfig.operation_attack_sector_spawns[secNum] = {}
                    for k, v in pairs(spawns) do
                        if type(v) == "table" then table.insert(self.MapConfig.operation_attack_sector_spawns[secNum], Vector(v.x, v.y, v.z)) end
                    end
                end
            end

            print("[Warses] Loaded map configuration for " .. map)

            self:SpawnCapturePoints()
            self:SpawnBaseProtection()
            self:SpawnVehicleSpawners()
            self:SpawnGravityZones()
        end
    else
        print("[Warses] No map configuration found for " .. map)
    end
end

function GM:SpawnGravityZones()
    for _, ent in ipairs(ents.FindByClass("warses_gravity_zone")) do
        ent:Remove()
    end

    if not self.MapConfig.gravity_zones then return end

    for _, zoneData in ipairs(self.MapConfig.gravity_zones) do
        local ent = ents.Create("warses_gravity_zone")
        if IsValid(ent) then
            local pos = zoneData.pos
            if type(pos) == "table" and pos.x then pos = Vector(pos.x, pos.y, pos.z) end

            ent:SetPos(pos)
            ent:Spawn()

            if zoneData.zoneType   then ent:SetZoneType(zoneData.zoneType) end
            if zoneData.zoneHeight then ent:SetZoneHeight(zoneData.zoneHeight) end
            if zoneData.zoneLength then ent:SetZoneLength(zoneData.zoneLength) end
            if zoneData.zoneWidth  then ent:SetZoneWidth(zoneData.zoneWidth) end
        end
    end
    print("[Warses] Spawning " .. #self.MapConfig.gravity_zones .. " gravity zones")
end

function GM:SpawnCapturePoints()
    for _, ent in ipairs(ents.FindByClass("warses_capturepoint")) do
        ent:Remove()
    end

    if GAMEMODE.CurrentGameMode == "deathmatch" then
        print("[Warses] DeathMatch: точки захвата пропущены")
        return
    end

    for _, pointData in ipairs(self.MapConfig.points) do
        local isOpPoint = pointData.sector and tonumber(pointData.sector) > 0

        if GAMEMODE.CurrentGameMode == "operation" and not isOpPoint then continue end
        if GAMEMODE.CurrentGameMode ~= "operation" and isOpPoint then continue end

        local ent = ents.Create("warses_capturepoint")
        local pos = pointData.pos
        if type(pos) == "table" and pos.x and pos.y and pos.z then
            pos = Vector(pos.x, pos.y, pos.z)
        elseif type(pos) == "string" then
            pos = Vector(pos)
        end
        ent:SetPos(pos)
        ent:Spawn()
        ent:SetPointName(pointData.name or "Control Point")

        if pointData.zoneType then ent:SetZoneType(pointData.zoneType) end
        if pointData.zoneHeight then ent:SetZoneHeight(pointData.zoneHeight) end
        if pointData.zoneLength then ent:SetZoneLength(pointData.zoneLength) end
        if pointData.zoneWidth then ent:SetZoneWidth(pointData.zoneWidth) end
        if pointData.sector and ent.SetSector then ent:SetSector(pointData.sector) end

        ent:DropToFloor()
    end
    print("[Warses] Spawning " .. #self.MapConfig.points .. " capture points")
end

function GM:SpawnBaseProtection()
    for _, ent in ipairs(ents.FindByClass("warses_base")) do
        ent:Remove()
    end

    if not self.MapConfig.bases then return end

    for _, baseData in ipairs(self.MapConfig.bases) do
        local ent = ents.Create("warses_base")
        local pos = baseData.pos
        if type(pos) == "table" and pos.x then pos = Vector(pos.x, pos.y, pos.z) end

        ent:SetPos(pos)
        ent:Spawn()

        ent:SetOwningTeam(baseData.owningTeam or 0)

        if baseData.zoneType then ent:SetZoneType(baseData.zoneType) end
        if baseData.zoneHeight then ent:SetZoneHeight(baseData.zoneHeight) end
        if baseData.zoneLength then ent:SetZoneLength(baseData.zoneLength) end
        if baseData.zoneWidth then ent:SetZoneWidth(baseData.zoneWidth) end
    end
    print("[Warses] Spawning " .. #self.MapConfig.bases .. " base protection zones")
end

function GM:SpawnVehicleSpawners()
    for _, ent in ipairs(ents.FindByClass("warses_vehicle_spawn")) do
        ent:Remove()
    end

    if not self.MapConfig.vehicles then return end

    for _, vehData in ipairs(self.MapConfig.vehicles) do
        local ent = ents.Create("warses_vehicle_spawn")

        local pos = vehData.pos
        if type(pos) == "table" and pos.x then pos = Vector(pos.x, pos.y, pos.z) end

        local ang = vehData.ang
        if type(ang) == "table" and ang.p then ang = Angle(ang.p, ang.y, ang.r) end

        ent:SetPos(pos)
        ent:SetAngles(ang or Angle(0,0,0))
        ent:Spawn()

        ent:SetVehicleClass(vehData.class or "jeep")
        ent:SetRespawnTime(vehData.respawnTime or 30)

        local c = vehData.color
        if c and (c.r or c.g or c.b) then
            local r = math.Clamp(tonumber(c.r) or 255, 0, 255)
            local g = math.Clamp(tonumber(c.g) or 255, 0, 255)
            local b = math.Clamp(tonumber(c.b) or 255, 0, 255)
            ent:SetColor(Color(r, g, b))
            ent:SetVehicleSpawnColor(Vector(r / 255, g / 255, b / 255))
        else
            ent:SetVehicleSpawnColor(Vector(1, 1, 1))
        end
        if ent.RespawnNow then ent:RespawnNow() end

        local phys = ent:GetPhysicsObject()
        if IsValid(phys) then phys:EnableMotion(false) end
    end
    print("[Warses] Spawning " .. #self.MapConfig.vehicles .. " vehicle spawners")
end

concommand.Add("warses_addspawn", function(ply, cmd, args)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end

    local teamName = args[1]
    local teamID = nil

    if string.lower(teamName) == "alpha" or string.lower(teamName) == "us" or string.lower(teamName) == "1" then
        teamID = TEAM_ALPHA
    elseif string.lower(teamName) == "bravo" or string.lower(teamName) == "opfor" or string.lower(teamName) == "2" then
        teamID = TEAM_BRAVO
    end

    if not teamID then
        ply:ChatPrint("Usage: warses_addspawn <alpha/bravo>")
        return
    end

    table.insert(GAMEMODE.MapConfig.spawns[teamID], ply:GetPos())
    ply:ChatPrint("Added spawn point for " .. team.GetName(teamID))
end)

concommand.Add("warses_set_base", function(ply, cmd, args)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end

    local teamName = args[1]
    local teamID = nil

    if string.lower(teamName or "") == "alpha" then teamID = TEAM_ALPHA
    elseif string.lower(teamName or "") == "bravo" then teamID = TEAM_BRAVO end

    if not teamID then
        ply:ChatPrint("Usage: warses_set_base <alpha/bravo>")
        return
    end

    local ent = ents.Create("warses_base")
    ent:SetPos(ply:GetPos())
    ent:SetOwningTeam(teamID)
    ent:Spawn()

    ply:ChatPrint("Base zone created for " .. team.GetName(teamID) .. ". Configure it using zone commands.")
end)

concommand.Add("warses_addpoint", function(ply, cmd, args)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end

    local name = table.concat(args, " ")
    if name == "" then name = "Control Point" end

    table.insert(GAMEMODE.MapConfig.points, {
        pos = ply:GetPos(),
        name = name
    })

    local ent = ents.Create("warses_capturepoint")
    ent:SetPos(ply:GetPos())
    ent:Spawn()
    ent:SetPointName(name)
    ent:DropToFloor()

    ply:ChatPrint("Added capture point: " .. name)
end)

concommand.Add("warses_atackteam", function(ply, cmd, args)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end

    local teamName = args[1]
    local teamID = nil

    if string.lower(teamName or "") == "alpha" then
        teamID = TEAM_ALPHA
    elseif string.lower(teamName or "") == "bravo" then
        teamID = TEAM_BRAVO
    end

    if not teamID then
        ply:ChatPrint("Usage: warses_atackteam <alpha/bravo>")
        return
    end

    GAMEMODE.MapConfig.operation_attack_team = teamID
    ply:ChatPrint("Команда атаки для режима Операция установлена на: " .. team.GetName(teamID))
end)

concommand.Add("warses_spawn_sek", function(ply, cmd, args)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end

    local sector = tonumber(args[1])
    if not sector then
        ply:ChatPrint("Usage: warses_spawn_sek <sector_number>")
        return
    end

    GAMEMODE.MapConfig.operation_sector_spawns = GAMEMODE.MapConfig.operation_sector_spawns or {}
    GAMEMODE.MapConfig.operation_sector_spawns[sector] = GAMEMODE.MapConfig.operation_sector_spawns[sector] or {}

    table.insert(GAMEMODE.MapConfig.operation_sector_spawns[sector], ply:GetPos())
    ply:ChatPrint("Added sector spawn for Sector " .. sector)
end)

concommand.Add("warses_spawnsek_atack", function(ply, cmd, args)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end

    local sector = tonumber(args[1])
    if not sector then
        ply:ChatPrint("Usage: warses_spawnsek_atack <sector_number>")
        return
    end

    GAMEMODE.MapConfig.operation_attack_sector_spawns = GAMEMODE.MapConfig.operation_attack_sector_spawns or {}
    GAMEMODE.MapConfig.operation_attack_sector_spawns[sector] = GAMEMODE.MapConfig.operation_attack_sector_spawns[sector] or {}

    table.insert(GAMEMODE.MapConfig.operation_attack_sector_spawns[sector], ply:GetPos())
    ply:ChatPrint("Added ATTACK sector spawn for Sector " .. sector)
end)

concommand.Add("warses_spawn_atak", function(ply, cmd, args)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end

    GAMEMODE.MapConfig.operation_attack_spawns = GAMEMODE.MapConfig.operation_attack_spawns or {}
    table.insert(GAMEMODE.MapConfig.operation_attack_spawns, ply:GetPos())
    ply:ChatPrint("Added initial attach spawn point for Operation mode.")
end)

concommand.Add("warses_createpointsek", function(ply, cmd, args)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end

    local sector = tonumber(args[#args])
    if not sector then
        ply:ChatPrint("Usage: warses_createpointsek <Point Name> <sector_number>")
        return
    end

    local nameArgs = {}
    for i=1, #args-1 do table.insert(nameArgs, args[i]) end
    local name = table.concat(nameArgs, " ")
    if name == "" then name = "Sector Capture Point" end

    table.insert(GAMEMODE.MapConfig.points, {
        pos = ply:GetPos(),
        name = name,
        sector = sector
    })

    local ent = ents.Create("warses_capturepoint")
    ent:SetPos(ply:GetPos())
    ent:Spawn()
    ent:SetPointName(name)
    if ent.SetSector then ent:SetSector(sector) end
    ent:DropToFloor()

    ply:ChatPrint("Added capture point: '" .. name .. "' for Sector " .. sector)
end)

concommand.Add("warses_removepoint", function(ply, cmd, args)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end

    local tr = ply:GetEyeTrace()
    if IsValid(tr.Entity) and tr.Entity:GetClass() == "warses_capturepoint" then
        local name = tr.Entity:GetPointName()
        tr.Entity:Remove()
        ply:ChatPrint("Removed capture point: " .. name)
    elseif IsValid(tr.Entity) and tr.Entity:GetClass() == "warses_base" then
        tr.Entity:Remove()
        ply:ChatPrint("Removed base protection zone.")
    else
        ply:ChatPrint("You must be looking at a capture point or base zone to remove it!")
    end
end)

concommand.Add("warses_save", function(ply, cmd, args)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end
    GAMEMODE:SaveMapConfig()
    ply:ChatPrint("Map configuration saved!")
end)

concommand.Add("warses_clear_config", function(ply, cmd, args)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end

    GAMEMODE.MapConfig = {
        spawns = {
            [TEAM_ALPHA] = {},
            [TEAM_BRAVO] = {}
        },
        points = {},
        bases = {},
        vehicles = {},
        gravity_zones = {},
        operation_attack_team = TEAM_ALPHA,
        operation_attack_spawns = {},
        operation_sector_spawns = {},
        operation_attack_sector_spawns = {}
    }

    for _, ent in ipairs(ents.FindByClass("warses_capturepoint")) do
        ent:Remove()
    end
    for _, ent in ipairs(ents.FindByClass("warses_base")) do
        ent:Remove()
    end
    for _, ent in ipairs(ents.FindByClass("warses_vehicle_spawn")) do
        ent:Remove()
    end
    for _, ent in ipairs(ents.FindByClass("warses_gravity_zone")) do
        ent:Remove()
    end

    ply:ChatPrint("Map configuration cleared (not saved on disk yet)!")
end)

concommand.Add("warses_set_zone_type", function(ply, cmd, args)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end

    local tr = ply:GetEyeTrace()
    local ent = tr.Entity

    if not IsValid(ent) or (ent:GetClass() ~= "warses_capturepoint" and ent:GetClass() ~= "warses_base") then
        ply:ChatPrint("You must be looking at a capture point or base zone!")
        return
    end

    local type = tonumber(args[1])
    if not type or type < 0 or type > 2 then
        ply:ChatPrint("Usage: warses_set_zone_type <0=Sphere, 1=Box, 2=Cylinder>")
        return
    end

    ent:SetZoneType(type)

    local typeNames = { [0] = "Sphere", [1] = "Box", [2] = "Cylinder" }
    ply:ChatPrint("Set zone type to: " .. typeNames[type])
end)

concommand.Add("warses_set_zone_size", function(ply, cmd, args)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end

    local tr = ply:GetEyeTrace()
    local ent = tr.Entity

    if not IsValid(ent) or (ent:GetClass() ~= "warses_capturepoint" and ent:GetClass() ~= "warses_base") then
        ply:ChatPrint("You must be looking at a capture point or base zone!")
        return
    end

    local length = tonumber(args[1])
    local width = tonumber(args[2])
    local height = tonumber(args[3])

    if not length then
        ply:ChatPrint("Usage: warses_set_zone_size <length> [width] [height]")
        return
    end

    width = width or length
    height = height or length

    ent:SetZoneLength(length)
    ent:SetZoneWidth(width)
    ent:SetZoneHeight(height)

    ply:ChatPrint("Set zone size to: " .. length .. " x " .. width .. " x " .. height)
end)

concommand.Add("warses_vehicle_spawn", function(ply, cmd, args)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end

    local class = args[1]
    local respawnTime = tonumber(args[2]) or 30
    local r = math.Clamp(tonumber(args[3]) or 255, 0, 255)
    local g = math.Clamp(tonumber(args[4]) or 255, 0, 255)
    local b = math.Clamp(tonumber(args[5]) or 255, 0, 255)

    if not class then
        ply:ChatPrint("Usage: warses_vehicle_spawn <class> [respawn] [r] [g] [b]")
        return
    end

    local ent = ents.Create("warses_vehicle_spawn")
    ent:SetPos(ply:GetPos())
    ent:SetAngles(ply:GetAngles())
    ent:Spawn()
    ent:SetVehicleClass(class)
    ent:SetRespawnTime(respawnTime)
    ent:SetColor(Color(r, g, b))
    ent:SetVehicleSpawnColor(Vector(r / 255, g / 255, b / 255))
    if ent.RespawnNow then ent:RespawnNow() end

    ply:ChatPrint(string.format(
        "Added vehicle spawner: %s (Respawn: %ds, Color: %d,%d,%d)",
        class, respawnTime, r, g, b))
end)
