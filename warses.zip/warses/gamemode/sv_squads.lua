SQUAD_SUPPRESS_DOT   = 0.985
SQUAD_SUPPRESS_RANGE = 6000
SQUAD_SPAWN_SAFE_R   = 250

util.AddNetworkString("Warses_SquadSync")
util.AddNetworkString("Warses_SquadAction")
util.AddNetworkString("Warses_SquadNotify")

GAMEMODE = GAMEMODE or GM
GAMEMODE.Squads        = GAMEMODE.Squads        or { [TEAM_ALPHA] = {}, [TEAM_BRAVO] = {} }
GAMEMODE.SquadNextID   = GAMEMODE.SquadNextID   or { [TEAM_ALPHA] = 1,  [TEAM_BRAVO] = 1  }

local function SanitizeName(name)
    name = tostring(name or "")
    name = string.Trim(name)
    name = string.gsub(name, "[%c]", "")
    if #name > SQUAD_MAX_NAME_LEN then
        name = string.sub(name, 1, SQUAD_MAX_NAME_LEN)
    end
    return name
end

local function Notify(ply, text, level)
    if not IsValid(ply) then return end
    net.Start("Warses_SquadNotify")
    net.WriteString(text or "")
    net.WriteUInt(level or 0, 4)
    net.Send(ply)
end

local function GetTeamSquads(teamID)
    if teamID ~= TEAM_ALPHA and teamID ~= TEAM_BRAVO then return nil end
    GAMEMODE.Squads[teamID] = GAMEMODE.Squads[teamID] or {}
    return GAMEMODE.Squads[teamID]
end

function Warses_GetSquad(teamID, squadID)
    local list = GetTeamSquads(teamID)
    return list and list[squadID] or nil
end

function Warses_GetPlayerSquad(ply)
    if not IsValid(ply) then return nil, nil, nil end
    local teamID = ply:Team()
    local list = GetTeamSquads(teamID)
    if not list then return nil, nil, teamID end
    local sid = ply:SteamID()
    for squadID, squad in pairs(list) do
        for _, memberSID in ipairs(squad.members) do
            if memberSID == sid then
                return squad, squadID, teamID
            end
        end
    end
    return nil, nil, teamID
end

function Warses_GetSquadmates(ply, includeDead)
    local squad = Warses_GetPlayerSquad(ply)
    if not squad then return {} end
    local mySID = ply:SteamID()
    local out = {}
    for _, sid in ipairs(squad.members) do
        if sid ~= mySID then
            local p = player.GetBySteamID(sid)
            if IsValid(p) and (includeDead or p:Alive()) then
                out[#out + 1] = p
            end
        end
    end
    return out
end

local function BuildSquadPayload(teamID)
    local list = GetTeamSquads(teamID) or {}
    local arr = {}
    for squadID, squad in pairs(list) do
        arr[#arr + 1] = {
            id      = squadID,
            name    = squad.name,
            leader  = squad.leader,
            members = squad.members,
        }
    end
    return arr
end

function Warses_BroadcastSquads(teamID)
    if teamID ~= TEAM_ALPHA and teamID ~= TEAM_BRAVO then return end
    local payload = BuildSquadPayload(teamID)

    net.Start("Warses_SquadSync")
    net.WriteUInt(teamID, 4)
    net.WriteUInt(#payload, 8)
    for _, sq in ipairs(payload) do
        net.WriteUInt(sq.id, 16)
        net.WriteString(sq.name or "")
        net.WriteString(sq.leader or "")
        net.WriteUInt(#sq.members, 8)
        for _, sid in ipairs(sq.members) do
            net.WriteString(sid)
        end
    end

    local recv = {}
    for _, p in ipairs(player.GetAll()) do
        if p:Team() == teamID or p:Team() == TEAM_SPECTATOR then
            recv[#recv + 1] = p
        end
    end
    if #recv > 0 then
        net.Send(recv)
    end
end

local function SyncPlayerNWVars(ply, squad, squadID)
    if not IsValid(ply) then return end
    if squad then
        ply:SetNWInt("WarsesSquadID", squadID or 0)
        ply:SetNWBool("WarsesIsSquadLeader", squad.leader == ply:SteamID())
        ply:SetNWString("WarsesSquadName", squad.name or "")
    else
        ply:SetNWInt("WarsesSquadID", 0)
        ply:SetNWBool("WarsesIsSquadLeader", false)
        ply:SetNWString("WarsesSquadName", "")
    end
end

local function SyncSquadMembersNW(squad, squadID)
    if not squad then return end
    for _, sid in ipairs(squad.members) do
        local p = player.GetBySteamID(sid)
        if IsValid(p) then SyncPlayerNWVars(p, squad, squadID) end
    end
end

local function FindFreeSquadID(teamID)
    local list = GetTeamSquads(teamID)
    local id = GAMEMODE.SquadNextID[teamID] or 1
    while list[id] do id = id + 1 end
    GAMEMODE.SquadNextID[teamID] = id + 1
    return id
end

local function DefaultSquadName(teamID)
    local prefix = (teamID == TEAM_ALPHA) and "Alpha" or "Bravo"
    local list = GetTeamSquads(teamID) or {}
    local n = 1
    while true do
        local candidate = prefix .. "-" .. n
        local taken = false
        for _, sq in pairs(list) do
            if sq.name == candidate then taken = true; break end
        end
        if not taken then return candidate end
        n = n + 1
    end
end

function Warses_DisbandSquad(teamID, squadID)
    local list = GetTeamSquads(teamID)
    if not list or not list[squadID] then return end
    local squad = list[squadID]
    local members = table.Copy(squad.members)
    list[squadID] = nil
    for _, sid in ipairs(members) do
        local p = player.GetBySteamID(sid)
        if IsValid(p) then SyncPlayerNWVars(p, nil, 0) end
    end
    Warses_BroadcastSquads(teamID)
end

function Warses_LeaveSquad(ply, silent)
    if not IsValid(ply) then return end
    local squad, squadID, teamID = Warses_GetPlayerSquad(ply)
    if not squad then return end

    local sid = ply:SteamID()
    for i = #squad.members, 1, -1 do
        if squad.members[i] == sid then
            table.remove(squad.members, i)
        end
    end

    SyncPlayerNWVars(ply, nil, 0)

    if #squad.members == 0 then
        Warses_DisbandSquad(teamID, squadID)
        return
    end

    if squad.leader == sid then
        squad.leader = squad.members[1]
        local newLeader = player.GetBySteamID(squad.leader)
        if IsValid(newLeader) and not silent then
            Notify(newLeader, "Вы стали лидером отряда " .. squad.name, 1)
        end
    end

    SyncSquadMembersNW(squad, squadID)
    Warses_BroadcastSquads(teamID)
end

function Warses_CreateSquad(ply, requestedName)
    if not IsValid(ply) then return end
    local teamID = ply:Team()
    if teamID ~= TEAM_ALPHA and teamID ~= TEAM_BRAVO then
        Notify(ply, "Выберите команду перед созданием отряда", 3); return
    end

    local existing = Warses_GetPlayerSquad(ply)
    if existing then Warses_LeaveSquad(ply, true) end

    local name = SanitizeName(requestedName)
    if #name < SQUAD_MIN_NAME_LEN then name = DefaultSquadName(teamID) end

    local list = GetTeamSquads(teamID)
    for _, sq in pairs(list) do
        if sq.name == name then
            Notify(ply, "Отряд с таким именем уже существует", 2)
            name = DefaultSquadName(teamID)
            break
        end
    end

    local squadID = FindFreeSquadID(teamID)
    local sid = ply:SteamID()
    local squad = {
        name    = name,
        leader  = sid,
        members = { sid },
    }
    list[squadID] = squad

    SyncPlayerNWVars(ply, squad, squadID)
    Notify(ply, "Создан отряд " .. name, 1)
    Warses_BroadcastSquads(teamID)
end

function Warses_JoinSquad(ply, squadID)
    if not IsValid(ply) then return end
    local teamID = ply:Team()
    local list = GetTeamSquads(teamID)
    if not list then
        Notify(ply, "Выберите команду", 3); return
    end
    local squad = list[squadID]
    if not squad then
        Notify(ply, "Отряд не найден", 3); return
    end
    if #squad.members >= SQUAD_MAX_MEMBERS then
        Notify(ply, "Отряд переполнен (" .. SQUAD_MAX_MEMBERS .. ")", 2); return
    end

    local current, currentID = Warses_GetPlayerSquad(ply)
    if currentID == squadID then return end
    if current then Warses_LeaveSquad(ply, true) end

    table.insert(squad.members, ply:SteamID())
    SyncPlayerNWVars(ply, squad, squadID)
    Notify(ply, "Вы вступили в отряд " .. squad.name, 1)
    Warses_BroadcastSquads(teamID)
end

function Warses_KickFromSquad(leaderPly, targetSID)
    if not IsValid(leaderPly) then return end
    local squad, squadID, teamID = Warses_GetPlayerSquad(leaderPly)
    if not squad then Notify(leaderPly, "Вы не в отряде", 3); return end
    if squad.leader ~= leaderPly:SteamID() then
        Notify(leaderPly, "Только лидер может выгонять", 3); return
    end
    if targetSID == leaderPly:SteamID() then
        Notify(leaderPly, "Нельзя выгнать себя — используйте Покинуть", 2); return
    end

    local found = false
    for i = #squad.members, 1, -1 do
        if squad.members[i] == targetSID then
            table.remove(squad.members, i); found = true; break
        end
    end
    if not found then return end

    local target = player.GetBySteamID(targetSID)
    if IsValid(target) then
        SyncPlayerNWVars(target, nil, 0)
        Notify(target, "Вас выгнали из отряда " .. squad.name, 2)
    end
    Warses_BroadcastSquads(teamID)
end

function Warses_PromoteLeader(leaderPly, targetSID)
    if not IsValid(leaderPly) then return end
    local squad, squadID, teamID = Warses_GetPlayerSquad(leaderPly)
    if not squad then return end
    if squad.leader ~= leaderPly:SteamID() then
        Notify(leaderPly, "Только лидер может передавать командование", 3); return
    end
    local inSquad = false
    for _, sid in ipairs(squad.members) do
        if sid == targetSID then inSquad = true; break end
    end
    if not inSquad then return end

    squad.leader = targetSID
    SyncSquadMembersNW(squad, squadID)
    local newLeader = player.GetBySteamID(targetSID)
    if IsValid(newLeader) then
        Notify(newLeader, "Вы стали лидером отряда " .. squad.name, 1)
    end
    Notify(leaderPly, "Лидерство передано", 0)
    Warses_BroadcastSquads(teamID)
end

function Warses_RenameSquad(leaderPly, newName)
    if not IsValid(leaderPly) then return end
    local squad, squadID, teamID = Warses_GetPlayerSquad(leaderPly)
    if not squad then return end
    if squad.leader ~= leaderPly:SteamID() then
        Notify(leaderPly, "Только лидер может переименовать", 3); return
    end
    local name = SanitizeName(newName)
    if #name < SQUAD_MIN_NAME_LEN then
        Notify(leaderPly, "Слишком короткое имя", 2); return
    end
    local list = GetTeamSquads(teamID)
    for sid, sq in pairs(list) do
        if sid ~= squadID and sq.name == name then
            Notify(leaderPly, "Такое имя уже занято", 2); return
        end
    end
    squad.name = name
    SyncSquadMembersNW(squad, squadID)
    Warses_BroadcastSquads(teamID)
end

local function LockSpawnOn(ply, reason)
    if not IsValid(ply) then return end
    local until_ = CurTime() + SQUAD_SPAWN_LOCK
    if ply:GetNWFloat("WarsesSpawnLockUntil", 0) < until_ then
        ply:SetNWFloat("WarsesSpawnLockUntil", until_)
    end
end

hook.Add("PostEntityTakeDamage", "Warses_SquadSpawnLock_Damage", function(target, dmgInfo, took)
    if not took then return end
    if not IsValid(target) or not target:IsPlayer() then return end
    if not target:Alive() then return end
    local attacker = dmgInfo:GetAttacker()
    if IsValid(attacker) and attacker:IsPlayer() and attacker:Team() == target:Team() then
        return
    end
    LockSpawnOn(target, "damage")
end)

local _suppressNextOK = {}
hook.Add("EntityFireBullets", "Warses_SquadSpawnLock_Bullets", function(ent, bullet)
    if not IsValid(ent) or not ent:IsPlayer() then return end
    local now = CurTime()
    local nextOK = _suppressNextOK[ent] or 0
    if now < nextOK then return end
    _suppressNextOK[ent] = now + 0.1

    local shooterTeam = ent:Team()
    if shooterTeam ~= TEAM_ALPHA and shooterTeam ~= TEAM_BRAVO then return end

    local enemyTeam = (shooterTeam == TEAM_ALPHA) and TEAM_BRAVO or TEAM_ALPHA
    local enemies = team.GetPlayers(enemyTeam)
    local nEnemies = #enemies
    if nEnemies == 0 then return end

    local src  = bullet.Src
    local dir  = bullet.Dir
    if not src or not dir then return end
    local dlen = dir:Length()
    if dlen <= 0.001 then return end
    if math.abs(dlen - 1) > 0.05 then dir = dir / dlen end

    local maxDist  = math.min(bullet.Distance or SQUAD_SUPPRESS_RANGE, SQUAD_SUPPRESS_RANGE)
    local maxDist2 = maxDist * maxDist
    local minDist2 = 60 * 60
    local dot      = SQUAD_SUPPRESS_DOT

    for i = 1, nEnemies do
        local enemy = enemies[i]
        if IsValid(enemy) and enemy:Alive() then
            local toEnemy = enemy:WorldSpaceCenter() - src
            local d2 = toEnemy:LengthSqr()
            if d2 > minDist2 and d2 < maxDist2 then
                local invD = 1 / math.sqrt(d2)
                local cosA = (dir.x * toEnemy.x + dir.y * toEnemy.y + dir.z * toEnemy.z) * invD
                if cosA >= dot then
                    LockSpawnOn(enemy, "aim")
                end
            end
        end
    end
end)

hook.Add("PlayerDisconnected", "Warses_SquadSuppressCleanup", function(ply)
    _suppressNextOK[ply] = nil
end)

local function HullClear(pos, ply)
    local mins, maxs = ply:OBBMins(), ply:OBBMaxs()
    local tr = util.TraceHull({
        start  = pos + Vector(0, 0, 4),
        endpos = pos + Vector(0, 0, 4),
        mins   = mins,
        maxs   = maxs,
        filter = ply,
        mask   = MASK_PLAYERSOLID,
    })
    return not tr.StartSolid and not tr.AllSolid
end

local function FindSafeSpawnNear(targetPly, spawningPly)
    if not IsValid(targetPly) then return nil, nil end
    local basePos = targetPly:GetPos()
    local yaw = targetPly:EyeAngles().y
    local back = Angle(0, yaw + 180, 0):Forward()
    local right = Angle(0, yaw + 90, 0):Forward()

    local offsets = {
        back * 60,
        back * 60 + right * 40,
        back * 60 - right * 40,
        back * 100,
        right * 80,
        -right * 80,
        Vector(0, 0, 0),
    }
    for _, off in ipairs(offsets) do
        local pos = basePos + off
        if HullClear(pos, spawningPly) then
            local tr = util.TraceLine({
                start  = pos + Vector(0, 0, 16),
                endpos = pos - Vector(0, 0, 96),
                filter = { spawningPly, targetPly },
                mask   = MASK_PLAYERSOLID,
            })
            if tr.Hit and not tr.StartSolid then
                pos = tr.HitPos + Vector(0, 0, 2)
            end
            return pos, Angle(0, yaw, 0)
        end
    end
    return basePos, Angle(0, yaw, 0)
end

local function EnemyTooClose(targetPly)
    if not IsValid(targetPly) then return false end
    local pos = targetPly:GetPos()
    local enemyTeam = (targetPly:Team() == TEAM_ALPHA) and TEAM_BRAVO or TEAM_ALPHA
    for _, e in ipairs(team.GetPlayers(enemyTeam)) do
        if IsValid(e) and e:Alive() and e:GetPos():DistToSqr(pos) < (SQUAD_SPAWN_SAFE_R * SQUAD_SPAWN_SAFE_R) then
            return true
        end
    end
    return false
end

function Warses_TrySquadSpawn(ply, targetSID)
    if not IsValid(ply) or not targetSID or targetSID == "" then return nil end
    local mySquad, _, teamID = Warses_GetPlayerSquad(ply)
    if not mySquad then
        Notify(ply, "Вы не в отряде", 2); return nil
    end
    local target = player.GetBySteamID(targetSID)
    if not IsValid(target) then
        Notify(ply, "Союзник не найден", 2); return nil
    end
    if target == ply then return nil end
    if target:Team() ~= teamID then
        Notify(ply, "Союзник не в вашей команде", 2); return nil
    end
    local sameSquad = false
    for _, sid in ipairs(mySquad.members) do
        if sid == targetSID then sameSquad = true; break end
    end
    if not sameSquad then
        Notify(ply, "Союзник не в вашем отряде", 2); return nil
    end
    if not target:Alive() then
        Notify(ply, "Союзник мёртв", 2); return nil
    end
    if target:GetNWFloat("WarsesSpawnLockUntil", 0) > CurTime() then
        local left = math.ceil(target:GetNWFloat("WarsesSpawnLockUntil") - CurTime())
        Notify(ply, "Союзник под огнём (" .. left .. "с)", 2); return nil
    end
    if EnemyTooClose(target) then
        Notify(ply, "Враг слишком близко к союзнику", 2); return nil
    end
    local pos, ang = FindSafeSpawnNear(target, ply)
    if not pos then return nil end
    return { pos = pos, ang = ang }
end

net.Receive("Warses_SquadAction", function(len, ply)
    if not IsValid(ply) then return end
    local action = net.ReadString()

    if action == "create" then
        local name = net.ReadString()
        Warses_CreateSquad(ply, name)
    elseif action == "join" then
        local squadID = net.ReadUInt(16)
        Warses_JoinSquad(ply, squadID)
    elseif action == "leave" then
        Warses_LeaveSquad(ply)
    elseif action == "kick" then
        local sid = net.ReadString()
        Warses_KickFromSquad(ply, sid)
    elseif action == "promote" then
        local sid = net.ReadString()
        Warses_PromoteLeader(ply, sid)
    elseif action == "rename" then
        local name = net.ReadString()
        Warses_RenameSquad(ply, name)
    elseif action == "request_sync" then
        Warses_BroadcastSquads(TEAM_ALPHA)
        Warses_BroadcastSquads(TEAM_BRAVO)
    end
end)

hook.Add("PlayerDisconnected", "Warses_Squads_PlayerLeft", function(ply)
    if IsValid(ply) then Warses_LeaveSquad(ply, true) end
end)

function Warses_CleanupOnTeamChange(ply)
    if not IsValid(ply) then return end
    local squad = Warses_GetPlayerSquad(ply)
    if squad then Warses_LeaveSquad(ply, true) end
end

hook.Add("PlayerSpawn", "Warses_SquadLockReset", function(ply)
    if IsValid(ply) then ply:SetNWFloat("WarsesSpawnLockUntil", 0) end
end)

hook.Add("PlayerInitialSpawn", "Warses_Squads_InitialSync", function(ply)
    timer.Simple(2, function()
        if IsValid(ply) then
            Warses_BroadcastSquads(TEAM_ALPHA)
            Warses_BroadcastSquads(TEAM_BRAVO)
        end
    end)
end)

print("[Warses] Squad system loaded.")
