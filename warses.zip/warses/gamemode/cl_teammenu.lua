local teamMenuOpen = false
local TeamMenuFrame = nil

surface.CreateFont("Warses_TM_Title", {font = "Roboto", size = 84, weight = 900, antialias = true})
surface.CreateFont("Warses_TM_Sub",   {font = "Roboto", size = 28, weight = 500, antialias = true})
surface.CreateFont("Warses_TM_Card",  {font = "Roboto", size = 46, weight = 800, antialias = true})
surface.CreateFont("Warses_TM_Btn",   {font = "Roboto", size = 22, weight = 700, antialias = true})
surface.CreateFont("Warses_TM_Small", {font = "Roboto", size = 16, weight = 500, antialias = true})

local function MakeTeamCard(parent, teamID, displayName, bgColor, hoverColor, x, y, w, h)
    local btn = vgui.Create("DButton", parent)
    btn:SetPos(x, y)
    btn:SetSize(w, h)
    btn:SetText("")

    btn.hover = 0
    btn.press = 0
    btn.appear = 0
    btn.appearDelay = (teamID == TEAM_ALPHA) and 0.10 or 0.20
    btn.start = SysTime()

    btn.Think = function(self)
        local elapsed = SysTime() - self.start - self.appearDelay
        self.appear = math.Clamp(elapsed * 2.2, 0, 1)
        self.appear = 1 - math.pow(1 - self.appear, 3)

        local target = self:IsHovered() and 1 or 0
        self.hover = Lerp(FrameTime() * 8, self.hover, target)
    end

    btn.Paint = function(self, pw, ph)
        if self.appear <= 0 then return end
        local a = self.appear

        local yOff = (1 - a) * 60
        local ox, oy = 0, yOff
        local hov = self.hover

        surface.SetDrawColor(0, 0, 0, 140 * a)
        surface.DrawRect(ox + 8, oy + 10, pw, ph)

        local r = math.floor(Lerp(hov, bgColor.r, hoverColor.r))
        local g = math.floor(Lerp(hov, bgColor.g, hoverColor.g))
        local b = math.floor(Lerp(hov, bgColor.b, hoverColor.b))
        surface.SetDrawColor(r, g, b, 245 * a)
        surface.DrawRect(ox, oy, pw, ph)

        surface.SetDrawColor(0, 0, 0, 70 * a)
        surface.DrawRect(ox + 6, oy + 6, pw - 12, ph - 12)

        surface.SetDrawColor(hoverColor.r, hoverColor.g, hoverColor.b, 255 * a)
        surface.DrawRect(ox, oy, pw, 4)

        surface.SetDrawColor(hoverColor.r, hoverColor.g, hoverColor.b, 120 * a)
        surface.DrawRect(ox, oy + ph - 2, pw, 2)

        local ringA = hov * 140 * a
        surface.SetDrawColor(255, 255, 255, ringA)
        surface.DrawOutlinedRect(ox + 4 - hov * 4, oy + 4 - hov * 4,
            pw - 8 + hov * 8, ph - 8 + hov * 8, 2)

        draw.SimpleText(displayName, "Warses_TM_Card",
            ox + pw / 2, oy + ph / 2 - 16,
            Color(255, 255, 255, 255 * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        local count = team.NumPlayers(teamID)
        draw.SimpleText(count .. " игроков", "Warses_TM_Btn",
            ox + pw / 2, oy + ph / 2 + 28,
            Color(255, 255, 255, 210 * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    return btn
end

function OpenTeamMenu()
    local zombieMode = GAMEMODE and GAMEMODE.CurrentGameMode == "zombie"
    local cutscene = Warses_IsZombieCutsceneFullscreen and Warses_IsZombieCutsceneFullscreen()
    if zombieMode or cutscene then
        chat.AddText(Color(220, 60, 60), "[Зомби] Меню команд недоступно сейчас.")
        return
    end
    if teamMenuOpen and IsValid(TeamMenuFrame) then return end
    teamMenuOpen = true

    local scrW, scrH = ScrW(), ScrH()

    local frame = vgui.Create("DFrame")
    TeamMenuFrame = frame
    frame:SetSize(scrW, scrH)
    frame:SetPos(0, 0)
    frame:SetTitle("")
    frame:ShowCloseButton(false)
    frame:SetDraggable(false)
    frame:MakePopup()
    frame:SetKeyboardInputEnabled(false)

    frame.start = SysTime()
    frame.appear = 0
    frame.OnClose = function() teamMenuOpen = false end

    local conflict = GAMEMODE.Conflicts[GAMEMODE.CurrentConflict]
    local sub = conflict and conflict.subconflicts[GAMEMODE.CurrentSubconflict] or nil

    local alphaName = sub and sub.teams and sub.teams[TEAM_ALPHA] and sub.teams[TEAM_ALPHA].name or "Team Alpha"
    local bravoName = sub and sub.teams and sub.teams[TEAM_BRAVO] and sub.teams[TEAM_BRAVO].name or "Team Bravo"
    local conflictText = conflict and sub
        and (conflict.name .. "  —  " .. sub.name) or "Unknown Conflict"
    local conflictDesc = sub and sub.description or ""

    frame.Think = function(self)
        self.appear = math.Clamp((SysTime() - self.start) * 1.6, 0, 1)
        self.appear = 1 - math.pow(1 - self.appear, 3)
    end

    frame.Paint = function(self, w, h)
        local a = self.appear

        surface.SetDrawColor(8, 9, 14, 240 * a)
        surface.DrawRect(0, 0, w, h)

        surface.SetDrawColor(255, 255, 255, 4 * a)
        for i = -h, w, 28 do
            local off = (CurTime() * 12) % 28
            surface.DrawLine(i + off, 0, i + off + h, h)
        end

        local barH = 80 * a
        surface.SetDrawColor(20, 22, 30, 240 * a)
        surface.DrawRect(0, 0, w, barH)
        surface.SetDrawColor(190, 35, 40, 230 * a)
        surface.DrawRect(0, barH - 2, w, 2)

        draw.SimpleText("WARSES", "Warses_TM_Title",
            w / 2, barH / 2,
            Color(220, 55, 55, 255 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        local subY = Lerp(a, barH + 40, barH + 60)
        draw.SimpleText("ВЫБЕРИТЕ СТОРОНУ", "Warses_TM_Sub",
            w / 2, subY,
            Color(220, 220, 220, 220 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        draw.SimpleText(conflictText, "Warses_TM_Btn",
            w / 2, subY + 36,
            Color(230, 95, 90, 220 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if conflictDesc ~= "" then
            draw.SimpleText(conflictDesc, "Warses_TM_Small",
                w / 2, subY + 60,
                Color(160, 160, 160, 200 * a),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end

        local cardY = h / 2 - 140
        draw.SimpleText("VS", "Warses_TM_Title",
            w / 2, cardY + 160,
            Color(255, 255, 255, 60 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local cardW, cardH = 380, 240
    local gap = 80
    local totalW = cardW * 2 + gap
    local cardY = scrH / 2 - cardH / 2

    local alphaBg    = Color(20, 40, 70)
    local alphaHover = Color(40, 110, 220)
    local btnAlpha = MakeTeamCard(frame, TEAM_ALPHA, alphaName, alphaBg, alphaHover,
        scrW / 2 - totalW / 2, cardY, cardW, cardH)
    btnAlpha.DoClick = function()
        LocalPlayerState.team = TEAM_ALPHA
        net.Start("Warses_SelectTeam")
        net.WriteInt(TEAM_ALPHA, 16)
        net.SendToServer()
        surface.PlaySound("buttons/button14.wav")
        frame:Close()
    end

    local bravoBg    = Color(70, 20, 20)
    local bravoHover = Color(220, 60, 60)
    local btnBravo = MakeTeamCard(frame, TEAM_BRAVO, bravoName, bravoBg, bravoHover,
        scrW / 2 - totalW / 2 + cardW + gap, cardY, cardW, cardH)
    btnBravo.DoClick = function()
        LocalPlayerState.team = TEAM_BRAVO
        net.Start("Warses_SelectTeam")
        net.WriteInt(TEAM_BRAVO, 16)
        net.SendToServer()
        surface.PlaySound("buttons/button14.wav")
        frame:Close()
    end

    local btnSpec = vgui.Create("DButton", frame)
    btnSpec:SetSize(240, 44)
    btnSpec:SetPos(scrW / 2 - 120, cardY + cardH + 60)
    btnSpec:SetText("")
    btnSpec.hover = 0
    btnSpec.Think = function(self)
        self.hover = Lerp(FrameTime() * 8, self.hover, self:IsHovered() and 1 or 0)
    end
    btnSpec.Paint = function(self, w, h)
        local a = frame.appear
        local hov = self.hover
        local bgA = 200 + hov * 40
        surface.SetDrawColor(30 + hov * 30, 30 + hov * 30, 35 + hov * 30, bgA * a)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(180, 180, 180, (120 + 100 * hov) * a)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        draw.SimpleText("Наблюдать", "Warses_TM_Btn",
            w / 2, h / 2,
            Color(220, 220, 220, 240 * a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    btnSpec.DoClick = function()
        LocalPlayerState.team = TEAM_SPECTATOR
        LocalPlayerState.class = nil
        net.Start("Warses_SelectTeam")
        net.WriteInt(TEAM_SPECTATOR, 16)
        net.SendToServer()
        surface.PlaySound("buttons/button14.wav")
        frame:Close()
    end
end

net.Receive("Warses_OpenTeamMenu", function() OpenTeamMenu() end)
concommand.Add("warses_teammenu", OpenTeamMenu)

function GM:ShowTeam()
    OpenTeamMenu()
end

hook.Add("PlayerButtonDown", "Warses_TeamMenu_Key", function(ply, button)
    if button ~= KEY_F2 then return end
    if not IsFirstTimePredicted() then return end
    if not IsValid(ply) or ply ~= LocalPlayer() then return end
    if (gui.IsChatting and gui.IsChatting()) or gui.IsConsoleVisible() then return end
    OpenTeamMenu()
end)
