WarsesSquads = WarsesSquads or { [TEAM_ALPHA] = {}, [TEAM_BRAVO] = {} }

function WarsesGetMySquad()
    local ply = LocalPlayer()
    if not IsValid(ply) then return nil end
    local sid = ply:GetNWInt("WarsesSquadID", 0)
    if sid == 0 then return nil end
    local team = ply:Team()
    local list = WarsesSquads[team]
    return list and list[sid] or nil, sid, team
end

function WarsesGetSquadOf(ply)
    if not IsValid(ply) then return nil end
    local sid = ply:GetNWInt("WarsesSquadID", 0)
    if sid == 0 then return nil end
    local list = WarsesSquads[ply:Team()]
    return list and list[sid] or nil, sid
end

surface.CreateFont("Warses_SQ_Title",  {font = "Roboto", size = 44, weight = 900, antialias = true})
surface.CreateFont("Warses_SQ_Sub",    {font = "Roboto", size = 18, weight = 500, antialias = true})
surface.CreateFont("Warses_SQ_Card",   {font = "Roboto", size = 22, weight = 800, antialias = true})
surface.CreateFont("Warses_SQ_Member", {font = "Roboto", size = 16, weight = 500, antialias = true})
surface.CreateFont("Warses_SQ_Tag",    {font = "Roboto", size = 12, weight = 700, antialias = true})
surface.CreateFont("Warses_SQ_Btn",    {font = "Roboto", size = 18, weight = 700, antialias = true})
surface.CreateFont("Warses_SQ_Small",  {font = "Roboto", size = 13, weight = 500, antialias = true})

net.Receive("Warses_SquadSync", function()
    local teamID = net.ReadUInt(4)
    local n = net.ReadUInt(8)
    local list = {}
    for i = 1, n do
        local sq = {}
        sq.id      = net.ReadUInt(16)
        sq.name    = net.ReadString()
        sq.leader  = net.ReadString()
        local mc   = net.ReadUInt(8)
        sq.members = {}
        for j = 1, mc do
            sq.members[#sq.members + 1] = net.ReadString()
        end
        list[sq.id] = sq
    end
    WarsesSquads[teamID] = list
end)

net.Receive("Warses_SquadNotify", function()
    local text  = net.ReadString()
    local level = net.ReadUInt(4)
    local prefix = "[Отряд] "
    local col = Color(220, 220, 220)
    if level == 1 then col = Color(120, 255, 140)
    elseif level == 2 then col = Color(255, 200, 80)
    elseif level == 3 then col = Color(255, 100, 100) end
    chat.AddText(col, prefix .. text)
    if level >= 2 then
        surface.PlaySound("buttons/button10.wav")
    else
        surface.PlaySound("buttons/button14.wav")
    end
end)

local function SendAction(name, ...)
    net.Start("Warses_SquadAction")
    net.WriteString(name)
    for _, v in ipairs({...}) do
        if isnumber(v) then
            net.WriteUInt(v, 16)
        else
            net.WriteString(tostring(v))
        end
    end
    net.SendToServer()
end

local SquadMenuFrame = nil

local _sidCache, _sidCacheT = {}, -1
local function _refreshSIDCache()
    if CurTime() - _sidCacheT < 1.0 then return _sidCache end
    _sidCacheT = CurTime()
    for k in pairs(_sidCache) do _sidCache[k] = nil end
    local plys = player.GetAll()
    for i = 1, #plys do
        local p = plys[i]
        if IsValid(p) then _sidCache[p:SteamID()] = p end
    end
    return _sidCache
end

local function PlayerNameFromSID(sid)
    local lookup = _refreshSIDCache()
    local p = lookup[sid]
    if IsValid(p) then return p:Nick(), p end
    return "—", nil
end

local function ClassNameOf(ply)
    if not IsValid(ply) then return "" end
    local cls = ply:GetNWString("Class", "")
    if cls ~= "" and GAMEMODE.Classes[cls] then
        return GAMEMODE.Classes[cls].name
    end
    return ""
end

local function BuildMemberRow(parent, sid, isLeader, isMe, isMyLeader, mySquadID)
    local row = vgui.Create("DPanel", parent)
    row:Dock(TOP)
    row:DockMargin(0, 0, 0, 4)
    row:SetTall(36)

    local nick, ply = PlayerNameFromSID(sid)
    local alive = IsValid(ply) and ply:Alive()
    local cls   = ClassNameOf(ply)

    row.Paint = function(self, w, h)
        surface.SetDrawColor(20, 22, 28, 230)
        surface.DrawRect(0, 0, w, h)
        local accent = isLeader and Color(255, 200, 80) or Color(120, 170, 255)
        surface.SetDrawColor(accent.r, accent.g, accent.b, 230)
        surface.DrawRect(0, 0, 3, h)

        if isLeader then
            draw.SimpleText("★", "Warses_SQ_Card", 14, h / 2,
                Color(255, 220, 100), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
        local nameCol = isMe and Color(120, 255, 140) or Color(235, 235, 240)
        draw.SimpleText(nick, "Warses_SQ_Member",
            isLeader and 32 or 14, h / 2 - 8,
            nameCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        if cls ~= "" then
            draw.SimpleText(cls, "Warses_SQ_Small",
                isLeader and 32 or 14, h / 2 + 8,
                Color(170, 175, 195), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
        if not alive then
            draw.SimpleText("МЁРТВ", "Warses_SQ_Tag", w - 80, h / 2,
                Color(255, 100, 100), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        elseif IsValid(ply) then
            local lock = ply:GetNWFloat("WarsesSpawnLockUntil", 0) - CurTime()
            if lock > 0 then
                draw.SimpleText("ПОД ОГНЁМ " .. math.ceil(lock) .. "c",
                    "Warses_SQ_Tag", w - 130, h / 2,
                    Color(255, 130, 100), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            end
        end
    end

    if isMyLeader and not isMe then
        local kick = vgui.Create("DButton", row)
        kick:SetText("X")
        kick:SetFont("Warses_SQ_Btn")
        kick:SetTextColor(Color(255, 220, 220))
        kick:SetSize(28, 28)
        kick.Paint = function(self, w, h)
            local hov = self:IsHovered()
            surface.SetDrawColor(hov and 170 or 110, 40, 40, 240)
            surface.DrawRect(0, 0, w, h)
        end
        kick.DoClick = function() SendAction("kick", sid) end
        kick.PerformLayout = function(self) self:SetPos(row:GetWide() - 36, 4) end
        kick.Think = function(self) self:PerformLayout() end

        local prom = vgui.Create("DButton", row)
        prom:SetText("★")
        prom:SetFont("Warses_SQ_Btn")
        prom:SetTextColor(Color(255, 240, 200))
        prom:SetSize(28, 28)
        prom.Paint = function(self, w, h)
            local hov = self:IsHovered()
            surface.SetDrawColor(hov and 180 or 110, hov and 140 or 90, 40, 240)
            surface.DrawRect(0, 0, w, h)
        end
        prom.DoClick = function() SendAction("promote", sid) end
        prom.PerformLayout = function(self) self:SetPos(row:GetWide() - 70, 4) end
        prom.Think = function(self) self:PerformLayout() end
    end

    return row
end

local function BuildSquadCard(parent, squad, myTeam, mySquad, mySquadID)
    local card = vgui.Create("DPanel", parent)
    card:Dock(TOP)
    card:DockMargin(0, 0, 0, 10)
    card:DockPadding(12, 10, 12, 10)

    local isMine = (mySquadID == squad.id)
    local full   = #squad.members >= SQUAD_MAX_MEMBERS

    local header = vgui.Create("DPanel", card)
    header:Dock(TOP)
    header:SetTall(34)
    header.Paint = function(self, w, h)
        local teamCol = (myTeam == TEAM_ALPHA) and Color(80, 140, 240) or Color(240, 80, 80)
        draw.SimpleText(squad.name or "?", "Warses_SQ_Card",
            0, h / 2, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText(#squad.members .. " / " .. SQUAD_MAX_MEMBERS, "Warses_SQ_Tag",
            w - 4, h / 2,
            full and Color(255, 100, 100) or Color(180, 230, 180),
            TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
    end

    if not isMine and not full then
        local joinBtn = vgui.Create("DButton", card)
        joinBtn:Dock(TOP)
        joinBtn:DockMargin(0, 4, 0, 4)
        joinBtn:SetTall(28)
        joinBtn:SetText("")
        joinBtn.Paint = function(self, w, h)
            local hov = self:IsHovered()
            surface.SetDrawColor(hov and 60 or 40, hov and 120 or 80, 60, 240)
            surface.DrawRect(0, 0, w, h)
            draw.SimpleText("ВСТУПИТЬ", "Warses_SQ_Btn",
                w / 2, h / 2, Color(255, 255, 255),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        joinBtn.DoClick = function() SendAction("join", squad.id) end
    end

    local isMyLeader = isMine and mySquad and mySquad.leader == LocalPlayer():SteamID()
    for _, sid in ipairs(squad.members) do
        BuildMemberRow(card, sid,
            squad.leader == sid,
            sid == LocalPlayer():SteamID(),
            isMyLeader,
            mySquadID)
    end

    card.PerformLayout = function(self, w, h)
        local total = 14 + 34 + 8
        if not isMine and not full then total = total + 32 end
        total = total + (#squad.members * 40)
        self:SetTall(total)
    end

    card.Paint = function(self, w, h)
        surface.SetDrawColor(14, 16, 22, 235)
        surface.DrawRect(0, 0, w, h)
        local accent = isMine and Color(120, 255, 140) or
                       ((myTeam == TEAM_ALPHA) and Color(80, 140, 240) or Color(240, 80, 80))
        surface.SetDrawColor(accent.r, accent.g, accent.b, 220)
        surface.DrawRect(0, 0, 4, h)
    end

    return card
end

local function RebuildSquadList(scroll)
    scroll:Clear()
    local myTeam = LocalPlayer():Team()
    if myTeam ~= TEAM_ALPHA and myTeam ~= TEAM_BRAVO then
        local lbl = vgui.Create("DLabel", scroll)
        lbl:Dock(TOP)
        lbl:SetTall(40)
        lbl:SetFont("Warses_SQ_Sub")
        lbl:SetText("  Выберите команду чтобы видеть отряды")
        lbl:SetTextColor(Color(200, 200, 200))
        return
    end

    local mySquad, mySquadID = WarsesGetMySquad()
    local list = WarsesSquads[myTeam] or {}
    local ids = {}
    for id in pairs(list) do ids[#ids + 1] = id end
    table.sort(ids)

    if #ids == 0 then
        local lbl = vgui.Create("DLabel", scroll)
        lbl:Dock(TOP)
        lbl:SetTall(40)
        lbl:SetFont("Warses_SQ_Sub")
        lbl:SetText("  В команде пока нет отрядов — создайте первый")
        lbl:SetTextColor(Color(200, 200, 200))
        return
    end

    for _, id in ipairs(ids) do
        BuildSquadCard(scroll, list[id], myTeam, mySquad, mySquadID)
    end
end

function OpenSquadMenu()
    if IsValid(SquadMenuFrame) then
        SquadMenuFrame:Close()
        SquadMenuFrame = nil
        return
    end

    local scrW, scrH = ScrW(), ScrH()
    local w, h = math.min(scrW * 0.7, 920), math.min(scrH * 0.78, 720)

    local frame = vgui.Create("DFrame")
    SquadMenuFrame = frame
    frame:SetSize(w, h)
    frame:Center()
    frame:SetTitle("")
    frame:ShowCloseButton(false)
    frame:MakePopup()

    frame.Paint = function(self, pw, ph)
        surface.SetDrawColor(8, 9, 14, 245)
        surface.DrawRect(0, 0, pw, ph)
        surface.SetDrawColor(190, 35, 40, 230)
        surface.DrawRect(0, 0, pw, 3)
        draw.SimpleText("ОТРЯДЫ", "Warses_SQ_Title",
            pw / 2, 36, Color(255, 255, 255),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("Создайте отряд или вступите — спавн на лидере и сослуживцах",
            "Warses_SQ_Sub", pw / 2, 70,
            Color(200, 200, 210), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local closeBtn = vgui.Create("DButton", frame)
    closeBtn:SetSize(36, 36)
    closeBtn:SetPos(w - 44, 8)
    closeBtn:SetText("")
    closeBtn.Paint = function(self, pw, ph)
        local hov = self:IsHovered()
        surface.SetDrawColor(hov and 170 or 110, 40, 40, 240)
        surface.DrawRect(0, 0, pw, ph)
        draw.SimpleText("X", "Warses_SQ_Btn", pw / 2, ph / 2,
            Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    closeBtn.DoClick = function() frame:Close(); SquadMenuFrame = nil end

    local leftW = 240
    local actions = vgui.Create("DPanel", frame)
    actions:SetPos(20, 100)
    actions:SetSize(leftW, h - 120)
    actions.Paint = function(self, pw, ph)
        surface.SetDrawColor(14, 16, 22, 230)
        surface.DrawRect(0, 0, pw, ph)
        surface.SetDrawColor(255, 255, 255, 18)
        surface.DrawOutlinedRect(0, 0, pw, ph, 1)
    end

    local nameEntry = vgui.Create("DTextEntry", actions)
    nameEntry:SetPos(14, 50)
    nameEntry:SetSize(leftW - 28, 32)
    nameEntry:SetFont("Warses_SQ_Sub")
    nameEntry:SetPlaceholderText("Имя отряда")
    nameEntry.Paint = function(self, pw, ph)
        surface.SetDrawColor(20, 22, 28, 240)
        surface.DrawRect(0, 0, pw, ph)
        surface.SetDrawColor(120, 130, 150, 180)
        surface.DrawOutlinedRect(0, 0, pw, ph, 1)
        self:DrawTextEntryText(Color(240, 240, 240), Color(120, 170, 255), Color(240, 240, 240))
    end

    local nameLbl = vgui.Create("DLabel", actions)
    nameLbl:SetPos(14, 26)
    nameLbl:SetSize(leftW - 28, 20)
    nameLbl:SetFont("Warses_SQ_Tag")
    nameLbl:SetText("ИМЯ ОТРЯДА")
    nameLbl:SetTextColor(Color(140, 160, 200))

    local function MakeBigButton(parent, label, y, color, onClick)
        local b = vgui.Create("DButton", parent)
        b:SetPos(14, y)
        b:SetSize(leftW - 28, 36)
        b:SetText("")
        b.Paint = function(self, pw, ph)
            local hov = self:IsHovered()
            local r = math.floor(Lerp(hov and 1 or 0, color.r * 0.6, color.r))
            local g = math.floor(Lerp(hov and 1 or 0, color.g * 0.6, color.g))
            local bcol = math.floor(Lerp(hov and 1 or 0, color.b * 0.6, color.b))
            surface.SetDrawColor(r, g, bcol, 240)
            surface.DrawRect(0, 0, pw, ph)
            draw.SimpleText(label, "Warses_SQ_Btn",
                pw / 2, ph / 2, Color(255, 255, 255),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        b.DoClick = onClick
        return b
    end

    MakeBigButton(actions, "СОЗДАТЬ", 96, Color(80, 160, 90), function()
        SendAction("create", nameEntry:GetValue())
        nameEntry:SetValue("")
    end)

    MakeBigButton(actions, "ПЕРЕИМЕНОВАТЬ", 140, Color(90, 110, 170), function()
        local v = nameEntry:GetValue()
        if v == "" then return end
        SendAction("rename", v)
        nameEntry:SetValue("")
    end)

    MakeBigButton(actions, "ПОКИНУТЬ ОТРЯД", 184, Color(170, 70, 70), function()
        SendAction("leave")
    end)

    MakeBigButton(actions, "ОБНОВИТЬ", 240, Color(80, 90, 110), function()
        SendAction("request_sync")
    end)

    local hint = vgui.Create("DLabel", actions)
    hint:SetPos(14, 296)
    hint:SetSize(leftW - 28, 200)
    hint:SetFont("Warses_SQ_Small")
    hint:SetWrap(true)
    hint:SetContentAlignment(7)
    hint:SetText(
        "• До " .. SQUAD_MAX_MEMBERS .. " человек в отряде\n" ..
        "• Спавн на любом живом сослуживце\n" ..
        "• Если по нему стреляют или ранили — спавн на нём блокируется на " ..
        (SQUAD_SPAWN_LOCK or 10) .. " сек\n" ..
        "• ★ — повысить до лидера, X — выгнать"
    )
    hint:SetTextColor(Color(180, 185, 200))

    local rightX = 20 + leftW + 16
    local rightW = w - rightX - 20
    local scroll = vgui.Create("DScrollPanel", frame)
    scroll:SetPos(rightX, 100)
    scroll:SetSize(rightW, h - 120)

    local sb = scroll:GetVBar()
    sb:SetWide(5)
    sb.Paint = function(_, pw, ph) surface.SetDrawColor(20, 22, 28, 200); surface.DrawRect(0, 0, pw, ph) end
    sb.btnUp.Paint = function() end
    sb.btnDown.Paint = function() end
    sb.btnGrip.Paint = function(_, pw, ph) surface.SetDrawColor(140, 150, 170, 220); surface.DrawRect(0, 0, pw, ph) end

    RebuildSquadList(scroll)
    local lastRebuild = 0
    scroll.Think = function(self)
        if CurTime() - lastRebuild > 1.0 then
            lastRebuild = CurTime()
            RebuildSquadList(self)
        end
    end

    SendAction("request_sync")
end

concommand.Add("warses_squadmenu", OpenSquadMenu)

hook.Add("PlayerButtonDown", "Warses_SquadMenu_Key", function(ply, button)
    if button ~= KEY_F3 then return end
    if not IsFirstTimePredicted() then return end
    if not IsValid(ply) or ply ~= LocalPlayer() then return end
    if (gui.IsChatting and gui.IsChatting()) or gui.IsConsoleVisible() then return end
    OpenSquadMenu()
end)
