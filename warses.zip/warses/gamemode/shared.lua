GM.Name = "Warses"
GM.Author = "Navalny Lexa"
GM.Email = ""
GM.Website = ""


TEAM_ALPHA = 1
TEAM_BRAVO = 2

Warses_CPCache = Warses_CPCache or {}
Warses_GZCache = Warses_GZCache or {}

local function _addToCache(cache, ent)
    for i = 1, #cache do
        if cache[i] == ent then return end
    end
    cache[#cache + 1] = ent
end

local function _removeFromCache(cache, ent)
    for i = 1, #cache do
        if cache[i] == ent then
            table.remove(cache, i)
            return
        end
    end
end

local function _compactCache(cache)
    local j = 1
    for i = 1, #cache do
        local e = cache[i]
        if IsValid(e) then
            if i ~= j then cache[j] = e end
            j = j + 1
        end
    end
    for k = j, #cache do cache[k] = nil end
end

function Warses_GetCPs()
    _compactCache(Warses_CPCache)
    return Warses_CPCache
end

function Warses_GetGZs()
    _compactCache(Warses_GZCache)
    return Warses_GZCache
end

hook.Add("OnEntityCreated", "Warses_EntCacheCreate", function(ent)
    if not IsValid(ent) then return end
    local cls = ent:GetClass()
    if cls == "warses_capturepoint" then
        _addToCache(Warses_CPCache, ent)
    elseif cls == "warses_gravity_zone" then
        _addToCache(Warses_GZCache, ent)
    end
end)

hook.Add("EntityRemoved", "Warses_EntCacheRemove", function(ent)
    local cls = ent:GetClass()
    if cls == "warses_capturepoint" then
        _removeFromCache(Warses_CPCache, ent)
    elseif cls == "warses_gravity_zone" then
        _removeFromCache(Warses_GZCache, ent)
    end
end)

hook.Add("InitPostEntity", "Warses_EntCacheInit", function()
    Warses_CPCache = {}
    Warses_GZCache = {}
    for _, e in ipairs(ents.FindByClass("warses_capturepoint")) do
        Warses_CPCache[#Warses_CPCache + 1] = e
    end
    for _, e in ipairs(ents.FindByClass("warses_gravity_zone")) do
        Warses_GZCache[#Warses_GZCache + 1] = e
    end
end)

SQUAD_MAX_MEMBERS  = 6
SQUAD_MIN_NAME_LEN = 2
SQUAD_MAX_NAME_LEN = 18
SQUAD_SPAWN_LOCK   = 10 

function GM:CreateTeams()
    team.SetUp(TEAM_ALPHA, "Team Alpha", Color(0, 100, 255), false)
    team.SetUp(TEAM_BRAVO, "Team Bravo", Color(255, 50, 50), false)
    team.SetUp(TEAM_SPECTATOR, "Spectators", Color(150, 150, 150), true)
end

-- Game Modes
GM.GameModesList = {
    capture = "Захват",
    operation = "Операция",
    deathmatch = "DeathMatch",
    zombie = "Зомби"
}


GM.ZombieTriggerMap = "gm_baik_stalingrad"
GM.ZombieTriggerChance = 0.35 -- 35%

GM.CurrentGameMode = "capture" -- default

GM.MapGameModes = {
    rp_vietnam_snp = {"capture", "operation"},
    gm_terminal_v1a = {"capture", "deathmatch"},
    usa_gaza_genocide = {"deathmatch"},
    mp_pipeline = {"capture", "deathmatch"},
    gm_baik_stalingrad = {"capture", "deathmatch"},
    redwinter = {"operation", "deathmatch"},
    vietnam_b5 = {"capture", "deathmatch"},
    iraq = {"deathmatch"},
    omaha_beach = {"capture", "operation"},
    aachen_d = {"operation"},

}

GM.Conflicts = {
    coldwar = {
        name = "Cold War",
        period = "1947 — 1991",
        description = "Прокси-конфликты эпохи противостояния сверхдержав",
        icon = "icon16/bomb.png",
        order = 4,
        subconflicts = {
            vietnam = {
                name = "Vietnam War",
                description = "Jungle warfare with helicopters and napalm",
                maps = {"rp_hgs_gmv", "rp_vietnam_snp", "vietnam_b5"},
                teams = {
                    [TEAM_ALPHA] = {name = "US Army", models = {
                        assault = {"models/jessev92/soldier_vietnam/us02.mdl"},
                        support = {"models/jessev92/soldier_vietnam/us03.mdl"},
                        sniper = {"models/jessev92/soldier_vietnam/us04.mdl"},
                        medic = {"models/jessev92/soldier_vietnam/us05.mdl"}
                    }},
                    [TEAM_BRAVO] = {name = "Viet Cong", models = {
                        assault = {"models/player/kuma/nva_soldier.mdl"},
                        support = {"models/player/kuma/nva_soldier.mdl"},
                        sniper = {"models/player/kuma/vietcong_soldier.mdl"},
                        medic = {"models/player/kuma/vietcong_soldier.mdl"}
                    }}
                },
                weaponLoadouts = {
                    [TEAM_ALPHA] = { -- US Army
                        assault = {"weapon_m16a2", "weapon_m1911", "weapon_buck200knife", "weapon_hg_grenade_tpik","weapon_medkit_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        support = {"weapon_m60e621", "weapon_m1911", "weapon_buck200knife", "weapon_hg_smokenade_tpik","weapon_medkit_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        sniper = {"weapon_m24remington", "weapon_m1911", "weapon_buck200knife","weapon_medkit_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        medic = {"weapon_remington870", "weapon_m1911", "weapon_warses_defib", "weapon_buck200knife","weapon_medkit_inf_sh", "weapon_walkie_talkie_alpha","weapon_hg_m18_tpik", "weapon_hands_sh"}
                    },
                    [TEAM_BRAVO] = { -- Viet Cong
                        assault = {"weapon_akm", "weapon_makarov", "weapon_buck200knife", "weapon_hg_rgd_tpik","weapon_medkit_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        support = {"weapon_hg_rpg", "weapon_skorpion", "weapon_buck200knife", "weapon_hg_smokenade_tpik","weapon_medkit_sh", "weapon_hg_molotov_tpik", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        sniper = {"weapon_svd", "weapon_makarov", "weapon_buck200knife","weapon_medkit_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        medic = {"weapon_mat49", "weapon_skorpion", "weapon_medkit_inf_sh", "weapon_warses_defib", "weapon_buck200knife", "weapon_walkie_talkie_bravo","weapon_hg_m18_tpik", "weapon_hands_sh"}
                    }
                },
                ammoLoadouts = {
                    [TEAM_ALPHA] = { -- US Army ammo
                        assault = {["ent_ammo_5.56x45mm"] = 180, ["ent_ammo_.45acp"] = 50},
                        support = {["ent_ammo_7.62x51mm"] = 300, ["ent_ammo_.45acp"] = 50},
                        sniper = {["ent_ammo_7.62x51mm"] = 60, ["ent_ammo_.45acp"] = 30},
                        medic = {["ent_ammo_12/70gauge"] = 40, ["ent_ammo_.45acp"] = 50}
                    },
                    [TEAM_BRAVO] = { -- Viet Cong ammo
                        assault = {["ent_ammo_7.62x39mm"] = 180, ["ent_ammo_9x18mm"] = 50},
                        support = {["ent_ammo_rpg-7projectile"] = 3, ["ent_ammo_7.65x17mm"] = 100},
                        sniper = {["ent_ammo_7.62x54mm"] = 60, ["ent_ammo_9x18mm"] = 30},
                        medic = {["ent_ammo_9x19mmparabellum"] = 180, ["ent_ammo_7.65x17mm"] = 50}
                    }
                },
                attachmentLoadouts = {
                    [TEAM_BRAVO] = { -- Viet Cong attachments
                        sniper = {"optic4"}
                    }
                }
            }
        }
    },
    ww1 = {
        name = "World War I",
        period = "1914 — 1918",
        description = "Великая война и распад империй",
        icon = "icon16/flag_green.png",
        order = 2,
        subconflicts = {
            russian_civil_war = {
                name = "Russian Civil War",
                description = "Гражданская война: красные против белых (1917—1923)",
                maps = {"redwinter"},
                availableClasses = {"rcw_rifleshot", "rcw_medic", "rcw_sniper"},
                teams = {
                    [TEAM_ALPHA] = {name = "Red Army", models = {
                        rcw_rifleshot = {"models/ro1soviet_rifleman2pm.mdl"},
                        rcw_medic     = {"models/ro1soviet_rifleman6pm.mdl"},
                        rcw_sniper    = {"models/ro1soviet_rifleman5pm.mdl"}
                    }},
                    [TEAM_BRAVO] = {name = "White Army", models = {
                        rcw_rifleshot = {"models/player/imperial_russian/russian_officer.mdl"},
                        rcw_medic     = {"models/player/imperial_russian/russian_officer.mdl"},
                        rcw_sniper    = {"models/player/imperial_russian/russian_officer.mdl"}
                    }}
                },
                weaponLoadouts = {
                    [TEAM_ALPHA] = { -- Red Army
                        rcw_rifleshot = {"weapon_mosinm9130", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        rcw_medic     = {"weapon_doublebarrel", "weapon_medkit_sh", "weapon_buck200knife", "weapon_bigbandage_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        rcw_sniper    = {"weapon_mosinm9130", "weapon_buck200knife", "weapon_medkit_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"}
                    },
                    [TEAM_BRAVO] = { -- White Army
                        rcw_rifleshot = {"weapon_mosinm9130", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        rcw_medic     = {"weapon_doublebarrel", "weapon_medkit_sh", "weapon_buck200knife", "weapon_bigbandage_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        rcw_sniper    = {"weapon_mosinm9130", "weapon_buck200knife", "weapon_medkit_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh"}
                    }
                },
                ammoLoadouts = {
                    [TEAM_ALPHA] = { -- Red Army ammo
                        rcw_rifleshot = {["ent_ammo_7.62x54mm"] = 120, ["ent_ammo_7.62x25mm"] = 50},
                        rcw_medic     = {["ent_ammo_12/70gauge"] = 120, ["ent_ammo_7.62x25mm"] = 50},
                        rcw_sniper    = {["ent_ammo_7.62x54mm"] = 60,  ["ent_ammo_7.62x25mm"] = 30}
                    },
                    [TEAM_BRAVO] = { -- White Army ammo
                        rcw_rifleshot = {["ent_ammo_7.62x54mm"] = 120, ["ent_ammo_7.62x25mm"] = 50},
                        rcw_medic     = {["ent_ammo_12/70gauge"] = 120, ["ent_ammo_7.62x25mm"] = 50},
                        rcw_sniper    = {["ent_ammo_7.62x54mm"] = 60,  ["ent_ammo_7.62x25mm"] = 30}
                    }
                },
                attachmentLoadouts = {
                    [TEAM_ALPHA] = {
                        rcw_sniper = {"optic12"}
                    },
                    [TEAM_BRAVO] = {
                        rcw_sniper = {"optic12"}
                    }
                }
            }
        }
    },
    ww2 = {
        name = "World War II",
        period = "1939 — 1945",
        description = "Глобальный конфликт: Восточный фронт",
        icon = "icon16/flag_red.png",
        order = 3,
        subconflicts = {
            eastern_front = {
                name = "Soviet Union Campaign",
                description = "Warfare in 1940s",
                maps = {"gm_baik_stalingrad", "rp_koursk_neros"},
                teams = {
                    [TEAM_ALPHA] = {name = "Soviet Union", models = {
                        assault = {"models/ro1soviet_rifleman2pm.mdl"},
                        support = {"models/ro1soviet_rifleman3pm.mdl"},
                        sniper = {"models/ro1soviet_rifleman5pm.mdl"},
                        medic = {"models/ro1soviet_rifleman6pm.mdl"}
                    }},
                    [TEAM_BRAVO] = {name = "Germany", models = {
                        assault = {"models/half-dead/red orchestra 2/GER/Hero.mdl"},
                        support = {"models/half-dead/red orchestra 2/GER/RawRecruit.mdl"},
                        sniper = {"models/half-dead/red orchestra 2/GER/Parka.mdl"},
                        medic = {"models/half-dead/red orchestra 2/GER/Tanker.mdl"}
                    }}
                },
                weaponLoadouts = {
                    [TEAM_ALPHA] = { -- Soviet Union
                        assault = {"weapon_ppsh", "weapon_tokarev", "weapon_buck200knife", "weapon_hg_f1_tpik","weapon_medkit_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        support = {"weapon_dp27", "weapon_tokarev", "weapon_buck200knife", "weapon_hg_m18_tpik","weapon_medkit_sh","weapon_hg_molotov_tpik", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        sniper = {"weapon_mosin", "weapon_tokarev", "weapon_buck200knife","weapon_medkit_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        medic = {"weapon_svtsvo", "weapon_tokarev", "weapon_medkit_inf_sh", "weapon_warses_defib", "weapon_buck200knife","weapon_bigbandage_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh","weapon_hg_m18_tpik"}
                    },
                    [TEAM_BRAVO] = { -- Germany
                        assault = {"weapon_mp40", "weapon_p38", "weapon_buck200knife", "weapon_hg_stilya_tpik","weapon_medkit_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        support = {"weapon_mg34", "weapon_p38", "weapon_buck200knife", "weapon_hg_stilya_tpik","weapon_medkit_sh", "weapon_hg_molotov_tpik", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        sniper = {"weapon_kar98", "weapon_p38", "weapon_buck200knife","weapon_medkit_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        medic = {"weapon_gewehr43", "weapon_p38", "weapon_medkit_inf_sh", "weapon_warses_defib", "weapon_buck200knife","weapon_bigbandage_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh","weapon_hg_nebelgranate_tpik"}
                    }
                },
                ammoLoadouts = {
                    [TEAM_ALPHA] = { -- Soviet Union ammo
                        assault = {["ent_ammo_7.62x25mm"] = 180, ["ent_ammo_7.62x25mm"] = 180},
                        support = {["ent_ammo_7.62x54mm"] = 200, ["ent_ammo_7.62x25mm"] = 50},
                        sniper = {["ent_ammo_7.62x54mm"] = 60, ["ent_ammo_7.62x25mm"] = 30},
                        medic = {["ent_ammo_7.62x54mm"] = 40, ["ent_ammo_7.62x25mm"] = 50}
                    },
                    [TEAM_BRAVO] = { -- Germany ammo
                        assault = {["ent_ammo_9x19mmparabellum"] = 180, ["ent_ammo_9x19mmparabellum"] = 180},
                        support = {["ent_ammo_7.92x57mmmauser"] = 200, ["ent_ammo_9x19mmparabellum"] = 100},
                        sniper = {["ent_ammo_7.62x51mm"] = 60, ["ent_ammo_9x19mmparabellum"] = 30},
                        medic = {["ent_ammo_7.92x57mmmauser"] = 40, ["ent_ammo_9x19mmparabellum"] = 50}
                    }
                },
                attachmentLoadouts = {
                    [TEAM_ALPHA] = { -- Soviet Union attachments
                        sniper = {"optic12"}
                    },
                    [TEAM_BRAVO] = { -- Germany attachments
                        sniper = {"optic12"}
                    }
                }
            },
            western_front = {
                name = "America vs Germany",
                description = "Западный фронт: высадка союзников",
                maps = {"omaha_beach", "aachen_d"},
                teams = {
                    [TEAM_ALPHA] = {name = "America", models = {
                        assault = {"models/wwii/humans/usa/gmod/player/us_hero_01_adam.mdl"},
                        support = {"models/wwii/humans/usa/gmod/player/us_hero_06_bill.mdl"},
                        sniper = {"models/wwii/humans/usa/gmod/player/us_veteran_01_adam.mdl"},
                        medic = {"models/wwii/humans/usa/gmod/player/us_raw_06_bill.mdl"}
                    }},
                    [TEAM_BRAVO] = {name = "Germany", models = {
                        assault = {"models/half-dead/red orchestra 2/GER/Hero.mdl"},
                        support = {"models/half-dead/red orchestra 2/GER/RawRecruit.mdl"},
                        sniper = {"models/half-dead/red orchestra 2/GER/Parka.mdl"},
                        medic = {"models/half-dead/red orchestra 2/GER/Tanker.mdl"}
                    }}
                },

                weaponLoadouts = {
                    [TEAM_ALPHA] = { -- America
                        assault = {"weapon_thompson", "weapon_m1911", "weapon_buck200knife", "weapon_hg_mk2_tpik","weapon_medkit_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        support = {"arc9_doi_m1919", "weapon_m1911", "weapon_buck200knife", "weapon_hg_m18_tpik","weapon_medkit_sh","weapon_hg_molotov_tpik", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        sniper = {"arc9_doi_garand", "weapon_m1911", "weapon_buck200knife","weapon_medkit_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        medic = {"weapon_ithaca37", "weapon_m1911", "weapon_medkit_inf_sh", "weapon_warses_defib", "weapon_buck200knife","weapon_bigbandage_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh","weapon_hg_m18_tpik"}
                    },
                    [TEAM_BRAVO] = { -- Germany
                        assault = {"weapon_mp40", "weapon_p38", "weapon_buck200knife", "weapon_hg_stilya_tpik","weapon_medkit_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        support = {"weapon_mg34", "weapon_p38", "weapon_buck200knife", "weapon_hg_stilya_tpik","weapon_medkit_sh", "weapon_hg_molotov_tpik", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        sniper = {"weapon_kar98", "weapon_p38", "weapon_buck200knife","weapon_medkit_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        medic = {"weapon_gewehr43", "weapon_p38", "weapon_medkit_inf_sh", "weapon_warses_defib", "weapon_buck200knife","weapon_bigbandage_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh","weapon_hg_nebelgranate_tpik"}
                    }
                },
                ammoLoadouts = {
                    [TEAM_ALPHA] = { -- America ammo
                        assault = {["ent_ammo_.45acp"] = 180, ["ent_ammo_.45acp"] = 30},
                        support = {["ent_ammo_7.62x51mm"] = 300, ["ent_ammo_.45acp"] = 50},
                        sniper = {["ent_ammo_7.62x51mm"] = 60, ["ent_ammo_.45acp"] = 60},
                        medic = {["ent_ammo_12/70gauge"] = 40, ["ent_ammo_.45acp"] = 50}
                    },
                    [TEAM_BRAVO] = { -- Germany ammo
                        assault = {["ent_ammo_9x19mmparabellum"] = 180, ["ent_ammo_9x19mmparabellum"] = 180},
                        support = {["ent_ammo_7.92x57mmmauser"] = 200, ["ent_ammo_9x19mmparabellum"] = 100},
                        sniper = {["ent_ammo_7.62x51mm"] = 60, ["ent_ammo_9x19mmparabellum"] = 30},
                        medic = {["ent_ammo_7.92x57mmmauser"] = 40, ["ent_ammo_9x19mmparabellum"] = 50}
                    }
                },
                attachmentLoadouts = {
                    [TEAM_ALPHA] = { -- America attachments
                        sniper = {"optic12"}
                    },
                    [TEAM_BRAVO] = { -- Germany attachments
                        sniper = {"optic12"}
                    }
                }
            }
        }
    },
    modern = {
        name = "Modern Warfare",
        period = "21-й век",
        description = "Современные армии и высокоточное оружие",
        icon = "icon16/lightning.png",
        order = 5,
        subconflicts = {
            nato = {
                name = "NATO vs Russia", 
                description = "Full scale modern conflict",
                maps = {"gm_terminal_v1a","mp_pipeline"},
                teams = {
                    [TEAM_ALPHA] = {name = "NATO", models = {
                        assault = {"models/player/suno/spyper/us_engineer.mdl"},
                        support = {"models/player/suno/spyper/us_engineer.mdl"},
                        sniper = {"models/player/suno/spyper/us_engineer.mdl"},
                        medic = {"models/player/suno/spyper/us_engineer.mdl"}
                    }},
                    [TEAM_BRAVO] = {name = "Russia", models = {
                        assault = {"models/kuma96/codmw/characters/allegiancedef/allegiancedef_pm.mdl"},
                        support = {"models/kuma96/codmw/characters/allegiancedef/allegiancedef_pm.mdl"},
                        sniper = {"models/kuma96/codmw/characters/allegiancedef/allegiancedef_pm.mdl"},
                        medic = {"models/kuma96/codmw/characters/allegiancedef/allegiancedef_pm.mdl"}
                    }}
                },
                weaponLoadouts = {
                    [TEAM_ALPHA] = { -- NATO Army
                        assault = {"weapon_hk416", "weapon_p22", "weapon_buck200knife", "weapon_hg_grenade_tpik","weapon_medkit_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        support = {"weapon_hk11lmg", "weapon_p22", "weapon_buck200knife", "weapon_hg_smokenade_tpik","weapon_medkit_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        sniper = {"weapon_sr25", "weapon_p22", "weapon_buck200knife","weapon_medkit_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        medic = {"weapon_mp5", "weapon_p22", "weapon_medkit_inf_sh", "weapon_warses_defib", "weapon_buck200knife","weapon_bigbandage_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"}
                    },
                    [TEAM_BRAVO] = { -- Russia
                        assault = {"weapon_ak200", "weapon_pl15", "weapon_buck200knife", "weapon_hg_rgd_tpik","weapon_medkit_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        support = {"weapon_pkm", "weapon_pl15", "weapon_buck200knife", "weapon_hg_smokenade_tpik","weapon_medkit_sh", "weapon_hg_molotov_tpik", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        sniper = {"weapon_svds", "weapon_pl15", "weapon_buck200knife","weapon_medkit_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        medic = {"weapon_asval", "weapon_pl15", "weapon_medkit_inf_sh", "weapon_warses_defib", "weapon_buck200knife","weapon_bigbandage_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh"}
                    }
                },
                ammoLoadouts = {
                    [TEAM_ALPHA] = { -- NATO Army ammo
                        assault = {["ent_ammo_5.56x45mm"] = 180, ["ent_ammo_.22longrifle"] = 50},
                        support = {["ent_ammo_7.62x51mm"] = 300, ["ent_ammo_.22longrifle"] = 50},
                        sniper = {["ent_ammo_7.62x51mm"] = 60, ["ent_ammo_.22longrifle"] = 50},
                        medic = {["ent_ammo_9x19mmparabellum"] = 180, ["ent_ammo_.22longrifle"] = 50}
                    },
                    [TEAM_BRAVO] = { -- Russia ammo
                        assault = {["ent_ammo_5.45x39mm"] = 180, ["ent_ammo_9x19mmparabellum"] = 50},
                        support = {["ent_ammo_7.62x54mm"] = 300, ["ent_ammo_9x19mmparabellum"] = 50},
                        sniper = {["ent_ammo_7.62x54mm"] = 60, ["ent_ammo_9x19mmparabellum"] = 50},
                        medic = {["ent_ammo_9x39mm"] = 180, ["ent_ammo_9x19mmparabellum"] = 50}
                    }
                },
                attachmentLoadouts = {
                    [TEAM_ALPHA] = { -- NATO Army attachments
                        sniper = {"optic6"}
                    },
                    [TEAM_BRAVO] = { -- Russia attachments
                        sniper = {"optic4"}
                    }
                }
            }
        }
    },
    civilwar = {
        name = "Civil War",
        period = "1861 — 1865",
        description = "Мушкеты, штыки и кавалерия",
        icon = "icon16/flag_blue.png",
        order = 1,
        subconflicts = {
            main = {
                name = "American Civil War",
                description = "Muskets, cannons and cavalry",
                maps = {"acw_starfort_b2"},
                teams = {
                    [TEAM_ALPHA] = {
                        name = "Union",
                        models = {
                            cavalry = {"models/jiffy/pms/unioncav/male_09.mdl"},
                            cw_rifleman = {"models/jiffy/pms/unionart/male_09.mdl"},
                            cw_captain = {"models/jiffy/pms/unioninfoff/male_08.mdl", "models/jiffy/pms/unioninfoff/male_03.mdl"}
                        }
                    },
                    [TEAM_BRAVO] = {
                        name = "Confederacy",
                        models = {
                            cavalry = {"models/jiffy/pms/csaart/male_07.mdl"},
                            cw_rifleman = {"models/jiffy/pms/csacav/male_04.mdl"},
                            cw_captain = {"models/jiffy/pms/csaoff/male_08.mdl", "models/jiffy/pms/csaoff/male_02.mdl"}
                        }
                    }
                },
                weaponLoadouts = {
                    [TEAM_ALPHA] = {
                        cavalry = {"weapon_hg_spear_knife", "weapon_hands_sh"},
                        cw_rifleman = {"weapon_musket", "weapon_hands_sh"},
                        cw_captain = {"weapon_buck200knife", "weapon_flintlock", "weapon_hands_sh"}
                    },
                    [TEAM_BRAVO] = {
                        cavalry = {"weapon_hg_spear_knife", "weapon_hands_sh"},
                        cw_rifleman = {"weapon_musket", "weapon_hands_sh"},
                        cw_captain = {"weapon_buck200knife", "weapon_flintlock", "weapon_hands_sh"}
                    }
                },
                ammoLoadouts = {
                    [TEAM_ALPHA] = {
                        cw_rifleman = {["ent_ammo_metallicball"] = 40},
                        cw_captain = {["ent_ammo_metallicball"] = 20}
                    },
                    [TEAM_BRAVO] = {
                        cw_rifleman = {["ent_ammo_metallicball"] = 40},
                        cw_captain = {["ent_ammo_metallicball"] = 20}
                    }
                },
                availableClasses = {"cavalry", "cw_rifleman", "cw_captain"}
            }
        }
    },
    halflife = {
        name = "Half-Life Conflict",
        period = "Альт. реальность",
        description = "Сопротивление против Альянса",
        icon = "icon16/asterisk_orange.png",
        order = 6,
        subconflicts = {
            xen = {
                name = "Xen Invasion",
                description = "Fight with Half-Life 2 weapons",
                maps = {"gm_occupants"},
                teams = {
                    [TEAM_ALPHA] = {
                        name = "Resistance", 
                        availableClasses = {"assault", "support", "sniper", "medic"},
                        models = {
                            assault = {"models/player/Group03/male_01.mdl", "models/player/Group03/female_01.mdl"},
                            support = {"models/player/Group03/male_03.mdl", "models/player/Group03/female_03.mdl"},
                            sniper = {"models/player/Group03/male_05.mdl", "models/player/Group03/female_04.mdl"},
                            medic = {"models/player/Group03/male_07.mdl", "models/player/Group03/female_02.mdl"}
                        }
                    },
                    [TEAM_BRAVO] = {
                        name = "Combine",
                        availableClasses = {"hl_metrocop", "hl_combine_soldier", "hl_combine_elite", "hl_combine_medic"},
                        models = {
                            hl_metrocop = {"models/player/police.mdl"},
                            hl_combine_soldier = {"models/player/combine_soldier.mdl"},
                            hl_combine_elite = {"models/player/combine_super_soldier.mdl"},
                            hl_combine_medic = {"models/player/combine_soldier_prisonguard.mdl"}
                        }
                    }
                },
                weaponLoadouts = {
                    [TEAM_ALPHA] = {
                        assault = {"weapon_akmwreked", "weapon_makarov", "weapon_hg_hl2nade_tpik", "weapon_hands_sh", "weapon_medkit_sh", "weapon_walkie_talkie_alpha"},
                        support = {"weapon_mp7", "weapon_makarov", "weapon_hg_hl2nade_tpik", "weapon_hands_sh", "weapon_medkit_sh", "weapon_walkie_talkie_alpha"},
                        sniper = {"weapon_hg_crossbow", "weapon_makarov", "weapon_hands_sh", "weapon_medkit_sh", "weapon_walkie_talkie_alpha"},
                        medic = {"weapon_remington870", "weapon_makarov", "weapon_medkit_inf_sh", "weapon_warses_defib", "weapon_hands_sh", "weapon_walkie_talkie_alpha"}
                    },
                    [TEAM_BRAVO] = {
                        hl_metrocop = {"weapon_mp7", "weapon_hk_usp", "weapon_hg_stunstick", "weapon_hg_hl2nade_tpik", "weapon_hands_sh", "weapon_medkit_sh", "weapon_walkie_talkie_bravo"},
                        hl_combine_soldier = {"weapon_osipr", "weapon_hk_usp", "weapon_hg_hl2nade_tpik", "weapon_hands_sh", "weapon_medkit_sh", "weapon_walkie_talkie_bravo"},
                        hl_combine_elite = {"weapon_combinesniper", "weapon_hk_usp", "weapon_hg_hl2nade_tpik", "weapon_hands_sh", "weapon_medkit_sh", "weapon_walkie_talkie_bravo"},
                        hl_combine_medic = {"weapon_spas12", "weapon_hk_usp", "weapon_medkit_inf_sh", "weapon_warses_defib", "weapon_hands_sh", "weapon_walkie_talkie_bravo"}
                    }
                },
                ammoLoadouts = {
                    [TEAM_ALPHA] = {
                        assault = {["ent_ammo_7.62x39mm"] = 180, ["ent_ammo_9x18mm"] = 100},
                        support = {["ent_ammo_4.6x30mm"] = 120, ["ent_ammo_9x18mm"] = 100},
                        sniper = {["ent_ammo_armature"] = 20, ["ent_ammo_9x18mm"] = 100},
                        medic = {["ent_ammo_12/70gauge"] = 40, ["ent_ammo_9x18mm"] = 100}
                    },
                    [TEAM_BRAVO] = {
                        hl_metrocop = {["ent_ammo_4.6x30mm"] = 180, ["ent_ammo_9x19mmparabellum"] = 100},
                        hl_combine_soldier = {["ent_ammo_pulse"] = 120, ["ent_ammo_9x19mmparabellum"] = 100},
                        hl_combine_elite = {["ent_ammo_pulse"] = 50, ["ent_ammo_9x19mmparabellum"] = 100},
                        hl_combine_medic = {["ent_ammo_12/70gauge"] = 40, ["ent_ammo_9x19mmparabellum"] = 100}
                    }
                }
            }
        }
    },
    levant = {
        name = "Gaza Conflict",
        period = "1948 — настоящее время",
        description = "Затяжной ближневосточный конфликт",
        icon = "icon16/flag_yellow.png",
        order = 7,
        subconflicts = {
            gaza = {
                name = "Operations in Gaza",
                description = "Urban warfare between IDF and Palestinian fighters",
                maps = {"usa_gaza_genocide", "rp_operation_castlead"},
                teams = {
                    [TEAM_ALPHA] = {name = "Israel", models = {
                        assault = {"models/ftteam/caxal_soldier/soldier.mdl"},
                        support = {"models/ftteam/caxal_soldier/soldier.mdl"},
                        sniper = {"models/ftteam/caxal_soldier/soldier.mdl"},
                        medic = {"models/ftteam/caxal_soldier/soldier.mdl"}
                    }},
                    [TEAM_BRAVO] = {name = "Palestine", models = {
                        assault = {"models/playermodel/alqaeda_commandomp_mp.mdl"},
                        support = {"models/playermodel/taliban_rpg_rpg.mdl"},
                        sniper = {"models/playermodel/osama_bin_laden.mdl"},
                        medic = {"models/playermodel/taliban_gruntmp.mdl"}
                    }}
                },
                weaponLoadouts = {
                    [TEAM_ALPHA] = { -- Israel (IDF)
                        assault = {"weapon_mk18", "weapon_glock17", "weapon_buck200knife", "weapon_hg_grenade_tpik", "weapon_medkit_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        support = {"weapon_m249", "weapon_glock17", "weapon_buck200knife", "weapon_hg_smokenade_tpik", "weapon_medkit_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        sniper  = {"weapon_m14dmr", "weapon_glock17", "weapon_buck200knife", "weapon_medkit_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        medic   = {"weapon_miniuzi", "weapon_glock17", "weapon_medkit_inf_sh", "weapon_warses_defib", "weapon_buck200knife", "weapon_bigbandage_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"}
                    },
                    [TEAM_BRAVO] = { -- Palestine
                        assault = {"weapon_akm", "weapon_makarov", "weapon_buck200knife", "weapon_hg_rgd_tpik", "weapon_medkit_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        support = {"weapon_hg_rpg", "weapon_makarov", "weapon_buck200knife", "weapon_hg_molotov_tpik", "weapon_medkit_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        sniper  = {"weapon_svd", "weapon_makarov", "weapon_buck200knife", "weapon_medkit_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        medic   = {"weapon_ak74u", "weapon_makarov", "weapon_medkit_inf_sh", "weapon_warses_defib", "weapon_buck200knife", "weapon_bigbandage_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh"}
                    }
                },
                ammoLoadouts = {
                    [TEAM_ALPHA] = { -- Israel ammo
                        assault = {["ent_ammo_5.56x45mm"] = 180, ["ent_ammo_9x19mmparabellum"] = 50},
                        support = {["ent_ammo_5.56x45mm"] = 300, ["ent_ammo_9x19mmparabellum"] = 50},
                        sniper  = {["ent_ammo_7.62x51mm"] = 60,  ["ent_ammo_9x19mmparabellum"] = 30},
                        medic   = {["ent_ammo_9x19mmparabellum"] = 180}
                    },
                    [TEAM_BRAVO] = { -- Palestine ammo
                        assault = {["ent_ammo_7.62x39mm"] = 180, ["ent_ammo_9x18mm"] = 50},
                        support = {["ent_ammo_rpg-7projectile"] = 3, ["ent_ammo_9x18mm"] = 50},
                        sniper  = {["ent_ammo_7.62x54mm"] = 60,  ["ent_ammo_9x18mm"] = 30},
                        medic   = {["ent_ammo_5.45x39mm"] = 180, ["ent_ammo_9x18mm"] = 50}
                    }
                },
                attachmentLoadouts = {
                    [TEAM_ALPHA] = { -- Israel attachments
                        sniper = {"optic6"}
                    },
                    [TEAM_BRAVO] = { -- Palestine attachments
                        sniper = {"optic4"}
                    }
                }
            }
        }
    },

    iraq = {
        name = "Iraq War",
        period = "2003 — 2011",
        description = "вторжение США, которое привело к многолетнему хаосу и терроризму",
        icon = "icon16/flag_orange.png",
        order = 8,
        subconflicts = {
            oif = {
                name = "Operation Iraqi Freedom",
                description = "Война под палящим солнцем",
                maps = {
                    "iraq_border",
                    "iraq",
                },
                teams = {
                    [TEAM_ALPHA] = {
                        name = "USA",
                        models = {
                            assault = {"models/player/4ervo/generic_camo_unit.mdl"},
                            support = {"models/player/4ervo/generic_camo_unit.mdl"},
                            sniper  = {"models/player/4ervo/generic_camo_unit.mdl"},
                            medic   = {"models/player/4ervo/generic_camo_unit.mdl"},
                        }
                    },
                    [TEAM_BRAVO] = {
                        name = "Iraqi Forces",
                        models = {
                            assault = {"models/playermodel/taliban_gruntmp.mdl"},
                            support = {"models/playermodel/taliban_rpg_rpg.mdl"},
                            sniper  = {"models/playermodel/taliban_bombermp.mdl" },
                            medic   = {"models/playermodel/alqaeda_commandomp_mp.mdl"},
                        }
                    }
                },
                weaponLoadouts = {
                    [TEAM_ALPHA] = {
                        assault = {
                            "weapon_scarl",
                            "weapon_m45",
                            "weapon_buck200knife",
                            "weapon_hg_grenade_tpik",
                            "weapon_medkit_sh",
                            "weapon_walkie_talkie_alpha",
                            "weapon_hands_sh",
                        },
                        support = { 
                            "weapon_m249",
                            "weapon_m45",
                            "weapon_buck200knife",
                            "weapon_hg_grenade_tpik",
                            "weapon_medkit_sh",
                            "weapon_walkie_talkie_alpha",
                            "weapon_hands_sh",
                        },
                        sniper  = { 
                            "weapon_m24remington",
                            "weapon_m45",
                            "weapon_buck200knife",
                            "weapon_hg_grenade_tpik",
                            "weapon_medkit_sh",
                            "weapon_walkie_talkie_alpha",
                            "weapon_hands_sh",
                        },
                        medic   = {                         
                            "weapon_maverickshot",
                            "weapon_m45",
                            "weapon_buck200knife",
                            "weapon_hg_grenade_tpik",
                            "weapon_medkit_sh",
                            "weapon_warses_defib",
                            "weapon_walkie_talkie_alpha",
                            "weapon_hands_sh",
                        },
                    },
                    [TEAM_BRAVO] = {
                        assault = {                        
                            "weapon_akm",
                            "weapon_makarov",
                            "weapon_buck200knife",
                            "weapon_hg_grenade_tpik",
                            "weapon_medkit_sh",
                            "weapon_walkie_talkie_bravo",
                            "weapon_hands_sh",
                        },
                        support = {                          
                            "weapon_m320gl",
                            "weapon_makarov",
                            "weapon_buck200knife",
                            "weapon_hg_grenade_tpik",
                            "weapon_medkit_sh",
                            "weapon_walkie_talkie_bravo",
                            "weapon_hands_sh",
                        },
                        sniper  = {                            
                            "weapon_sks",
                            "weapon_makarov",
                            "weapon_buck200knife",
                            "weapon_hg_grenade_tpik",
                            "weapon_medkit_sh",
                            "weapon_walkie_talkie_bravo",
                            "weapon_hands_sh",
                        },
                        medic   = {                            
                            "weapon_mac11",
                            "weapon_makarov",
                            "weapon_buck200knife",
                            "weapon_hg_grenade_tpik",
                            "weapon_medkit_sh",
                            "weapon_warses_defib",
                            "weapon_walkie_talkie_bravo",
                            "weapon_hands_sh",
                        },
                    }
                },
                ammoLoadouts = {
                    [TEAM_ALPHA] = {
                        assault = {["ent_ammo_5.56x45mm"] = 180, ["ent_ammo_.45acp"] = 50},
                        support = {["ent_ammo_5.56x45mm"] = 300, ["ent_ammo_.45acp"] = 50},
                        sniper  = {["ent_ammo_7.62x51mm"] = 50, ["ent_ammo_.45acp"] = 50}, 
                        medic   = {["ent_ammo_12/70gauge"] = 50, ["ent_ammo_.45acp"] = 50},
                    },
                    [TEAM_BRAVO] = {
                        assault = {["ent_ammo_5.56x45mm"] = 180, ["ent_ammo_9x18mm"] = 50},
                        support = {["ent_ammo_grenade40mm"] = 6, ["ent_ammo_9x18mm"] = 50},
                        sniper  = {["ent_ammo_7.62x39mm"] = 50, ["ent_ammo_9x18mm"] = 50}, 
                        medic   = {["ent_ammo_9x19mmparabellum"] = 120, ["ent_ammo_9x18mm"] = 50},
                    }
                },
                attachmentLoadouts = {
                    [TEAM_ALPHA] = {
                        sniper = {"optic12"},
                    },
                    [TEAM_BRAVO] = {
                        sniper = {"optic4"},
                    }
                }
            }
        }
    },
--[[    spacewar = {
        name = "Space War",
        period = "Будущее",
        description = "Сражения в невесомости в открытом космосе",
        icon = "icon16/world.png",
        order = 6,
        subconflicts = {
            orbital = {
                name = "Orbital Conflict",
                description = "Zero-gravity combat in deep space",
                maps = {"gm_space", "gm_space_arena", "gm_zero_g", "rp_orbital_station"},
                zeroGravity = true,
                teams = {
                    [TEAM_ALPHA] = {name = "Earth Federation", models = {
                        assault = {"models/player/suno/spyper/us_engineer.mdl"},
                        support = {"models/player/suno/spyper/us_engineer.mdl"},
                        sniper = {"models/player/suno/spyper/us_engineer.mdl"},
                        medic = {"models/player/suno/spyper/us_engineer.mdl"}
                    }},
                    [TEAM_BRAVO] = {name = "Mars Republic", models = {
                        assault = {"models/kuma96/codmw/characters/allegiancedef/allegiancedef_pm.mdl"},
                        support = {"models/kuma96/codmw/characters/allegiancedef/allegiancedef_pm.mdl"},
                        sniper = {"models/kuma96/codmw/characters/allegiancedef/allegiancedef_pm.mdl"},
                        medic = {"models/kuma96/codmw/characters/allegiancedef/allegiancedef_pm.mdl"}
                    }}
                },
                weaponLoadouts = {
                    [TEAM_ALPHA] = { -- Earth Federation
                        assault = {"weapon_hk416", "weapon_p22", "weapon_buck200knife", "weapon_hg_grenade_tpik","weapon_medkit_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        support = {"weapon_hk21", "weapon_p22", "weapon_buck200knife", "weapon_hg_smokenade_tpik","weapon_medkit_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        sniper = {"weapon_sr25", "weapon_p22", "weapon_buck200knife","weapon_medkit_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"},
                        medic = {"weapon_mp5", "weapon_p22", "weapon_medkit_inf_sh", "weapon_warses_defib", "weapon_buck200knife","weapon_bigbandage_sh", "weapon_walkie_talkie_alpha", "weapon_hands_sh"}
                    },
                    [TEAM_BRAVO] = { -- Mars Republic
                        assault = {"weapon_ak200", "weapon_pl15", "weapon_buck200knife", "weapon_hg_rgd_tpik","weapon_medkit_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        support = {"weapon_pkm", "weapon_pl15", "weapon_buck200knife", "weapon_hg_smokenade_tpik","weapon_medkit_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        sniper = {"weapon_svds", "weapon_pl15", "weapon_buck200knife","weapon_medkit_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh"},
                        medic = {"weapon_asval", "weapon_pl15", "weapon_medkit_inf_sh", "weapon_warses_defib", "weapon_buck200knife","weapon_bigbandage_sh", "weapon_walkie_talkie_bravo", "weapon_hands_sh"}
                    }
                },
                ammoLoadouts = {
                    [TEAM_ALPHA] = { -- Earth Federation ammo
                        assault = {["ent_ammo_5.56x45mm"] = 180, ["ent_ammo_.22longrifle"] = 50},
                        support = {["ent_ammo_7.62x51mm"] = 300, ["ent_ammo_.22longrifle"] = 50},
                        sniper = {["ent_ammo_7.62x51mm"] = 60, ["ent_ammo_.22longrifle"] = 50},
                        medic = {["ent_ammo_9x19mmparabellum"] = 180, ["ent_ammo_.22longrifle"] = 50}
                    },
                    [TEAM_BRAVO] = { -- Mars Republic ammo
                        assault = {["ent_ammo_5.45x39mm"] = 180, ["ent_ammo_9x19mmparabellum"] = 50},
                        support = {["ent_ammo_7.62x54mm"] = 300, ["ent_ammo_9x19mmparabellum"] = 50},
                        sniper = {["ent_ammo_7.62x54mm"] = 60, ["ent_ammo_9x19mmparabellum"] = 50},
                        medic = {["ent_ammo_9x39mm"] = 180, ["ent_ammo_9x19mmparabellum"] = 50}
                    }
                }
            }
        }
    }
]]--
}

function GM:IsZeroGravityConflict()
    local conflict = self.Conflicts[self.CurrentConflict]
    if not conflict then return false end
    local sub = conflict.subconflicts[self.CurrentSubconflict]
    if not sub then return false end
    return sub.zeroGravity == true
end

GM.Classes = {
    assault = {
        name = "Assault",
        description = "Front-line soldier with balanced loadout",
        icon = "icon16/user.png",
        weapons = {"weapon_smg1", "weapon_pistol", "weapon_crowbar", "weapon_frag"},
        ammo = {
            ["SMG1"] = 180,
            ["Pistol"] = 100
        },
        model = "models/player/combine_soldier.mdl",
        health = 100,
        armor = 25,
        att_slots = nil,
        max_players = nil
    },
    support = {
        name = "Support",
        description = "Heavy weapons specialist",
        icon = "icon16/shield.png",
        weapons = {"weapon_ar2", "weapon_pistol", "weapon_crowbar"},
        ammo = {
            ["AR2"] = 120,
            ["Pistol"] = 100
        },
        model = "models/player/combine_soldier_prisonguard.mdl",
        health = 125,
        armor = 50,
        att_slots = 2,
        max_players = 3
    },
    sniper = {
        name = "Sniper",
        description = "Long-range precision",
        icon = "icon16/eye.png",
        weapons = {"weapon_crossbow", "weapon_pistol"},
        ammo = {
            ["XBowBolt"] = 20,
            ["Pistol"] = 50
        },
        model = "models/player/combine_super_soldier.mdl",
        health = 75,
        armor = 0,
        att_slots = 2,
        max_players = 2
    },
    medic = {
        name = "Medic",
        description = "Heals teammates",
        icon = "icon16/heart.png",
        weapons = {"weapon_smg1", "weapon_pistol", "weapon_crowbar"},
        ammo = {
            ["SMG1"] = 120,
            ["Pistol"] = 100
        },
        model = "models/player/police.mdl",
        health = 100,
        armor = 0,
        canHeal = true,
        att_slots = 5,
        max_players = 4 
    },

    cavalry = {
        name = "Cavalier",
        description = "Ближний бой верхом или в тылу",
        icon = "icon16/user_suit.png",
        weapons = {"weapon_hg_spear_knife", "weapon_fists"},
        model = "models/humans/civilwar/male_01.mdl",
        health = 100,
        armor = 0,
        max_players = nil
    },
    cw_rifleman = {
        name = "RifleMan",
        description = "Основная пехота с мушкетом",
        icon = "icon16/user_gray.png",
        weapons = {"weapon_musket", "weapon_fists"},
        model = "models/humans/civilwar/male_02.mdl",
        health = 100,
        armor = 0,
        max_players = 6
    },
    cw_captain = {
        name = "Capitan",
        description = "Командир с пистолем и кортиком",
        icon = "icon16/user_orange.png",
        weapons = {"weapon_flintlock", "weapon_buck200knife", "weapon_fists"},
        model = "models/humans/civilwar/male_03.mdl",
        health = 110,
        armor = 10,
        max_players = 3
    },

    rcw_rifleshot = {
        name = "Rifleshot",
        description = "Стрелок с винтовкой, основа пехоты",
        icon = "icon16/user_gray.png",
        weapons = {"weapon_mosin", "weapon_fists"},
        model = "models/ro1soviet_rifleman2pm.mdl",
        health = 100,
        armor = 0,
        max_players = nil
    },
    rcw_medic = {
        name = "Medic",
        description = "Полевой врач гражданской войны",
        icon = "icon16/heart.png",
        weapons = {"weapon_mosin", "weapon_fists"},
        model = "models/ro1soviet_rifleman6pm.mdl",
        health = 100,
        armor = 0,
        canHeal = true,
        max_players = 4
    },
    rcw_sniper = {
        name = "Sniper",
        description = "Меткий стрелок с оптикой",
        icon = "icon16/eye.png",
        weapons = {"weapon_mosin", "weapon_fists"},
        model = "models/ro1soviet_rifleman5pm.mdl",
        health = 80,
        armor = 0,
        att_slots = 2,
        max_players = 2
    },

    hl_metrocop = {
        name = "Метрокоп",
        description = "Сотрудник Гражданской Обороны",
        icon = "icon16/shield.png",
        weapons = {"weapon_smg1", "weapon_pistol", "weapon_stunstick", "weapon_frag"},
        ammo = { ["SMG1"] = 180, ["Pistol"] = 100, ["Grenade"] = 2 },
        model = "models/player/police.mdl",
        health = 100,
        armor = 25,
        max_players = nil
    },
    hl_combine_soldier = {
        name = "Комбайн",
        description = "Стандартная пехота Альянса",
        icon = "icon16/user.png",
        weapons = {"weapon_ar2", "weapon_smg1", "weapon_frag"},
        ammo = { ["AR2"] = 120, ["SMG1"] = 120, ["Grenade"] = 3 },
        model = "models/player/combine_soldier.mdl",
        health = 125,
        armor = 50,
        max_players = 6
    },
    hl_combine_elite = {
        name = "Элита",
        description = "Элитный боец Overwatch",
        icon = "icon16/star.png",
        weapons = {"weapon_ar2", "weapon_shotgun", "weapon_frag"},
        ammo = { ["AR2"] = 150, ["Buckshot"] = 40, ["Grenade"] = 5 },
        model = "models/player/combine_super_soldier.mdl",
        health = 150,
        armor = 75,
        max_players = 2
    },
    hl_combine_medic = {
        name = "Медик",
        description = "Полевой врач Альянса",
        icon = "icon16/heart.png",
        weapons = {"weapon_smg1", "weapon_pistol", "weapon_medkit_sh"},
        ammo = { ["SMG1"] = 150, ["Pistol"] = 100 },
        model = "models/player/combine_soldier_prisonguard.mdl",
        health = 100,
        armor = 25,
        canHeal = true,
        max_players = 4
    },

    zombie = {
        name = "Зомби",
        description = "Восставший мертвец, голод и ярость",
        icon = "icon16/user_red.png",
        weapons = {"weapon_hands_sh"},
        ammo = {},
        model = "models/half-dead/red orchestra 2/GER/ZombieHero.mdl",

        zombie_models = {
            "models/half-dead/red orchestra 2/GER/ZombieHero.mdl",
            "models/half-dead/red orchestra 2/GER/ZombieWinter.mdl",
        },
        health = 150,
        armor = 0,
        att_slots = 0,
        max_players = nil
    }
}

-- Game settings
CreateConVar("warses_respawn_time", "8", {FCVAR_REPLICATED, FCVAR_ARCHIVE})
CreateConVar("warses_capture_time", "10", {FCVAR_REPLICATED, FCVAR_ARCHIVE})
CreateConVar("warses_friendly_fire", "0", {FCVAR_REPLICATED, FCVAR_ARCHIVE})

CreateConVar("warses_dm_winscore", "250", {FCVAR_REPLICATED, FCVAR_ARCHIVE}) -- сколько очков нужно для победы
CreateConVar("warses_dm_killpoints", "5", {FCVAR_REPLICATED, FCVAR_ARCHIVE}) -- очков команде за убийство врага
CreateConVar("warses_dm_deathpenalty", "1", {FCVAR_REPLICATED, FCVAR_ARCHIVE}) -- штраф своей команде за смерть

Warses_CV_Respawn       = GetConVar("warses_respawn_time")
Warses_CV_CaptureTime   = GetConVar("warses_capture_time")
Warses_CV_FriendlyFire  = GetConVar("warses_friendly_fire")
Warses_CV_DMWinScore    = GetConVar("warses_dm_winscore")
Warses_CV_DMKillPoints  = GetConVar("warses_dm_killpoints")
Warses_CV_DMDeathPenalty = GetConVar("warses_dm_deathpenalty")

GM.RespawnTime = Warses_CV_Respawn:GetInt()
GM.CaptureTime = Warses_CV_CaptureTime:GetInt()
GM.MinPlayersToStart = 2
GM.FriendlyFire = Warses_CV_FriendlyFire:GetBool()

GM.CurrentConflict = "coldwar"
GM.CurrentSubconflict = "vietnam"

function GM:GetAvailableClasses(teamID)
    if not teamID then
        if CLIENT then
            teamID = LocalPlayer():Team()
        else

        end
    end

    local conflict = self.Conflicts[self.CurrentConflict]
    if not conflict then return self.Classes end
    
    local subconflict = conflict.subconflicts[self.CurrentSubconflict]
    if not subconflict then return self.Classes end

    if teamID and subconflict.teams and subconflict.teams[teamID] and subconflict.teams[teamID].availableClasses then
        local classes = {}
        for _, classID in ipairs(subconflict.teams[teamID].availableClasses) do
            if self.Classes[classID] then
                classes[classID] = self.Classes[classID]
            end
        end
        return classes
    end
    
    if subconflict.availableClasses then
        local classes = {}
        for _, classID in ipairs(subconflict.availableClasses) do
            if self.Classes[classID] then
                classes[classID] = self.Classes[classID]
            end
        end
        return classes
    end
    
    local classes = {}
    local specialClasses = {
        cavalry = true, cw_rifleman = true, cw_captain = true,
        rcw_rifleshot = true, rcw_medic = true, rcw_sniper = true,
        hl_metrocop = true, hl_combine_soldier = true, hl_combine_elite = true, hl_combine_medic = true,
        zombie = true
    }
    
    for k, v in pairs(self.Classes) do
        if not specialClasses[k] then
            classes[k] = v
        end
    end
    return classes
end

function GM:GetWeaponVariants(teamID, classID)
    local conflict = self.Conflicts[self.CurrentConflict]
    if not conflict then return nil end
    local sub = conflict.subconflicts[self.CurrentSubconflict]
    if not sub or not sub.weaponVariants then return nil end
    local teamVar = sub.weaponVariants[teamID]
    if not teamVar then return nil end
    local classVar = teamVar[classID]
    if not classVar then return nil end
    local hasChoice = false
    if classVar.primary   and #classVar.primary   > 1 then hasChoice = true end
    if classVar.secondary and #classVar.secondary > 1 then hasChoice = true end
    if not hasChoice then return nil end
    return classVar
end

function GM:FindWeaponVariant(teamID, classID, slot, wepClass)
    local variants = self:GetWeaponVariants(teamID, classID)
    if not variants or not variants[slot] then return nil end
    for _, v in ipairs(variants[slot]) do
        if v.wep == wepClass then return v end
    end
    return nil
end

function GM:GetTeamInfo(teamID)
    local conflict = self.Conflicts[self.CurrentConflict]
    if not conflict then return nil end
    
    local subconflict = conflict.subconflicts[self.CurrentSubconflict]
    if not subconflict then return nil end
    
    return subconflict.teams[teamID]
end

function GM:DetectConflictByMap()
    local currentMap = string.lower(game.GetMap())
    print("[Warses] DetectConflictByMap → current map = '" .. currentMap .. "'")

    for conflictID, conflict in pairs(self.Conflicts) do

        if istable(conflict) and istable(conflict.subconflicts) then
            for subconflictID, subconflict in pairs(conflict.subconflicts) do
                if istable(subconflict) and subconflict.maps then
                    for _, mapName in ipairs(subconflict.maps) do
                        if string.lower(mapName) == currentMap then
                            self.CurrentConflict = conflictID
                            self.CurrentSubconflict = subconflictID
                            print("[Warses] Detected conflict: " .. tostring(subconflict.name) .. " (Map: " .. currentMap .. ")")
                            return
                        end
                    end
                end
            end
        else
            print("[Warses] ВНИМАНИЕ: конфликт '" .. tostring(conflictID) .. "' без таблицы subconflicts — пропущен")
        end
    end

    self.CurrentConflict = "halflife"
    self.CurrentSubconflict = "xen"
    print("[Warses] Map '" .. currentMap .. "' not found in any conflict, defaulting to Half-Life Conflict")
end
