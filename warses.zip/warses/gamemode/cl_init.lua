include("shared.lua")
include("sh_vip.lua")
include("cl_squadmenu.lua")
include("cl_teammenu.lua")
include("cl_classmenu.lua")
include("cl_hud.lua")
include("cl_scoreboard.lua")
include("cl_mapvote.lua")
include("cl_adminmenu.lua")
include("cl_zombie.lua")
include("cl_markers.lua")
include("cl_comeback.lua")
include("cl_spectator.lua")
include("sh_safevehicle.lua")

LocalPlayerState = {
    team = nil,
    class = nil,
    respawnTime = 0
}

net.Receive("Warses_SyncGameState", function()
    GAMEMODE.CurrentConflict = net.ReadString()
    GAMEMODE.CurrentSubconflict = net.ReadString()
    GAMEMODE.CurrentGameMode = net.ReadString()
end)

function GM:Initialize()
    self:DetectConflictByMap()
end

hook.Add("PlayerButtonDown", "Warses_Kamikaze_Key", function(ply, button)
    if button == KEY_T then
        if not IsFirstTimePredicted() then return end
        if not IsValid(ply) or ply ~= LocalPlayer() then return end

        if (gui.IsChatting and gui.IsChatting()) or gui.IsConsoleVisible() or vgui.CursorVisible() then return end

        if ply:GetNWString("Class") ~= "support" then
            ply:ChatPrint("Нужен класс Support (Поддержка) для дрона!")
            return
        end
        if GAMEMODE.CurrentConflict ~= "modern" or GAMEMODE.CurrentSubconflict ~= "nato" then
            ply:ChatPrint("Дроны доступны только в современных конфликтах!")
            return
        end

        net.Start("Warses_SpawnKamikaze")
        net.SendToServer()
    end
end)
