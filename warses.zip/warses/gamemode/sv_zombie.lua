util.AddNetworkString("Warses_ZombieIntro")
util.AddNetworkString("Warses_ZombieEnd")
util.AddNetworkString("Warses_ZombieLives")
util.AddNetworkString("Warses_ZombieSpawned")
util.AddNetworkString("Warses_ZombieConvert")
util.AddNetworkString("Warses_ZombieLoseLife")
util.AddNetworkString("Warses_ZombieFinalDeath")

util.PrecacheModel("models/half-dead/red orchestra 2/GER/ZombieHero.mdl")
util.PrecacheModel("models/half-dead/red orchestra 2/GER/ZombieWinter.mdl")

local ZOMBIE_LIVES_ORIGINAL = 3
local ZOMBIE_LIVES_CONVERTED = 1
local CUTSCENE_DURATION = 12
local CONVERT_DURATION = 10.0
local LOSELIFE_DURATION = 2.0
local FINAL_DEATH_DURATION = 17.0

GAMEMODE.ZombiePending = false
GAMEMODE.ZombieOriginalGermans = {}
GAMEMODE.ZombieLives = {}
GAMEMODE.ZombieActive = false
GAMEMODE.ZombieSoloMode = false

local function GetRole(ply)
    if not IsValid(ply) then return "spectator" end
    local t = ply:Team()
    if t == TEAM_BRAVO then return "zombie" end
    if t == TEAM_ALPHA then return "soviet" end
    return "spectator"
end

local function GetLives(ply)
    if not IsValid(ply) then return 0 end
    return GAMEMODE.ZombieLives[ply:SteamID()] or 0
end

local function SendSpawned(ply)
    if not IsValid(ply) then return end
    net.Start("Warses_ZombieSpawned")
    net.WriteInt(GetLives(ply), 8)
    net.WriteString(GetRole(ply))
    net.Send(ply)
end

local function EnterGhostMode(ply)
    if not IsValid(ply) then return end

    ply:UnSpectate()
    ply:Freeze(false)
    ply:StripWeapons()

    ply:SetNoDraw(true)
    ply:DrawShadow(false)
    if ply.DrawWorldModel then ply:DrawWorldModel(false) end
    ply:SetRenderMode(RENDERMODE_NONE)
    ply:SetColor(Color(255, 255, 255, 0))

    ply:SetSolidFlags(bit.bor(ply:GetSolidFlags(), FSOLID_NOT_SOLID, FSOLID_TRIGGER))
    ply:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)

    ply:SetMoveType(MOVETYPE_NOCLIP)

    local hMin = Vector(-1, -1, -1)
    local hMax = Vector(1, 1, 1)
    ply:SetHull(hMin, hMax)
    ply:SetHullDuck(hMin, hMax)

    ply:SetHealth(999)
    ply:GodEnable()
end

hook.Add("PlayerSpawn", "Warses_ZombieGhostSpawn", function(ply)
    if not GAMEMODE.ZombieActive then return end
    if not IsValid(ply) then return end
    if ply:Team() ~= TEAM_SPECTATOR then return end

    timer.Simple(0.05, function()
        if IsValid(ply) and ply:Team() == TEAM_SPECTATOR then
            EnterGhostMode(ply)
        end
    end)
end)

function Warses_CheckZombieTrigger(winningTeam)
    if GAMEMODE.ZombieActive or GAMEMODE.ZombiePending then return false end

    if string.lower(game.GetMap()) ~= string.lower(GAMEMODE.ZombieTriggerMap or "") then
        return false
    end

    if winningTeam ~= TEAM_ALPHA then return false end

    if math.random() > (GAMEMODE.ZombieTriggerChance or 0.35) then
        return false
    end

    GAMEMODE.ZombieOriginalGermans = {}
    local germans, soviets = 0, 0
    for _, ply in ipairs(player.GetAll()) do
        if ply:Team() == TEAM_BRAVO then
            GAMEMODE.ZombieOriginalGermans[ply:SteamID()] = true
            germans = germans + 1
        elseif ply:Team() == TEAM_ALPHA then
            soviets = soviets + 1
        end
    end

    if germans < 1 or soviets < 1 then
        GAMEMODE.ZombieOriginalGermans = {}
        return false
    end

    GAMEMODE.ZombiePending = true
    return true
end

function Warses_StartZombieCutscene()
    if not GAMEMODE.ZombiePending then return end
    GAMEMODE.ZombiePending = false

    print("[Warses] >>> ZOMBIE MODE TRIGGERED <<<")

    timer.Remove("MapVote_EndTimer")
    if MapVote then
        MapVote.Active = false
        MapVote.Phase = 0
    end
    SetGlobalBool("MapVote_Active", false)

    for _, ply in ipairs(player.GetAll()) do
        local role, lives
        if GAMEMODE.ZombieOriginalGermans[ply:SteamID()] then
            role  = "zombie"
            lives = ZOMBIE_LIVES_ORIGINAL
        elseif ply:Team() == TEAM_ALPHA then
            role  = "soviet"
            lives = 1
        elseif ply:Team() == TEAM_BRAVO then
            role  = "zombie"
            lives = ZOMBIE_LIVES_ORIGINAL
        else
            role  = "spectator"
            lives = 0
        end
        net.Start("Warses_ZombieIntro")
        net.WriteFloat(CUTSCENE_DURATION)
        net.WriteString(role)
        net.WriteInt(lives, 8)
        net.Send(ply)
    end

    timer.Create("Warses_ZombieStartGameplay", CUTSCENE_DURATION, 1, function()
        Warses_BeginZombieGameplay()
    end)
end

function Warses_BeginZombieGameplay()
    GAMEMODE.ZombieActive = true
    GAMEMODE.CurrentGameMode = "zombie"
    GAMEMODE.ZombieLives = {}

    Warses_SetGameOver(false)
    SetGlobalInt("AlphaScore", 0)
    SetGlobalInt("BravoScore", 0)
    SetGlobalInt("GameTime", 0)

    if not timer.Exists("Warses_ScoringLoop") then
        timer.Create("Warses_ScoringLoop", 1, 0, function()
            if Warses_IsGameOver() then return end
            SetGlobalInt("GameTime", GetGlobalInt("GameTime") + 1)
        end)
    end

    for _, ply in ipairs(player.GetAll()) do
        GAMEMODE:SyncGameState(ply)
    end

    for _, ply in ipairs(player.GetAll()) do
        if not IsValid(ply) then continue end
        if ply:Team() == TEAM_SPECTATOR then continue end

        local sid = ply:SteamID()
        local data = GAMEMODE.PlayerData[sid]
        if not data then continue end

        ply:Freeze(false)

        if GAMEMODE.ZombieOriginalGermans[sid] or ply:Team() == TEAM_BRAVO then
            data.team = TEAM_BRAVO
            data.class = "zombie"
            ply:SetTeam(TEAM_BRAVO)
            ply:SetNWString("Class", "zombie")
            GAMEMODE.ZombieLives[sid] = ZOMBIE_LIVES_ORIGINAL
        elseif ply:Team() == TEAM_ALPHA then
            if not data.class or data.class == "zombie" then
                data.class = "assault"
                ply:SetNWString("Class", "assault")
            end
            GAMEMODE.ZombieLives[sid] = 1
        end

        data.respawnTime = 0
        ply.WarsesNextSpawnTarget = nil
        if ply:Alive() then ply:KillSilent() end
        ply:Spawn()

        local pp = ply
        timer.Simple(0.2, function()
            if IsValid(pp) and pp:Alive() then SendSpawned(pp) end
        end)
    end

    PrintMessage(HUD_PRINTTALK, "*** Восстание мертвецов начинается! ***")

    timer.Simple(1, Warses_CheckZombieEnd)
end

local function HandleZombieDeath(victim)
    if not IsValid(victim) then return end
    if victim.ZombieFinalDying then return end

    local sid = victim:SteamID()
    local data = GAMEMODE.PlayerData[sid]
    if not data then return end

    victim.ZombieRespawnPos = victim:GetPos() + Vector(0, 0, 8)

    if victim:Team() == TEAM_ALPHA then
        data.team = TEAM_BRAVO
        data.class = "zombie"
        GAMEMODE.ZombieLives[sid] = ZOMBIE_LIVES_CONVERTED

        net.Start("Warses_ZombieConvert")
        net.Send(victim)

        timer.Simple(0.2, function()
            if not IsValid(victim) then return end
            victim:SetTeam(TEAM_BRAVO)
            victim:SetNWString("Class", "zombie")
        end)

        timer.Simple(CONVERT_DURATION, function()
            if not IsValid(victim) or not GAMEMODE.ZombieActive then return end
            victim:UnSpectate()
            victim:Spawn()
            timer.Simple(0.2, function()
                if IsValid(victim) and victim:Alive() then SendSpawned(victim) end
            end)
        end)

        victim:ChatPrint("Вы обращены в зомби!")

    elseif victim:Team() == TEAM_BRAVO then
        local left = (GAMEMODE.ZombieLives[sid] or 0) - 1
        GAMEMODE.ZombieLives[sid] = left

        if left <= 0 then
            local wasGerman = GAMEMODE.ZombieOriginalGermans[sid] and true or false
            local originalLives = wasGerman and ZOMBIE_LIVES_ORIGINAL or 1
            local dur = wasGerman and 17.0 or 13.0

            victim.ZombieFinalDying = true

            net.Start("Warses_ZombieFinalDeath")
            net.WriteInt(originalLives, 8)
            net.Send(victim)

            victim:ChatPrint("Все жизни потрачены...")

            local rag = victim:GetRagdollEntity()
            if IsValid(rag) then rag:Remove() end
            victim:Spectate(OBS_MODE_ROAMING)
            victim:SpectateEntity(NULL)
            victim:Freeze(true)
            victim:SetMoveType(MOVETYPE_NONE)
            data.class = nil
            victim:SetNWString("Class", "")

            timer.Simple(dur, function()
                if not IsValid(victim) then return end
                victim.ZombieFinalDying = nil
                data.team = TEAM_SPECTATOR
                data.class = nil
                victim:SetTeam(TEAM_SPECTATOR)
                victim:SetNWString("Class", "")
                victim:Freeze(false)
                victim:SetMoveType(MOVETYPE_WALK)
                if victim:Alive() then victim:KillSilent() end
                victim:UnSpectate()
                victim:Spawn()
                timer.Simple(0.2, function()
                    if IsValid(victim) then SendSpawned(victim) end
                end)
                timer.Simple(0.3, Warses_CheckZombieEnd)
            end)
        else
            net.Start("Warses_ZombieLoseLife")
            net.WriteInt(left, 8)
            net.Send(victim)

            victim:ChatPrint(string.format("Жизней осталось: %d", left))

            timer.Simple(LOSELIFE_DURATION + 1, function()
                if IsValid(victim) and GAMEMODE.ZombieActive then
                    victim:UnSpectate()
                    victim:Spawn()
                    timer.Simple(0.2, function()
                        if IsValid(victim) and victim:Alive() then SendSpawned(victim) end
                    end)
                end
            end)
        end
    end

    timer.Simple(1, Warses_CheckZombieEnd)
end

hook.Add("PlayerDeath", "Warses_ZombieDeath", function(victim, inflictor, attacker)
    if not GAMEMODE.ZombieActive then return end
    HandleZombieDeath(victim)
end)

hook.Add("PostPlayerDeath", "Warses_ZombieDeath_Cancel", function(ply)
    if not GAMEMODE.ZombieActive then return end
    ply.WarsesNextSpawnTarget = nil
end)

function Warses_CheckZombieEnd()
    if not GAMEMODE.ZombieActive then return end
    if GAMEMODE.ZombieSoloMode then return end

    local alpha, bravo = 0, 0
    for _, ply in ipairs(player.GetAll()) do
        local t = ply:Team()
        if t == TEAM_ALPHA then alpha = alpha + 1
        elseif t == TEAM_BRAVO then bravo = bravo + 1 end
    end

    if alpha == 0 or bravo == 0 then
        local winner = (alpha > 0) and TEAM_ALPHA or TEAM_BRAVO
        Warses_EndZombieMode(winner)
    end
end

function Warses_EndZombieMode(winner)
    if not GAMEMODE.ZombieActive then return end
    GAMEMODE.ZombieActive = false
    GAMEMODE.ZombieSoloMode = false
    GAMEMODE.CurrentGameMode = "capture"
    Warses_SetGameOver(true)

    if winner == TEAM_ALPHA then
        PrintMessage(HUD_PRINTTALK, "*** Советы выжили в зомби-апокалипсисе! ***")
    else
        PrintMessage(HUD_PRINTTALK, "*** Зомби пожрали всё живое... ***")
    end

    net.Start("Warses_ZombieEnd")
    net.Broadcast()

    for _, ply in ipairs(player.GetAll()) do
        ply:Freeze(true)
    end

    timer.Simple(5, function()
        hook.Run("StartMapVote")
    end)
end

hook.Add("PlayerSpawn", "Warses_ZombieRespawnAtDeath", function(ply)
    if not GAMEMODE.ZombieActive then return end
    if not IsValid(ply) then return end
    local pos = ply.ZombieRespawnPos
    if not pos then return end
    ply.ZombieRespawnPos = nil

    timer.Simple(0, function()
        if IsValid(ply) and ply:Alive() then
            ply:SetPos(pos)
        end
    end)
end)

hook.Add("PlayerInitialSpawn", "Warses_ZombieJoin", function(ply)
    if not GAMEMODE.ZombieActive then return end
    timer.Simple(1.5, function()
        if not IsValid(ply) then return end
        net.Start("Warses_ZombieIntro")
        net.WriteFloat(0)
        net.WriteString(GetRole(ply))
        net.WriteInt(GetLives(ply), 8)
        net.Send(ply)
    end)
end)

hook.Add("Warses_ZombieSkipClassMenu", "noop", function() end)

hook.Add("PlayerDisconnected", "Warses_ZombieCheckOnLeave", function(ply)
    if not GAMEMODE.ZombieActive then return end
    timer.Simple(0.5, Warses_CheckZombieEnd)
end)

concommand.Add("warses_zombie_test", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then
        ply:ChatPrint("[Warses] Только суперадмин может запускать тест.")
        return
    end

    if GAMEMODE.ZombieActive then
        local msg = "[Warses] Зомби-режим уже идёт."
        if IsValid(ply) then ply:ChatPrint(msg) else print(msg) end
        return
    end

    Warses_SetGameOver(false)
    for _, p in ipairs(player.GetAll()) do p:Freeze(false) end

    GAMEMODE.ZombieOriginalGermans = {}
    for _, p in ipairs(player.GetAll()) do
        if p:Team() == TEAM_BRAVO then
            GAMEMODE.ZombieOriginalGermans[p:SteamID()] = true
        end
    end

    GAMEMODE.ZombiePending = true
    Warses_StartZombieCutscene()

    PrintMessage(HUD_PRINTTALK, "[Warses] >>> Зомби-режим запущен через тестовую команду <<<")
end)

concommand.Add("warses_zombie_stop", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then
        ply:ChatPrint("[Warses] Только суперадмин может остановить тест.")
        return
    end

    if not GAMEMODE.ZombieActive and not GAMEMODE.ZombiePending then
        local msg = "[Warses] Зомби-режим не активен."
        if IsValid(ply) then ply:ChatPrint(msg) else print(msg) end
        return
    end

    GAMEMODE.ZombiePending = false
    timer.Remove("Warses_ZombieInterrupt")
    timer.Remove("Warses_ZombieStartGameplay")

    if GAMEMODE.ZombieActive then
        Warses_EndZombieMode(TEAM_ALPHA)
    else
        net.Start("Warses_ZombieEnd")
        net.Broadcast()
    end

    PrintMessage(HUD_PRINTTALK, "[Warses] Зомби-режим остановлен админом.")
end)

concommand.Add("warses_zombie_solo", function(ply, cmd, args)
    if not IsValid(ply) then
        print("[Warses] warses_zombie_solo нужно вызывать как игрок (не из rcon).")
        return
    end
    if not ply:IsSuperAdmin() then
        ply:ChatPrint("[Warses] Только суперадмин может запускать тест.")
        return
    end

    if GAMEMODE.ZombieActive then
        ply:ChatPrint("[Warses] Зомби-режим уже идёт. Останови через warses_zombie_stop.")
        return
    end

    local side = string.lower(args[1] or "zombie")
    if side ~= "zombie" and side ~= "soviet" then
        ply:ChatPrint("[Warses] Использование: warses_zombie_solo [zombie|soviet]")
        return
    end

    Warses_SetGameOver(false)
    for _, p in ipairs(player.GetAll()) do p:Freeze(false) end

    local data = GAMEMODE.PlayerData[ply:SteamID()]
    if not data then
        GAMEMODE.PlayerData[ply:SteamID()] = {
            team = nil, class = nil, respawnTime = 0, deaths = 0, kills = 0
        }
        data = GAMEMODE.PlayerData[ply:SteamID()]
    end

    GAMEMODE.ZombieOriginalGermans = {}
    if side == "zombie" then
        ply:SetTeam(TEAM_BRAVO)
        data.team = TEAM_BRAVO
        data.class = "zombie"
        ply:SetNWString("Class", "zombie")
        GAMEMODE.ZombieOriginalGermans[ply:SteamID()] = true
    else
        ply:SetTeam(TEAM_ALPHA)
        data.team = TEAM_ALPHA
        data.class = "assault"
        ply:SetNWString("Class", "assault")
    end

    GAMEMODE.ZombieSoloMode = true
    GAMEMODE.ZombiePending = true
    Warses_StartZombieCutscene()

    ply:ChatPrint(string.format(
        "[Warses] Соло-тест запущен (сторона: %s). Авто-завершение отключено. Останов: warses_zombie_stop",
        side
    ))
end)

concommand.Add("warses_zombie_arm", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then
        ply:ChatPrint("[Warses] Только суперадмин может зарядить триггер.")
        return
    end

    if GAMEMODE.ZombieActive then
        local msg = "[Warses] Зомби-режим уже идёт."
        if IsValid(ply) then ply:ChatPrint(msg) else print(msg) end
        return
    end

    GAMEMODE.ZombieOriginalGermans = {}
    for _, p in ipairs(player.GetAll()) do
        if p:Team() == TEAM_BRAVO then
            GAMEMODE.ZombieOriginalGermans[p:SteamID()] = true
        end
    end
    GAMEMODE.ZombiePending = true

    local msg = "[Warses] Триггер заряжен. Следующий RTV прервётся кат-сценой."
    if IsValid(ply) then ply:ChatPrint(msg) else print(msg) end
end)
